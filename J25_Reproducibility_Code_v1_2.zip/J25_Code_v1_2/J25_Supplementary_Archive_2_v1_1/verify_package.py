"""Verify the delivered package with the Python standard library only."""
from pathlib import Path
import argparse,hashlib,json,sys,zipfile
R=Path(__file__).resolve().parent

def digest(stream):
 h=hashlib.sha256()
 for chunk in iter(lambda:stream.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--deep-science',action='store_true');args=ap.parse_args()
 manifest=json.loads((R/'PACKAGE_MANIFEST.json').read_text());fail=[]
 for row in manifest['files']:
  p=R/row['path']
  if not p.is_file() or p.stat().st_size!=row['bytes']:fail.append(row['path']);continue
  with p.open('rb') as f:hash_ok=digest(f)==row['sha256']
  if not hash_ok:fail.append(row['path'])
 scientific_files=0
 if args.deep_science:
  archive=R/'reproducibility/J25_Public_Data_Reproducibility_v1_0_0.zip'
  with zipfile.ZipFile(archive) as z:
   bad=z.testzip()
   if bad:fail.append('science ZIP CRC: '+bad)
   m=json.loads(z.read('SCIENCE_MANIFEST.json'))
   for row in m['files']:
    try:
     info=z.getinfo(row['path'])
     with z.open(info) as f:ok=info.file_size==row['bytes'] and digest(f)==row['sha256']
    except KeyError:ok=False
    if not ok:fail.append('science: '+row['path'])
    scientific_files+=1
 print(json.dumps({'passed':not fail,'package_files_checked':len(manifest['files']),'science_files_checked':scientific_files,'failures':fail},indent=2))
 sys.exit(bool(fail))

if __name__=='__main__':main()
