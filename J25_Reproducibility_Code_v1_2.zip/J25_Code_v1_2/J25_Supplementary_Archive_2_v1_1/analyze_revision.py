"""Post hoc sensitivity analyses of frozen controller records; no policy refitting.

Run: python analyze_revision.py --science-root PATH --output PATH --workers 4
PATH contains the original J25_v0_8 and science_v05 directories from Zenodo 1.0.0.
"""
import argparse, hashlib, json, os, sys, time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
import pandas as pd

SCIENCE=OUT=None
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def init(science,out):
    global SCIENCE,OUT,audit
    SCIENCE=Path(science);OUT=Path(out)
    sys.path.insert(0,str(SCIENCE/'J25_v0_8/src'))
    import audit
    audit.init()
def one(task):
    from oracle import DispatchOracle,attribute
    cohort,cid,ep,regime,paths=task
    key=f'{cohort}__{cid}__{ep}__{regime}'
    done=OUT/'adaptive_reference'/f'{key}.json'
    if done.exists(): return json.loads(done.read_text())
    data=audit.DATA[cid]; rec={};summaries={}
    for m in ['proposed','adaptive']:
        p=Path(paths[m]);summaries[m]=json.loads(p.read_text())
        with np.load(p.with_name(p.name.replace('.summary.json','.npz')),allow_pickle=False) as z:
            rec[m]={k:z[k].copy() for k in ['actions','states','origins']}
            if m=='adaptive':plant={k:z[k].copy() for k in ['hp_el','aux','dhw','cap','retention','feeder']}
    p,r=rec['proposed'],rec['adaptive']; origins=r['origins']
    cop=np.array([float(audit.heating_cop(data['weather'][t],audit.config(audit.true_scale(regime,i)))) for i,t in enumerate(origins)])
    prices=np.array([audit.config()['tariff'][int(data['hours'][t])] for t in origins])
    o=DispatchOracle(data['loads'][origins],cop,prices,plant,r['states'][0])
    original=SCIENCE/'J25_v0_8/results/oracle'/f'{key}.json'
    old=json.loads(original.read_text());cache={z['contract_id']:z for z in old['solver_calls']}
    calls=[];corners=[];new_count=0
    for U,E in [(p['actions'][:,:,3:5],p['states'][-1]),(r['actions'][:,:,3:5],p['states'][-1]),(p['actions'][:,:,3:5],r['states'][-1]),(r['actions'][:,:,3:5],r['states'][-1])]:
        h=hashlib.sha256(np.ascontiguousarray(U).tobytes()+np.ascontiguousarray(E).tobytes()+b'profile'+b'0.0').hexdigest()[:24]
        if h in cache:
            row=dict(cache[h]);row['source']='Zenodo 1.0.0'
        else:
            row,arrays=o.solve(U,E)
            row.update(contract_id=h,source='revision 1.1')
            if arrays:
                dest=OUT/'adaptive_reference/solutions'/key/f'{h}.npz';dest.parent.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(dest,**arrays)
                row['solution_file']=str(dest.relative_to(OUT))
                row['solution_sha256']=sha(dest)
            cache[h]=row;new_count+=1
        calls.append(row);corners.append(row['cost'] if row['certificate_passed'] else None)
    result={'cohort':cohort,'community':cid,'episode':ep,'regime':regime,'method':'proposed','reference':'adaptive','V00':corners[0],'V10':corners[1],'V01':corners[2],'V11':corners[3],
            **attribute(summaries['proposed']['energy_cost'],summaries['adaptive']['energy_cost'],*corners),
            'solver_calls':calls,'new_distinct_solves':new_count,'all_certified':all(z['certificate_passed'] for z in calls)}
    write(done,result);return result

def synthetic(out):
    from oracle import DispatchOracle,attribute
    loads=np.zeros((2,1,4));loads[0,0,0]=1;loads[1,0,2]=1
    plant={'hp_el':np.array([0.]),'aux':np.array([0.]),'dhw':np.array([2.]),'cap':np.array([2.,2.]),'retention':np.ones(2),'feeder':2.}
    oracle=DispatchOracle(loads,np.ones(2),np.array([1.,3.]),plant,np.zeros((1,2)))
    U0=np.zeros((2,1,2));U0[1,0,1]=1;U1=np.zeros_like(U0)
    E0=np.zeros((1,2));E1=np.array([[0.,1.]])
    rows=[]
    for label,U,E in [('V00',U0,E0),('V10',U1,E0),('V01',U0,E1),('V11',U1,E1)]:
        row,a=oracle.solve(U,E);assert row['certificate_passed']
        np.savez_compressed(out/f'synthetic_{label}.npz',**a)
        rows.append({'corner':label,**row})
    values=[r['cost'] for r in rows]
    assert np.allclose(values,[1.,2.,2.,5.],atol=1e-10)
    result=attribute(1.,7.,*values)
    assert np.allclose([result[k] for k in ['raw_saving','dispatch_component','service_component','inventory_component','interaction']],[6.,2.,2.,2.,2.],atol=1e-10)
    write(out/'synthetic.json',{'description':'Two-hour resistance-heated store; low/high tariffs 1/3; shared import cap 2; base demand 1/0; useful heat demand 0/1; store capacity 2; no losses; initial inventory 0; policy serves 0 and ends 0; reference serves 1 and ends 1 using two units in the expensive hour.', 'corners':rows,'observed_policy_cost':1.,'observed_reference_cost':7.,'attribution':result})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--science-root',required=True);ap.add_argument('--output',required=True);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args()
    science=Path(a.science_root).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
    src=science/'J25_v0_8/analysis';at=pd.read_csv(src/'contract_attribution.csv');po=pd.read_csv(src/'controller_pooled_totals.csv')
    protocol={'version':'1.1','analysis_type':'post hoc review sensitivity; no controller changes, new training or additional building samples','base_archive_doi':'10.5281/zenodo.23978238','base_archive_version':'1.0.0','inputs':{str(p.relative_to(science)):sha(p) for p in [src/'contract_attribution.csv',src/'controller_pooled_totals.csv',science/'J25_v0_8/src/oracle.py']},'all_policy_comparison':'all 14 retained policies against Rule100, both cohorts; no selection by effect size','second_reference':'learned scorer versus adaptive MPC in every 288 replay pairs; exact contracts and unchanged feasibility gates','penalty':'uniform nonnegative unmet-heat penalty added to raw electricity bills only; no claim of comfort valuation','interaction':'signed pooled, pooled absolute, maximum absolute replay interaction; no signed cancellation claim','cluster_sensitivity':'leave one community out within each cohort; descriptive only','new_code_sha256':sha(__file__),'configured_before_new_reference_solves':True}
    write(out/'POSTHOC_ANALYSIS_SPEC_v1_1.json',protocol)
    agg=at.groupby(['cohort','method'],sort=False).agg(cases=('method','size'),saving=('raw_saving','sum'),dispatch=('dispatch_component','sum'),service=('service_component','sum'),storage=('inventory_component','sum'),interaction=('interaction','sum'),interaction_abs_sum=('interaction',lambda x:x.abs().sum()),interaction_max_abs=('interaction',lambda x:x.abs().max()),native_regret=('native_regret','sum')).reset_index()
    agg=agg.merge(po[['cohort','method','energy_cost','unmet_kwh_th','mean_final_error']],on=['cohort','method'],validate='one_to_one')
    agg['contract_share_percent']=np.where(agg.saving.abs()>1e-9,100*(agg.service+agg.storage)/agg.saving,np.nan)
    assert np.max(np.abs(agg.saving-agg.dispatch-agg.service-agg.storage))<1e-8
    agg.to_csv(out/'all_policy_decomposition.csv',index=False)
    pen=[]
    for cohort,g in po.groupby('cohort'):
        ref=g.set_index('method').loc['rule100']
        for _,r in g.iterrows():
            du=float(r.unmet_kwh_th-ref.unmet_kwh_th);gap=float(ref.energy_cost-r.energy_cost)
            pen.append({'cohort':cohort,'method':r.method,'reference':'rule100','electricity_saving':gap,'additional_unmet_kwh_th':du,'break_even_penalty':gap/du if du>1e-9 and gap>0 else None,'ratio_to_peak_electricity_tariff':gap/du/.38 if du>1e-9 and gap>0 else None})
    pd.DataFrame(pen).to_csv(out/'break_even_penalties.csv',index=False)
    loo=[]
    for cohort in at.cohort.unique():
        for method in ['proposed','nominal']:
            q=at[(at.cohort==cohort)&(at.method==method)]
            for cid in q.community.unique():
                r=q[q.community!=cid]
                loo.append({'cohort':cohort,'method':method,'excluded_community':cid,'cases':len(r),'saving':r.raw_saving.sum(),'dispatch':r.dispatch_component.sum(),'service':r.service_component.sum(),'storage':r.inventory_component.sum(),'contract_share_percent':100*(r.service_component.sum()+r.inventory_component.sum())/r.raw_saving.sum()})
    pd.DataFrame(loo).to_csv(out/'leave_one_community_out.csv',index=False)
    init(str(science),str(out));tasks=audit.tasks()
    results=[];start=time.perf_counter()
    with ProcessPoolExecutor(max_workers=a.workers,initializer=init,initargs=(str(science),str(out))) as pool:
        futures=[pool.submit(one,t) for t in tasks]
        for f in as_completed(futures):
            results.append(f.result())
            if len(results)%48==0:print(f'Adaptive-reference cases {len(results)}/{len(tasks)}',flush=True)
    synthetic(out)
    clean=[{k:v for k,v in r.items() if k!='solver_calls'} for r in results]
    d=pd.DataFrame(clean).sort_values(['cohort','community','episode','regime']);d.to_csv(out/'adaptive_reference_attribution.csv',index=False)
    cols=['raw_saving','dispatch_component','service_component','inventory_component','interaction','native_regret','reference_regret']
    d.groupby('cohort')[cols].sum().reset_index().to_csv(out/'adaptive_reference_totals.csv',index=False)
    new=[z for r in results for z in r['solver_calls'] if z['source']=='revision 1.1']
    # Corner duplicates are removed by (replay, contract) before counting solves.
    new_unique={(r['cohort'],r['community'],r['episode'],r['regime'],z['contract_id']):z for r in results for z in r['solver_calls'] if z['source']=='revision 1.1'}
    summary={'analysis_spec_sha256':sha(out/'POSTHOC_ANALYSIS_SPEC_v1_1.json'),'adaptive_reference_cases':len(results),'all_decomposable':bool(d.decomposable.all()),'all_corner_certificates_passed':all(r['all_certified'] for r in results),'new_reference_LPs':len(new_unique),'synthetic_LPs':4,'base_LPs_unchanged':9976,'max_identity_residual':float(d.identity_residual.abs().max()),'max_new_certificate_residual':max(max(z[k] for k in ['equality_residual','inequality_violation','bound_violation','stationarity_residual','dual_sign_violation','duality_gap']) for z in new_unique.values()),'wall_seconds':time.perf_counter()-start,'versions':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':__import__('scipy').__version__},'controller_rollouts_added':0,'claims':'All additions are descriptive analyses of the original cohorts; they do not expand independent climate or weather-year coverage.'}
    assert summary['all_decomposable'] and summary['all_corner_certificates_passed'] and summary['max_identity_residual']<1e-6
    write(out/'REVISION_ANALYSIS_SUMMARY.json',summary)
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__': main()
