"""Reconstruct saved new certificates and compare them with physical balances."""
from pathlib import Path
import argparse,json,sys
import numpy as np
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--science-root',required=True);ap.add_argument('--results',required=True);a=ap.parse_args()
    science=Path(a.science_root).resolve();out=Path(a.results).resolve()
    sys.path.insert(0,str(science/'J25_v0_8/src'))
    import audit
    from oracle import DispatchOracle
    audit.init();tasks={f'{c}__{cid}__{ep}__{reg}':(c,cid,ep,reg,ps) for c,cid,ep,reg,ps in audit.tasks()}
    checked=0;max_residual=0.;fail=[]
    for f in sorted((out/'adaptive_reference').glob('*.json')):
        r=json.loads(f.read_text());task=tasks[f.stem];cohort,cid,ep,reg,paths=task;data=audit.DATA[cid]
        p=Path(paths['adaptive'])
        with np.load(p.with_name(p.name.replace('.summary.json','.npz'))) as z:
            plant={k:z[k].copy() for k in ['hp_el','aux','dhw','cap','retention','feeder']};origins=z['origins'].copy();initial=z['states'][0].copy()
        cop=np.array([float(audit.heating_cop(data['weather'][t],audit.config(audit.true_scale(reg,i)))) for i,t in enumerate(origins)])
        prices=np.array([audit.config()['tariff'][int(data['hours'][t])] for t in origins])
        o=DispatchOracle(data['loads'][origins],cop,prices,plant,initial);seen=set()
        for row in r['solver_calls']:
            if row['source']!='revision 1.1' or row['contract_id'] in seen:continue
            seen.add(row['contract_id'])
            with np.load(out/row['solution_file']) as z:
                x=z['x'];ye=z['equality_dual'];yi=z['inequality_dual'];yl=z['lower_dual'];yu=z['upper_dual'];unmet=z['contract_unmet'];end=z['contract_terminal']
            mat,b,lo,hi=o.problem(unmet,end)
            primal=float(o.c@x);dual=float(b@ye+o.bub@yi+lo@yl+hi@yu)
            vals=[np.max(np.abs(mat@x-b)),max(0,np.max(o.Aub@x-o.bub)),max(0,np.max(lo-x),np.max(x-hi)),np.max(np.abs(o.c-mat.T@ye-o.Aub.T@yi-yl-yu)),max(0,np.max(yi),np.max(-yl),np.max(yu)),abs(primal-dual),abs(primal+o.constant-row['cost'])]
            # An independently expressed heat balance checks each home and service.
            q=x.reshape(o.T,o.B,7);states=np.concatenate([initial[None],q[:,:,5:7]],axis=0)
            heat=np.stack([cop[:,None]*q[:,:,0]+q[:,:,1],q[:,:,2]],axis=-1)
            physical=states[1:]-states[:-1]*plant['retention']-heat-unmet+data['loads'][origins,:][:,:,[1,2]]
            vals.append(np.max(np.abs(physical)));v=float(max(vals));max_residual=max(max_residual,v);checked+=1
            if v>1e-6:fail.append([f.name,row['contract_id'],v])
    result={'passed':not fail,'saved_new_contracts_checked':checked,'maximum_recomputed_residual':max_residual,'failures':fail,'includes_independent_heat_balance_expression':True}
    assert checked==552
    (out/'RECOMPUTED_CERTIFICATES.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert not fail
if __name__=='__main__':main()
