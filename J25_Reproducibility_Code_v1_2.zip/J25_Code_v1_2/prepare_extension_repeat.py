"""Prepare a fresh extension rerun without copying completed output records."""
from pathlib import Path
import argparse, json, shutil

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    destination = args.out.resolve()
    if destination.exists():
        raise FileExistsError('Use a new output directory: ' + str(destination))
    source = root / 'J25_v1_2' / 'data'
    manifest = source / 'cohort_manifest.json'
    if not manifest.is_file():
        raise FileNotFoundError(manifest)
    destination.mkdir(parents=True, exist_ok=False)
    shutil.copytree(source, destination / 'data')
    (destination / 'results').mkdir()
    print(json.dumps({'work_directory': str(destination), 'input_files': sum(p.is_file() for p in (destination / 'data').rglob('*')), 'results_empty': not any((destination / 'results').iterdir())}, indent=2))

if __name__ == '__main__':
    main()
