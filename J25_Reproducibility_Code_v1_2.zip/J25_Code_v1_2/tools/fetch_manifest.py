"""Download the profiles listed in a cohort manifest and verify each SHA-256."""
import json,sys,hashlib,urllib.request
from pathlib import Path
root=Path(sys.argv[1]);m=json.loads((root/'data/cohort_manifest.json').read_text());bad=0;n=0
for c in m['communities']:
  for b in c['buildings']:
    p=root/b['path']
    if not p.exists():
      p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(urllib.request.urlopen(b['url'],timeout=60).read())
    ok=hashlib.sha256(p.read_bytes()).hexdigest()==b['sha256'];bad+=not ok;n+=1
print(n,'profiles fetched;',bad,'hash mismatches')
