#!/usr/bin/env bash
# Rebuild the frozen forecaster, service score, calibration and output corrections from public CityLearn v3.1.0 data
# using the archived training code, then compare model hashes with J25_v0_8/protocol/INITIAL_FREEZE.json.
set -euo pipefail
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
ROOT=$(pwd)
cd science_v05/reviewer_project
[ -f data/study_v0_3/cohort_manifest.json ] || python -m src.study_v0_3.acquire
[ -f data/study_v0_5/cohort_manifest.json ] || python -m src.study_v0_5.acquire
[ -f models/study_v0_3/point_forecast.pkl ] || python -m src.study_v0_3.fit_forecast
[ -f models/study_v0_5/service_score.pkl ] || python -m src.study_v0_5.develop
mkdir -p results/study_v0_5/decision_training
[ -f models/study_v0_5/decision_corrections.json ] || python -m src.study_v0_5.tune_decision
cd "$ROOT"
python - <<'PY'
import json,hashlib
f=json.load(open('J25_v0_8/protocol/INITIAL_FREEZE.json'))['existing_model_and_selection_hashes']
ok={x['path']:hashlib.sha256(open(x['path'],'rb').read()).hexdigest()==x['sha256'] for x in f}
print(json.dumps(ok,indent=1));assert all(ok.values()),'hash mismatch'
PY
