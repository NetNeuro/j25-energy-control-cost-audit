"""Verify every distributed file without scientific dependencies."""
from pathlib import Path
import hashlib, json, sys

def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'PACKAGE_MANIFEST.json').read_text())
    failures = []
    for row in manifest['files']:
        path = root / row['path']
        if not path.is_file() or path.stat().st_size != row['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            failures.append(row['path'])
    result = {'passed': not failures, 'files_checked': len(manifest['files']), 'failures': failures, 'scope': 'Distributed file integrity; no scientific rerun'}
    print(json.dumps(result, indent=2))
    return bool(failures)

if __name__ == '__main__':
    sys.exit(main())
