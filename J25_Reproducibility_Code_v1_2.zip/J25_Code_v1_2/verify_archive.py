from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parent
m=json.loads((R/'SCIENCE_MANIFEST.json').read_text());fail=[]
for row in m['files']:
 p=R/row['path']
 if not p.is_file() or p.stat().st_size!=row['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:fail.append(row['path'])
print(json.dumps({'passed':not fail,'files':len(m['files']),'failures':fail},indent=2))
sys.exit(bool(fail))
