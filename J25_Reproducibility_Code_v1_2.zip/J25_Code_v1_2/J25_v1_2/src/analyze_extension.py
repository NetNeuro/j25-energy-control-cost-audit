"""Pooled summaries, decompositions, intervals, break-even penalties and omission checks.

Cohort roots (each with results/replication and results/oracle*):
  repeat    -> full numerical repeat of the published 36-home replication
  extension -> v1.2 extension cohort (33 homes)
  combined  -> repeat + extension (building-ID replication, 23 communities)
Bootstrap follows J25_v0_8/src/analyze.py exactly: 2,000 draws, seed 20261105,
communities resampled within climate, seasonal weeks resampled jointly, regimes paired.
"""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd
NAMES={'rule50':'Rule 50','rule75':'Rule 75','rule100':'Rule 100','nominal':'Fixed-COP MPC','adaptive':'Adaptive MPC','scenario':'Scenario MPC',
 'decision_focused':'Output-corrected MPC','load_reserve':'Load-envelope reserve','feedback':'Feedback reserve','proposed':'Learned service score',
 'marginal_calibration':'Marginal calibration','no_model_adaptation':'No COP adaptation','uncalibrated_score':'Uncalibrated score','physical_score':'Physical score'}
KEYS=['community','episode','regime']

def load(root,label):
 m=[];a=[];b=[];s=[];ad=[];ads=[]
 for p in sorted((root/'results/replication').glob('*.summary.json')):
  v=json.loads(p.read_text());m.append({'cohort':label,'method':v['spec']['name'],**{k:v[k] for k in ['community','climate','episode','regime','energy_cost','unmet_kwh_th','space_unmet_kwh_th','dhw_unmet_kwh_th','terminal_deviation_kwh_th','max_balance_residual','max_bound_violation','base_overload_hours','fallback_count']}})
 for p in sorted((root/'results/oracle').glob('*__*.json')):
  d=json.loads(p.read_text());a.extend(d['primary']);b.extend(d['ablations'])
  s.extend({'case':d['key'],**{k:x[k] for k in x if k!='message'}} for x in d['solver_calls'])
 for p in sorted((root/'results/oracle_adaptive_reference').glob('*__*.json')):
  d=json.loads(p.read_text());ad.extend(d['primary']);ads.extend({'case':d['key'],**{k:x[k] for k in x if k!='message'}} for x in d['solver_calls'])
 f=lambda rows:pd.json_normalize(rows) if rows else pd.DataFrame()
 A=f(a);B=f(b);AD=f(ad)
 for X in [A,B,AD]:
  if len(X):X['cohort']=label
 return pd.DataFrame(m),A,B,pd.DataFrame(s),AD,pd.DataFrame(ads)

def boot(cube,ids,stat,draws=2000,seed=20261105):
 strata=[[i for i,c in enumerate(ids) if c.startswith(cl)] for cl in ['VT','CA','TX']];rng=np.random.default_rng(seed);E=cube.shape[1];z=[]
 for _ in range(draws):
  ci=np.concatenate([rng.choice(g,size=len(g),replace=True) for g in strata]);ei=rng.integers(0,E,E);z.append(stat(cube[ci][:,ei]))
 return np.array(z)

def intervals(m,a,label):
 q=a[a.method=='proposed'].set_index(KEYS);own=m[m.method=='proposed'].set_index(KEYS);ref=m[m.method=='rule100'].set_index(KEYS)
 q=q.join(own[['unmet_kwh_th','terminal_deviation_kwh_th','energy_cost']].add_prefix('own_')).join(ref[['unmet_kwh_th','terminal_deviation_kwh_th','energy_cost']].add_prefix('ref_'))
 cols=['raw_saving','service_component','inventory_component','dispatch_component','own_unmet_kwh_th','ref_unmet_kwh_th','own_terminal_deviation_kwh_th','ref_terminal_deviation_kwh_th','own_energy_cost','ref_energy_cost']
 ids=sorted(q.index.get_level_values(0).unique());eps=sorted(q.index.get_level_values(1).unique());regs=['nominal','cop_step']
 cube=np.array([[[q.loc[(c,e,r),cols].to_numpy(dtype=float) for r in regs] for e in eps] for c in ids])
 def stat(x):
  mu=x.mean(axis=(0,1,2));d=dict(zip(cols,mu))
  return np.array([d['own_unmet_kwh_th']-d['ref_unmet_kwh_th'],d['own_unmet_kwh_th']-.8*d['ref_unmet_kwh_th'],100*(d['own_energy_cost']/d['ref_energy_cost']-1),
    d['own_terminal_deviation_kwh_th']-d['ref_terminal_deviation_kwh_th'],d['dispatch_component'],d['service_component']+d['inventory_component']])
 names=['unmet_difference_per_replay','service_margin_excess_per_replay','relative_cost_difference_percent','final_error_difference_per_replay','dispatch_regret_difference_per_replay','contract_terms_per_replay']
 point=stat(cube);z=boot(cube,ids,stat)
 out=[{'cohort':label,'metric':n,'estimate':float(point[i]),'lower_95':float(np.quantile(z[:,i],.025)),'upper_95':float(np.quantile(z[:,i],.975)),'draws':2000,'seed':20261105,'communities':len(ids),'seasonal_weeks':len(eps)} for i,n in enumerate(names)]
 lim={'service_margin_excess_per_replay':0.,'relative_cost_difference_percent':1.,'final_error_difference_per_replay':.05}
 for r in out:
  if r['metric'] in lim:r['declared_limit']=lim[r['metric']];r['point_within_limit']=r['estimate']<=lim[r['metric']];r['interval_within_limit']=r['upper_95']<=lim[r['metric']]
 return out

def summarize(m,a,b,s,ad,ads,label,out):
 out.mkdir(parents=True,exist_ok=True)
 n=m.groupby('method').size();assert (n==n.iloc[0]).all()
 pooled=m.groupby('method').agg(rollouts=('energy_cost','size'),bill=('energy_cost','sum'),unmet=('unmet_kwh_th','sum'),sh_unmet=('space_unmet_kwh_th','sum'),dhw_unmet=('dhw_unmet_kwh_th','sum'),
  mean_final_error=('terminal_deviation_kwh_th','mean'),max_balance=('max_balance_residual','max'),max_bound=('max_bound_violation','max'),base_overload_hours=('base_overload_hours','sum'),fallbacks=('fallback_count','sum'))
 dec=a.groupby('method').agg(cases=('method','size'),decomposable=('decomposable','sum'),saving=('raw_saving','sum'),dispatch=('dispatch_component','sum'),heat=('service_component','sum'),
  stores=('inventory_component','sum'),interaction=('interaction','sum'),interaction_abs_max=('interaction',lambda x:float(np.abs(x).max())),native_regret=('native_regret','mean'),identity_max=('identity_residual',lambda x:float(np.abs(x).max())))
 t=pooled.join(dec);t['contract_share_percent']=100*(t.heat+t.stores)/t.saving.where(t.saving.abs()>1e-9)
 ref=t.loc['rule100']
 t['additional_unmet']=t.unmet-ref.unmet;t['break_even_penalty']=np.where((t.saving>0)&(t.additional_unmet>0),t.saving/t.additional_unmet,np.nan)
 t.insert(0,'policy',[NAMES[i] for i in t.index]);t=t.loc[list(NAMES)];t.to_csv(out/'policy_summary.csv')
 res={'label':label,'rollouts':int(len(m)),'communities':int(m.community.nunique()),'attribution_rows':int(len(a)),'all_decomposable':bool(a.decomposable.all()),
  'unique_rule100_lps':int(len(s)),'unique_adaptive_lps':int(len(ads)),'lp_status_counts':{str(k):int(v) for k,v in pd.concat([s,ads]).status.value_counts().items()},
  'all_lps_certified':bool(pd.concat([s,ads]).certificate_passed.all()) if len(s) else None,
  'max_certificate_residual':float(pd.concat([s,ads])[['equality_residual','inequality_violation','bound_violation','stationarity_residual','dual_sign_violation','duality_gap']].max().max()) if len(s) else None,
  'max_identity_residual':float(pd.concat([a.identity_residual,ad.identity_residual if len(ad) else a.identity_residual]).abs().max()),
  'max_native_witness_residual':float(a.filter(like='native_witness.').max().max()),
  'max_balance_residual':float(m.max_balance_residual.max()),'max_bound_violation':float(m.max_bound_violation.max()),'base_overload_hours':int(m.base_overload_hours.sum()),
  'demand_note':'see demand_kwh_th'}
 if len(ad):
  res['adaptive_reference']={k:float(ad[k].sum()) for k in ['raw_saving','dispatch_component','service_component','inventory_component']};res['adaptive_reference']['cases']=int(len(ad));res['adaptive_reference']['all_decomposable']=bool(ad.decomposable.all())
 if len(b):
  q=a[a.method=='proposed'].set_index(KEYS);rows=[]
  for mode,g in b.groupby('matching'):
   d=q.loc[g.set_index(KEYS).index,'V00']-g.set_index(KEYS).V00;rows.append({'matching':mode,'n':len(d),'median':float(d.median()),'maximum':float(d.max()),'pooled':float(d.sum())})
  res['matching_relaxations']=rows
 res['intervals']=intervals(m,a,label)
 loco={}
 for meth in ['proposed','nominal']:
  shares=[]
  for c in sorted(a.community.unique()):
   g=a[(a.method==meth)&(a.community!=c)];shares.append(100*(g.service_component.sum()+g.inventory_component.sum())/g.raw_saving.sum())
  loco[NAMES[meth]]={'min_share_percent':min(shares),'max_share_percent':max(shares),'saving_always_positive':bool(all(a[(a.method==meth)&(a.community!=c)].raw_saving.sum()>0 for c in a.community.unique()))}
 res['leave_one_community_out']=loco
 (out/'summary.json').write_text(json.dumps(res,indent=2)+'\n')
 return t,res

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repeat',type=Path,required=True);ap.add_argument('--extension',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);x=ap.parse_args()
 R=load(x.repeat.resolve(),'repeat');X=load(x.extension.resolve(),'extension') if (x.extension/'results/oracle').exists() else None
 summarize(*R,'repeat',x.out/'repeat')
 if X is not None:
  summarize(*X,'extension',x.out/'extension')
  C=[pd.concat([r,e],ignore_index=True) for r,e in zip(R,X)];summarize(*C,'combined',x.out/'combined')

if __name__=='__main__':main()
