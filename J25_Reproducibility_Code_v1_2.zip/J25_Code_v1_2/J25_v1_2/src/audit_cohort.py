"""Four-contract audit of a cohort directory.

Rule 100 reference: J25_v0_8/src/audit.one_case reused unchanged (all 14 policies,
plus the three matching ablations for the learned scorer).
Adaptive-MPC reference: same DispatchOracle, attribute() and certificate checks,
with 'adaptive' as reference and the learned scorer ('proposed') as evaluated policy.
"""
from pathlib import Path
import argparse,concurrent.futures,hashlib,json,os,sys,time,traceback
os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
E=Path(__file__).resolve().parents[1];V8=E.parent/'J25_v0_8'
sys.path.insert(0,str(V8/'src'))
import numpy as np
import audit
from oracle import DispatchOracle,attribute

def initialize(root):
 audit.R=Path(root);audit.init()

def adaptive_case(task):
 cohort,cid,ep,regime,paths=task;key=f'{cohort}__{cid}__{ep}__{regime}';out=audit.R/'results/oracle_adaptive_reference'
 out.mkdir(parents=True,exist_ok=True);done=out/(key+'.json')
 if done.exists():return json.loads(done.read_text())
 start=time.perf_counter();data=audit.DATA[cid];recs={};summ={}
 for m in ['adaptive','proposed']:
  summ[m]=json.loads(Path(paths[m]).read_text())
  with np.load(Path(paths[m]).with_name(Path(paths[m]).name.replace('.summary.json','.npz'))) as a:
   recs[m]={'actions':a['actions'].copy(),'states':a['states'].copy(),'origins':a['origins'].copy()}
   plant={k:a[k].copy() for k in ['hp_el','aux','dhw','cap','retention','feeder']}
 ref=recs['adaptive'];origins=ref['origins']
 cop=np.array([float(audit.heating_cop(data['weather'][t],audit.config(audit.true_scale(regime,i)))) for i,t in enumerate(origins)])
 prices=np.array([audit.config()['tariff'][int(data['hours'][t])] for t in origins])
 o=DispatchOracle(data['loads'][origins],cop,prices,plant,ref['states'][0]);cache={};solvers=[];sol=out/'solutions'/key;sol.mkdir(parents=True,exist_ok=True)
 def value(U,Ef):
  h=hashlib.sha256(np.ascontiguousarray(U).tobytes()+np.ascontiguousarray(Ef).tobytes()+b'profile0.0').hexdigest()[:24]
  if h not in cache:
   row,arr=o.solve(U,Ef,'profile',0.);row.update({'contract_id':h,'solution_file':f'solutions/{key}/{h}.npz' if arr else None})
   if arr:np.savez_compressed(sol/(h+'.npz'),**arr)
   cache[h]=row;solvers.append(row)
  return cache[h]
 U=recs['proposed']['actions'][:,:,3:5];Ef=recs['proposed']['states'][-1];Ur=ref['actions'][:,:,3:5];Er=ref['states'][-1]
 J=summ['proposed']['energy_cost'];Jr=summ['adaptive']['energy_cost']
 corners=[value(u,e) for u,e in [(U,Ef),(Ur,Ef),(U,Er),(Ur,Er)]]
 res=attribute(J,Jr,*[v['cost'] if v['certificate_passed'] else None for v in corners])
 row={'cohort':cohort,'community':cid,'climate':cid[:2],'episode':ep,'regime':regime,'method':'proposed','reference':'adaptive',
  'observed_cost':J,'reference_cost':Jr,'unmet_kwh_th':summ['proposed']['unmet_kwh_th'],'reference_unmet_kwh_th':summ['adaptive']['unmet_kwh_th'],
  'contract_statuses':[v['status'] for v in corners],'all_certified':all(v['certificate_passed'] for v in corners),
  'V00':corners[0]['cost'],'V10':corners[1]['cost'],'V01':corners[2]['cost'],'V11':corners[3]['cost'],**res}
 result={'key':key,'primary':[row],'solver_calls':solvers,'wall_seconds':time.perf_counter()-start,'completed_utc':audit.stamp()}
 audit.write(done,result);return result

def tasks(root,label):
 g={}
 for p in (root/'results/replication').glob('*.summary.json'):
  s=json.loads(p.read_text());g.setdefault((label,s['community'],s['episode'],s['regime']),{})[s['spec']['name']]=str(p)
 return [(*k,v) for k,v in sorted(g.items())]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--label',required=True);ap.add_argument('--workers',type=int,default=2);a=ap.parse_args()
 root=a.root.resolve();ts=tasks(root,a.label);assert all(len(t[4])==14 for t in ts),'incomplete rollouts'
 for fn,name in [(audit.one_case,'rule100'),(adaptive_case,'adaptive')]:
  with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers,initializer=initialize,initargs=(str(root),)) as pool:
   fs={pool.submit(fn,t):t for t in ts};n=0
   for f in concurrent.futures.as_completed(fs):
    try:f.result()
    except Exception:
     with (root/'results/AUDIT_FAILED_ATTEMPTS.jsonl').open('a') as h:h.write(json.dumps({'task':list(fs[f][:4]),'reference':name,'error':traceback.format_exc()})+'\n')
     raise
    n+=1
    if n%48==0 or n==len(ts):print('Audit',name,n,'/',len(ts),flush=True)

if __name__=='__main__':main()
