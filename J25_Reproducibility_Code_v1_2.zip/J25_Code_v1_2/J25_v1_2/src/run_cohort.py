"""Run the 14 frozen v0.8 policies on a cohort directory, reusing replicate.run unchanged.

--root must contain data/cohort_manifest.json (and receives results/replication).
Used for (a) the full repeat of the published 36-home replication and (b) the
v1.2 extension cohort. No model is fitted or tuned here.
"""
from pathlib import Path
import argparse,concurrent.futures,json,os,sys,traceback
os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
E=Path(__file__).resolve().parents[1];V8=E.parent/'J25_v0_8'
sys.path.insert(0,str(V8/'src'))
import replicate

def initialize(root):
 replicate.R=Path(root);replicate.init()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--workers',type=int,default=2);a=ap.parse_args()
 root=a.root.resolve();design=json.loads((V8/'protocol/DESIGN.json').read_text());m=json.loads((root/'data/cohort_manifest.json').read_text())
 tasks=[(c['id'],ep,spec,reg) for c in m['communities'] for ep in replicate.episode_dates() for reg in design['new_cohort']['regimes'] for spec in design['new_cohort']['policies']]
 out=root/'results/replication';out.mkdir(parents=True,exist_ok=True)
 (out/'CONTEXT.json').write_text(json.dumps({'started_utc':replicate.stamp(),'tasks':len(tasks),'workers':a.workers,'runner':'J25_v1_2/src/run_cohort.py -> J25_v0_8/src/replicate.run (unchanged)','new_model_training':False},indent=2)+'\n')
 n=0
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers,initializer=initialize,initargs=(str(root),)) as pool:
  fs={pool.submit(replicate.run,t):t for t in tasks}
  for f in concurrent.futures.as_completed(fs):
   try:f.result()
   except Exception:
    with (out/'FAILED_ATTEMPTS.jsonl').open('a') as g:g.write(json.dumps({'task':[fs[f][0],fs[f][1]['name'],fs[f][2]['name'],fs[f][3]],'error':traceback.format_exc()})+'\n')
    raise
   n+=1
   if n%112==0 or n==len(tasks):print('Rollouts',n,'/',len(tasks),flush=True)
 (out/'COMPLETED.json').write_text(json.dumps({'completed_utc':replicate.stamp(),'rollouts':n,'decisions':n*168},indent=2)+'\n')

if __name__=='__main__':main()
