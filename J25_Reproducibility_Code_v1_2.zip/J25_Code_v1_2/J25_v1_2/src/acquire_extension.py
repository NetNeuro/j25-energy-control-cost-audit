"""Outcome-independent selection of the v1.2 extension cohort (Tier 2 cluster expansion).

Rule fixed before any extension rollout: exclude every building ID controlled in
v0.3, v0.5 and v0.8 (108 IDs); inspect remaining include=true profiles in
source-schema order with the unchanged eligibility rule; form consecutive groups
of three; keep up to four communities per climate (the replication size), or fewer
where the neighbourhood has fewer remaining eligible profiles. Leftover eligible
profiles that do not complete a group of three are not used.
"""
from pathlib import Path
import json,sys,datetime
E=Path(__file__).resolve().parents[1];V8=E.parent/'J25_v0_8'
sys.path.insert(0,str(V8/'src'))
import acquire as v8
v8.R=E   # downloads and manifest paths resolve inside the extension directory

def main():
 dest=E/'data/cohort_manifest.json'
 if dest.exists():raise FileExistsError('Extension cohort already assigned; preserve it')
 prior=json.loads((V8/'data/cohort_manifest.json').read_text())
 excluded=set(prior['excluded_controlled_ids'])|{b['id'] for c in prior['communities'] for b in c['buildings']}
 assert len(excluded)==108
 result={'source_tag':'v3.1.0','selected_before_extension_control_outputs':True,'excluded_controlled_ids':sorted(excluded),
   'rule':__doc__.strip(),'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'communities':[],'eligibility_audit':[],'weather':prior['weather']}
 for climate in v8.DATASETS:
  schema=json.loads((v8.S/f'data/study_v0_3/raw/{climate}/schema.json').read_text())
  candidates=[k for k,v in schema['buildings'].items() if v.get('include') and k not in excluded]
  chosen=[]
  for k in candidates:
   row=v8.fetch((climate,k));result['eligibility_audit'].append(row)
   if row['eligible']:chosen.append(row)
   if len(chosen)==12:break
  n=min(4,len(chosen)//3)
  for j in range(n):result['communities'].append({'id':f'{climate}_X{j:02d}','climate':climate,'buildings':chosen[3*j:3*j+3]})
  print(climate,'inspected',sum(r['climate']==climate for r in result['eligibility_audit']),'eligible',len(chosen),'communities',n,flush=True)
 ids=[b['id'] for c in result['communities'] for b in c['buildings']]
 assert len(ids)==len(set(ids)) and not excluded.intersection(ids)
 dest.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
