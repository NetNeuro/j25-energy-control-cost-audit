"""Independent reconstruction for a cohort root: physical trajectories, bills and every saved LP certificate.

Adapted from J25_v0_8/src/verify_science.py for any cohort root and for the
adaptive-reference solutions. Tolerance 1e-6. Not field validation.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys
os.environ.setdefault('OMP_NUM_THREADS','1')
E=Path(__file__).resolve().parents[1];V8=E.parent/'J25_v0_8';sys.path.insert(0,str(V8/'src'))
import numpy as np
import audit
from oracle import DispatchOracle
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--expected-rollouts',type=int,required=True);a=ap.parse_args()
 root=a.root.resolve();audit.R=root;audit.init();cfg=audit.config();fails=[];mx={};n={'rollouts':0,'lp_solutions':0,'attribution_rows':0}
 def chk(ok,msg):
  if not ok:fails.append(msg)
 def rem(k,v):mx[k]=max(mx.get(k,0.),float(v))
 for p in sorted((root/'results/replication').glob('*.summary.json')):
  s=json.loads(p.read_text());z=p.with_name(p.name.replace('.summary.json','.npz'));chk(sha(z)==s['record_sha256'],'record hash '+p.stem)
  with np.load(z,allow_pickle=False) as f:act=f['actions'];st=f['states'];orig=f['origins'];ret=f['retention'];cap=f['cap'];hp=f['hp_el'];aux=f['aux'];dhw=f['dhw'];feeder=float(f['feeder'])
  d=audit.DATA[s['community']];load=d['loads'][orig];cop=np.array([float(audit.heating_cop(d['weather'][t],audit.config(audit.true_scale(s['regime'],i)))) for i,t in enumerate(orig)])
  gen=np.stack([act[:,:,0]+act[:,:,1],act[:,:,2]],axis=2);bal=st[1:]-ret*st[:-1]-gen-act[:,:,3:5]+load[:,:,[1,2]]
  el=act[:,:,:3].copy();el[:,:,0]/=cop[:,None];base=(load[:,:,0]+load[:,:,3]/3).sum(axis=1);grid=base+el.sum(axis=(1,2))
  viol=max(0,float(-st.min()),float((st-cap).max()),float((el-np.stack([hp,aux,dhw],axis=1)).max()),float((grid-feeder).max()))
  cost=float(np.array(cfg['tariff'])[d['hours'][orig]]@grid)
  rem('thermal_balance',np.abs(bal).max());rem('physical_violation',viol);rem('bill_residual',abs(cost-s['energy_cost']))
  chk(np.abs(bal).max()<1e-6 and viol<1e-6 and abs(cost-s['energy_cost'])<1e-6,'physics '+p.stem);chk(act.shape==(168,3,7),'arrays '+p.stem);n['rollouts']+=1
 for folder,refname in [('oracle','rule100'),('oracle_adaptive_reference','adaptive')]:
  for p in sorted((root/'results'/folder).glob('*__*.json')):
   case=json.loads(p.read_text());_,cid,ep,reg=case['key'].split('__')
   with np.load(root/'results/replication'/f'{cid}__{ep}__{reg}__{refname}.npz') as f:orig=f['origins'];init=f['states'][0];plant={k:f[k].copy() for k in ['hp_el','aux','dhw','cap','retention','feeder']}
   d=audit.DATA[cid];cop=np.array([float(audit.heating_cop(d['weather'][t],audit.config(audit.true_scale(reg,i)))) for i,t in enumerate(orig)])
   o=DispatchOracle(d['loads'][orig],cop,np.array(cfg['tariff'])[d['hours'][orig]],plant,init)
   for row in case['solver_calls']:
    if row['status']!=0:chk(row['cost'] is None and not row['certificate_passed'],'withheld '+case['key']);continue
    with np.load(root/'results'/folder/row['solution_file'],allow_pickle=False) as f:x=f['x'];ye=f['equality_dual'];yu=f['inequality_dual'];yl=f['lower_dual'];yh=f['upper_dual'];U=f['contract_unmet'];Ef=f['contract_terminal']
    A,b,lo,hi=o.problem(U,Ef,row['mode'],row['terminal_tolerance']);pr=float(o.c@x);du=float(b@ye+o.bub@yu+lo@yl+hi@yh)
    v={'equality':np.abs(A@x-b).max(),'inequality':max(0,(o.Aub@x-o.bub).max()),'bounds':max(0,(lo-x).max(),(x-hi).max()),'stationarity':np.abs(o.c-A.T@ye-o.Aub.T@yu-yl-yh).max(),
       'dual_sign':max(0,yu.max(),(-yl).max(),yh.max()),'gap':abs(pr-du),'objective':abs(pr+o.constant-row['cost'])}
    for k,val in v.items():rem('lp_'+k,val)
    chk(max(v.values())<=1e-6,'certificate '+case['key']+'/'+row['contract_id']);n['lp_solutions']+=1
   for r in case['primary']+case.get('ablations',[]):
    if r['decomposable']:
     res=r['raw_saving']-r['dispatch_component']-r['service_component']-r['inventory_component'];rem('identity',abs(res));chk(abs(res)<=1e-6,'identity '+case['key'])
    n['attribution_rows']+=1
 chk(n['rollouts']==a.expected_rollouts,f"expected {a.expected_rollouts} rollouts, found {n['rollouts']}")
 out={'root':root.name,'passed':not fails,'counts':n,'maximum_residuals':mx,'failures':fails[:50],'failure_count':len(fails),'tolerance':1e-6,
      'scope':'Physical trajectories, bills and every saved primal-dual LP solution reconstructed from saved arrays; numerical tolerance, not field validation.'}
 (root/'VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
 if fails:sys.exit(1)
if __name__=='__main__':main()
