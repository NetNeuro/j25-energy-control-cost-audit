# Supplementary Analysis Code

Regime-specific attribution and paired bootstrap uncertainty for
“Auditing building-controller cost savings in residential heat-pump systems
with matched heat service and final storage” by Anfal Hathah and Md Mottahir Alam.

Version 1.0, 17 November 2026.

## Scope

This self-contained package reproduces manuscript Table 11 and Supplement
S17 (Tables S12–S13). It summarizes existing audit records and does not retrain
controllers or solve additional dispatch programs. The full experiment's public
inputs, models, code and records are in Zenodo version 1.2:
https://doi.org/10.5281/zenodo.24109049.

The analysis code, selected input records and results are included in the same
Zenodo version 1.2 record and are also supplied with the article. The three
frozen scientific archives remain unchanged.

## Reproduce

Use Python 3.11 or newer. NumPy 2.3.5 was used for the reported computation.

```bash
python -m pip install -r requirements.txt
python analyze.py --output regenerated_results
```

Compare `regenerated_results/regime_and_uncertainty.csv` with the supplied
`results/regime_and_uncertainty.csv`. The numerical outputs are deterministic
for the pinned dependency and seed. `verification.json` records the input hash,
contract-identity checks and bootstrap denominator counts.

## Inputs and outputs

- `inputs/attribution_records.csv`: all 736 selected audit records for fixed-COP
  MPC and the learned scorer, covering every replication and extension community,
  seasonal week and conversion regime. Costs are currency units; unmet heat is
  kWh of thermal energy. Replication records are from the full repeat that
  reproduced the reported pooled values at their published precision.
- `inputs/source_manifest.json`: source DOI, component-archive hash, selection
  rule and the SHA-256 of all 368 source JSON records.
- `config.json`: 2,000 draws, seed 20261105 and the resampling definition.
- `analyze.py`: checks the four-contract values and bill identities, then
  recomputes the regime summaries and percentile intervals.
- `results/regime_and_uncertainty.csv`: 18 combinations of cohort, policy and
  regime, including costs per replay, pooled totals and share intervals.
- `results/verification.json`: input checks and the recorded software version.
- `SHA256SUMS.txt`: checksums of the distributed package files.

Communities are resampled within climate; eight seasonal weeks are resampled
jointly across communities. Pooled draws retain both conversion regimes.
The contract-share ratio is recomputed in every draw. All 36,000 ratios had
positive saving denominators. These intervals describe the sampled buildings
and weather windows; they are separate from the omission ranges in manuscript
Table 9 and do not establish generalization to new weather years.

## Source integrity and rights

The source archive is `J25_Supplementary_Archive_3_v1_2_core.zip`, SHA-256
f1d5cd4ba0fc09abcc37021fab5a9be9fbe75f506fa6df28cde42af440111513.
This agrees with the version 1.2 deposit entry manifest. The original scientific
archives have not been changed. The included license and third-party notices
retain the source project's rights and attribution.
