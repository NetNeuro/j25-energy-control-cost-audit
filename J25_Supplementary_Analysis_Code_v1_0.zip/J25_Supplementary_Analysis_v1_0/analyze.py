"""Regime summaries and paired cluster-bootstrap intervals for cost attribution.

Run: python analyze.py --output results
Uses archived audit records; does not refit a model or rerun a controller.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import numpy as np

ROOT=Path(__file__).resolve().parent
VALUES=['raw_saving','dispatch_component','service_component','inventory_component']
METRICS=VALUES+['contract_component','contract_share_percent']
POLICIES={'nominal':'Fixed-COP MPC','proposed':'Learned service score'}
REGIMES=['nominal','cop_step']

def load_records():
    with (ROOT/'inputs/attribution_records.csv').open(newline='') as f:
        records=list(csv.DictReader(f))
    keys=set()
    for r in records:
        key=tuple(r[k] for k in ['cohort','community','episode','regime','method'])
        assert key not in keys, key
        keys.add(key)
        for k in r:
            if k not in ['cohort','community','climate','episode','regime','method']:r[k]=float(r[k])
        h=.5*((r['V10']-r['V00'])+(r['V11']-r['V01']))
        e=.5*((r['V01']-r['V00'])+(r['V11']-r['V10']))
        assert abs(h-r['service_component'])<1e-6
        assert abs(e-r['inventory_component'])<1e-6
        assert abs(r['raw_saving']-sum(r[k] for k in VALUES[1:]))<1e-6
        assert abs(r['raw_saving']-(r['reference_cost']-r['observed_cost']))<1e-6
        assert abs(r['dispatch_component']-(r['reference_regret']-r['native_regret']))<1e-6
    return records

def statistic(cube):
    mean=cube.mean(axis=(0,1,2))
    contract=mean[2]+mean[3]
    share=100*contract/mean[0] if abs(mean[0])>1e-9 else np.nan
    return np.r_[mean,contract,share]

def bootstrap(cube,communities,draws,seed):
    strata=[[i for i,c in enumerate(communities) if c.startswith(cl)] for cl in ['VT','CA','TX']]
    assert all(strata)
    rng=np.random.default_rng(seed)
    values=[]
    for _ in range(draws):
        ci=np.concatenate([rng.choice(g,size=len(g),replace=True) for g in strata])
        ei=rng.integers(0,cube.shape[1],cube.shape[1])
        values.append(statistic(cube[ci][:,ei]))
    return np.array(values)

def analyze(records,config):
    results=[]
    for cohort in ['replication','extension','combined']:
        selected=records if cohort=='combined' else [r for r in records if r['cohort']==cohort]
        for method,name in POLICIES.items():
            selected_policy=[r for r in selected if r['method']==method]
            communities=sorted({r['community'] for r in selected_policy})
            episodes=sorted({r['episode'] for r in selected_policy})
            indexed={(r['community'],r['episode'],r['regime']):r for r in selected_policy}
            cube=np.array([[[[indexed[c,e,g][k] for k in VALUES] for g in REGIMES] for e in episodes] for c in communities])
            assert len(indexed)==len(communities)*len(episodes)*2
            for regime,indices in [('pooled',[0,1]),('nominal',[0]),('cop_step',[1])]:
                x=cube[:,:,indices,:]
                point=statistic(x)
                samples=bootstrap(x,communities,config['draws'],config['seed'])
                # Undefined ratios are reported explicitly and never silently discarded.
                valid=np.isfinite(samples[:,5]); positive=samples[:,0]>0
                lo=np.quantile(samples[:,:5],.025,axis=0)
                hi=np.quantile(samples[:,:5],.975,axis=0)
                ratio_ci=np.quantile(samples[valid,5],[.025,.975]) if valid.all() else [np.nan,np.nan]
                row={'cohort':cohort,'policy':name,'regime':regime,'communities':len(communities),'weeks':len(episodes),'replays':int(np.prod(x.shape[:3])),'draws':config['draws'],'seed':config['seed'],'undefined_share_draws':int((~valid).sum()),'nonpositive_saving_draws':int((~positive).sum())}
                for i,k in enumerate(METRICS):
                    row[k]=float(point[i])
                    row[k+'_lower_95']=float(lo[i] if i<5 else ratio_ci[0])
                    row[k+'_upper_95']=float(hi[i] if i<5 else ratio_ci[1])
                    if i<5:row[k+'_pooled']=float(point[i]*row['replays'])
                results.append(row)
    return results

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'results')
    args=parser.parse_args()
    config=json.loads((ROOT/'config.json').read_text())
    records=load_records();results=analyze(records,config)
    args.output.mkdir(parents=True,exist_ok=True)
    with (args.output/'regime_and_uncertainty.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)
    checks={'input_records':len(records),'summary_rows':len(results),'all_input_identities_within_1e_6':True,'undefined_share_draws':sum(r['undefined_share_draws'] for r in results),'nonpositive_saving_draws':sum(r['nonpositive_saving_draws'] for r in results),'numpy_version':np.__version__,'input_sha256':hashlib.sha256((ROOT/'inputs/attribution_records.csv').read_bytes()).hexdigest(),'config':config}
    (args.output/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))
    for r in results:
        print(r['cohort'],r['policy'],r['regime'],f"saving={r['raw_saving_pooled']:.6f}; H={r['service_component_pooled']:.6f}; E={r['inventory_component_pooled']:.6f}; share={r['contract_share_percent']:.6f} [{r['contract_share_percent_lower_95']:.6f},{r['contract_share_percent_upper_95']:.6f}]")

if __name__=='__main__':main()
