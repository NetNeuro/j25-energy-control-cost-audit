"""Read-only checks of the reviewer scientific subset; no simulation or fitting."""
import hashlib,json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
ROOT=Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 errors=[];counts={}
 def check(ok,message):
  if not ok:errors.append(message)
 def read(p):return json.loads((ROOT/p).read_text())
 m=read('REVIEW_ARCHIVE_MANIFEST.json')
 for x in m['files']:
  p=ROOT/x['path'];check(p.is_file() and p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],'Delivered bytes '+x['path'])
 counts['manifest_files']=len(m['files'])
 for name in ['TEST_FREEZE','BOPTEST_FREEZE']:
  for x in read('protocol/study_v0_5/'+name+'.json')['files']:check(sha(ROOT/x['path'])==x['sha256'],'Frozen scientific input '+x['path'])
 scope=read('SCIENTIFIC_SUBSET_SCOPE.json');check(all(x['source_sha256']==x['delivered_sha256']==sha(ROOT/x['path']) for x in scope['preserved_scientific_files']),'Preserved original scientific bytes')
 prior={b['id'] for c in read('data/study_v0_3/cohort_manifest.json')['communities'] for b in c['buildings']};fresh=[]
 for c in read('data/study_v0_5/cohort_manifest.json')['communities']:
  for b in c['buildings']:fresh.append(b['id']);check(sha(ROOT/b['path'])==b['sha256'],'Fresh profile '+b['id'])
 check(len(fresh)==18 and len(set(fresh))==18 and not set(fresh)&prior,'18 fresh profiles disjoint from prior 54')
 from src.study_v0_5.common import load_data
 data=load_data(True);comparisons={};scorechecks=0;scoremisses=0;maxbalance=0.;maxelectrical=0.
 for folder,n in [('fresh_test',1248),('physical_score_test',96)]:
  paths=sorted((ROOT/'results/study_v0_5'/folder).glob('*.summary.json'));check(len(paths)==n,'Complete episode count '+folder);decisions=0
  for p in paths:
   s=json.loads(p.read_text());z=p.with_name(s['key']+'.npz')
   with ZipFile(z) as zz:check(zz.testzip() is None,'Compressed array CRC '+s['key'])
   with np.load(z,allow_pickle=False) as a:
    act=a['actions'];state=a['states'];rows=[json.loads(x) for x in a['records_json']]
    check(act.shape==(168,3,7) and state.shape==(169,3,2) and len(rows)==168,'Array/record shape '+s['key'])
    check(np.isfinite(act).all() and np.isfinite(state).all(),'Finite arrays '+s['key']);decisions+=len(rows)
    loads=data[s['community']]['loads'][a['origins']];q=np.stack([act[:,:,0]+act[:,:,1],act[:,:,2]],axis=2)
    residual=state[1:]-state[:-1]*a['retention']-q-act[:,:,3:5]+loads[:,:,[1,2]];maxbalance=max(maxbalance,float(abs(residual).max()))
    cop=np.array([r['actual_cop'] for r in rows]);g=(loads[:,:,0]+loads[:,:,3]/3+act[:,:,0]/cop[:,None]+act[:,:,1]+act[:,:,2]).sum(axis=1)
    maxelectrical=max(maxelectrical,float(np.max(abs(g-[r['grid_kwh'] for r in rows]))))
    check(abs(act[:,:,3:5].sum()-s['unmet_kwh_th'])<1e-5,'Recorded unmet sum '+s['key'])
    check(max(0,-state.min(),(state-a['cap']).max())<1e-6,'Storage bound '+s['key'])
    check(g.max()<=float(a['feeder'])+1e-6,'Import bound '+s['key'])
    if folder=='fresh_test':
     valid=[r for r in rows if r['score_miscovered'] is not None];scorechecks+=len(valid);scoremisses+=sum(r['score_miscovered'] for r in valid)
     if s['spec']['name'] in ['proposed','uncalibrated_score']:comparisons.setdefault((s['community'],s['episode'],s['regime']),{})[s['spec']['name']]=hashlib.sha256(act.tobytes()).hexdigest()
  counts[folder]={'episodes':len(paths),'decisions':decisions}
 check(maxbalance<1e-6 and maxelectrical<1e-6,'Independent balances')
 check(len(comparisons)==96 and all(x['proposed']==x['uncalibrated_score'] for x in comparisons.values()),'Exact calibration action equality')
 check(scorechecks==64128 and scoremisses==273,'Complete score counters')
 gate=read('results/study_v0_5/analysis_robust/PRIMARY_GATE.json');check(not gate['point_criteria_met'] and not gate['interval_supported_criteria_met'],'Failed effectiveness criteria preserved')
 reps=[json.loads(p.read_text()) for p in (ROOT/'results/study_v0_5').glob('reproduction_*/NUMERICAL_REPRODUCTION.json')]
 check(any(x['episodes']==6 and x['all_passed'] for x in reps),'Executed six-episode repetition receipt')
 check(read('results/study_v0_5/MODEL_RETRAINING_VERIFICATION.json')['passed'],'Executed model-refit receipt')
 dyn=read('results/study_v0_5/boptest/ALL_RESULTS.json');check(len(dyn)==16 and sum(x['steps']*x['instances'] for x in dyn)==32256,'Dynamic case count')
 null=read('publication_diagnostics_reference/null_score_diagnostic.json');check(sum(x['null_upper_bound_misses_on_that_stream'] for x in null)==71,'Post hoc null diagnostic')
 counts.update(max_thermal_residual=maxbalance,max_electrical_residual=maxelectrical,score_checks=scorechecks,score_misses=scoremisses,dynamic_cases=len(dyn))
 result={'passed':not errors,'counts':counts,'failures':errors,'interpretation':'Record/byte integrity; the primary scientific improvement criterion failed.'}
 print(json.dumps(result,indent=2))
 if errors:raise SystemExit(1)
if __name__=='__main__':main()
