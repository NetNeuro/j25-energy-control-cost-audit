import json,pickle,unittest,copy
import numpy as np
from src.study_v0_3.data import ROOT,load_all,features,forecast_point
from src.study_v0_3.control import *

class StudyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.all=load_all();cls.d=cls.all['VT_00'];cls.c=configuration();cls.p=size_plant(cls.d,cls.c,3)
        cls.model,cls.cal=load_models()
    def test_roles_and_id_disjointness(self):
        ids=[b for d in self.all.values() for b in d['building_ids']]
        self.assertEqual(len(ids),54);self.assertEqual(len(set(ids)),54)
        self.assertEqual(sum(d['role']=='test' for d in self.all.values()),6)
        for c in ['VT','CA','TX']:self.assertEqual(sum(d['climate']==c and d['role']=='train' for d in self.all.values()),3)
    def test_future_loads_cannot_change_features_forecasts_or_actions(self):
        a=copy.deepcopy(self.d);a['loads'][2161:]=1e6;a['weather'][2161:]=1e6
        np.testing.assert_array_equal(features(self.d,2160,np.arange(1,24)),features(a,2160,np.arange(1,24)))
        for x,y in zip(forecast_point(self.d,2160,24,self.model),forecast_point(a,2160,24,self.model)):
            np.testing.assert_array_equal(x,y)
        state=np.tile(self.p['cap']/2,(3,1))
        x,*_=act(self.d,2160,24,state,self.p,'reserve',self.model,self.cal)
        y,*_=act(a,2160,24,state,self.p,'reserve',self.model,self.cal)
        np.testing.assert_allclose(x,y)
    def test_lexicographic_current_service_and_independent_audit(self):
        state=np.tile(self.p['cap']/2,(3,1))
        for method in ['persistence','ml_mpc','scenario','reserve']:
            a,e,r=act(self.d,336,6,state,self.p,method,self.model,self.cal)
            self.assertLess(r['unmet_kwh_th'],1e-5)
            self.assertLess(r['max_balance_residual'],1e-6)
            self.assertLess(r['max_bound_violation'],1e-6)
            self.assertLess(r['lex_violation'],1e-6)
    def test_reserve_witness_cannot_shed_current_load_to_charge(self):
        state=np.tile(self.p['cap']/2,(3,1));y,temp=forecast_point(self.d,336,6,self.model)
        p=build_problem(y[None],temp[None],self.d['hours'][336:342],state,self.p,self.c);p['base_n']=len(p['c'])
        # Deliberately unreachable next-step envelope must be rejected.
        q=add_reserve_witness(p,np.full((3,4),1000.),-20,self.p,self.c)
        x,r=lex_solve(q,self.c);self.assertIsNone(x);self.assertIn('Infeasible',r['status'])
    def test_lexicographic_service_is_not_traded_for_a_low_price(self):
        state=np.zeros((3,2));y=np.zeros((1,2,3,4));y[:,:,:,1]=1
        p=build_problem(y,np.zeros((1,2)),np.array([0,1]),state,self.p,self.c);p['base_n']=len(p['c'])
        x,r=lex_solve(p,self.c)
        self.assertIsNotNone(x);self.assertLess(x[p['idx'][:,:,:,3:5]].sum(),1e-5)

if __name__=='__main__':unittest.main()
