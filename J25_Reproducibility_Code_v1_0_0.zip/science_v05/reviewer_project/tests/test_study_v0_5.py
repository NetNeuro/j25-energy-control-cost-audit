import copy,json,pickle,unittest
import numpy as np
from scipy.optimize import linprog
from src.study_v0_5.common import config,execute,EfficiencyObserver,load_data,ROOT,size_plant
from src.study_v0_5.controller import min_deficit,solve_plan,Controller,choose
from src.study_v0_3.control import load_models
from src.benchmark_v0_2 import heating_cop

class ServiceStudyTests(unittest.TestCase):
    def test_closed_form_recourse_matches_independent_lp(self):
        rng=np.random.default_rng(77)
        for _ in range(50):
            plant={'cap':np.array([5.,3.]),'retention':np.array([.998,.996]),'hp_el':rng.uniform(.3,3,3),
                'aux':rng.uniform(.2,4,3),'dhw':rng.uniform(.2,3,3),'feeder':rng.uniform(2,15),'buildings':3}
            load=rng.uniform(0,6,(3,4));state=rng.random((3,2))*plant['cap'];temp=float(rng.uniform(-10,20));scale=float(rng.uniform(.7,1.1))
            k=float(heating_cop(temp,config(scale)));need=np.maximum(load[:,[1,2]]-state*plant['retention'],0)
            A=np.zeros((6,15));rhs=need.ravel();cost=np.zeros(15);grid=np.zeros(15);bounds=[]
            for b in range(3):
                j=5*b;A[2*b,[j,j+1,j+3]]=[k,1,1];A[2*b+1,[j+2,j+4]]=[1,1]
                cost[j+3:j+5]=1;grid[j:j+3]=1
                bounds.extend([(0,plant['hp_el'][b]),(0,plant['aux'][b]),(0,plant['dhw'][b]),(0,None),(0,None)])
            head=max(0,plant['feeder']-(load[:,0]+load[:,3]/3).sum())
            r=linprog(cost,A_eq=A,b_eq=rhs,A_ub=grid[None],b_ub=[head],bounds=bounds,method='highs')
            self.assertTrue(r.success);self.assertAlmostEqual(r.fun,min_deficit(load,temp,state,plant,scale),places=7)
    def test_electric_command_and_realized_balance(self):
        d=load_data()['VT_00'];p=size_plant(d,config(),3);state=np.tile(p['cap']/2,(3,1));load=d['loads'][1000]
        a=np.column_stack([p['hp_el']*2,p['aux']*.2,p['dhw']*.2,np.zeros((3,2)),state])
        actual,end,r=execute(load,float(d['weather'][1000]),state,a,p,1.,.8)
        self.assertLess(r['max_balance_residual'],1e-10);self.assertTrue(np.all(end>=-1e-9));self.assertTrue(np.all(end<=p['cap']+1e-9))
        self.assertLess(r['device_violation'],1e-9)
    def test_thermostat_curtails_electricity_when_store_fills(self):
        p={'cap':np.array([2.,2.]),'retention':np.ones(2),'hp_el':np.ones(3)*4,'aux':np.ones(3)*4,'dhw':np.ones(3)*4,'feeder':50,'buildings':3}
        state=np.ones((3,2))*2;a=np.column_stack([np.ones((3,3))*4,np.zeros((3,2)),state])
        _,end,r=execute(np.zeros((3,4)),10,state,a,p,1,1)
        self.assertTrue(np.allclose(end,2));self.assertAlmostEqual(r['grid_kwh'],0);self.assertGreater(r['thermostat_curtailed_heat_kwh_th'],0)
    def test_shared_simultaneous_event_protects_any_selection(self):
        prediction=np.array([.1,.3,.2]);truth=np.array([.2,.35,.4]);q=float((truth-prediction).max())
        for j in [0,1,2]:self.assertLessEqual(truth[j],prediction[j]+q+1e-12)
    def test_quarter_repair_does_not_inherit_half_full_terminal(self):
        d=load_data()['VT_00'];p=size_plant(d,config(),3);state=np.zeros((3,2));y=np.zeros((1,3,4));w=np.array([10.])
        a,info=solve_plan(y,w,np.array([0]),state,p,1,reserve=np.tile(p['cap']*.25,(3,1)))
        self.assertIsNotNone(a);self.assertTrue(np.allclose(a[:,5:7],p['cap']*.25,atol=1e-5))
    def test_efficiency_measurement_updates_only_after_execution(self):
        obs=EfficiencyObserver();self.assertEqual(obs.value,1.)
        k=float(heating_cop(0,config()))
        obs.update({'hp_electrical_kwh':1.,'hp_heat_kwh_th':k*.8},0)
        self.assertAlmostEqual(obs.value,.96)
    def test_fresh_id_exclusion(self):
        old=json.loads((ROOT/'data/study_v0_3/cohort_manifest.json').read_text());new=json.loads((ROOT/'data/study_v0_5/cohort_manifest.json').read_text())
        a={b['id'] for c in old['communities'] for b in c['buildings']};b=[b['id'] for c in new['communities'] for b in c['buildings']]
        self.assertEqual(len(set(b)),18);self.assertFalse(a&set(b))
    def test_future_load_and_weather_do_not_change_action(self):
        d=load_data()['VT_00'];mut={k:v.copy() if isinstance(v,np.ndarray) else v for k,v in d.items() if not k.startswith('_')}
        t=1000;mut['loads'][t+1:]*=7;mut['weather'][t+1:]+=15
        model,cal=load_models();risk=pickle.load(open(ROOT/'models/study_v0_5/service_score.pkl','rb'));rcal=json.loads((ROOT/'models/study_v0_5/score_calibration.json').read_text())
        p=size_plant(d,config(),3);state=np.tile(p['cap']/2,(3,1));s={'method':'risk_simultaneous','tolerance':.1}
        a,_=Controller(s,model,cal,risk,rcal,cache=False).act(d,t,24,state,p)
        b,_=Controller(s,model,cal,risk,rcal,cache=False).act(mut,t,24,state,p)
        self.assertTrue(np.allclose(a,b,atol=1e-7))
if __name__=='__main__':unittest.main()
