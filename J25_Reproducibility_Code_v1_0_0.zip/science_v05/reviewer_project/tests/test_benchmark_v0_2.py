import copy
import json
import unittest
import numpy as np
from src.benchmark_v0_2 import (ROOT, load_inputs, size_plant, forecast, build_problem,
    solve, matrix_audit, action_audit, fallback, heating_cop)


class BenchmarkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c = json.loads((ROOT/'configs/benchmark_v0_2.json').read_text())
        cls.d = load_inputs(cls.c)
        cls.p = size_plant(cls.d, cls.c, 3)

    def test_future_values_cannot_change_causal_problem(self):
        d = copy.deepcopy(self.d)
        d['loads'][337:] = 1e6; d['weather'][337:] = 1e6
        a = forecast(self.d, self.c, 336, 24, 3, 14)
        b = forecast(d, self.c, 336, 24, 3, 14)
        np.testing.assert_array_equal(a[0], b[0]); np.testing.assert_array_equal(a[1], b[1])
        self.assertLess(max(max(x) for x in a[2]['residual_donor_rows']), 336)
        self.assertEqual(len(set(tuple(x) for x in a[2]['residual_donor_rows'])), 13)

    def test_capacity_sizing_ignores_all_development_outcomes(self):
        d = copy.deepcopy(self.d); d['loads'][336:] = 1e6
        q = size_plant(d, self.c, 3)
        for k in ['hp_el', 'aux', 'dhw', 'cap', 'feeder']:
            np.testing.assert_array_equal(self.p[k], q[k])
        self.assertAlmostEqual(self.p['cap'][0], 5.815)
        self.assertAlmostEqual(self.p['cap'][1], 3.489)

    def test_shared_first_action_and_distinct_thermal_buses(self):
        loads, temp, _ = forecast(self.d, self.c, 336, 3, 3, 5)
        state = np.tile(self.p['cap']/2, (3,1))
        p = build_problem(loads,temp,self.d['hours'][336:339],state,self.p,self.c)
        np.testing.assert_array_equal(p['idx'][0,0],p['idx'][4,0])
        self.assertFalse(np.array_equal(p['idx'][0,1],p['idx'][4,1]))
        for method in ['simplex','ipm']:
            r = solve(p,self.c,method)
            self.assertEqual(r['status'],'Optimal')
            self.assertLess(matrix_audit(p,r['x'])['max_matrix_violation'],1e-6)
            a = action_audit(loads[0,0],temp[0,0],state,r['x'][p['idx'][0,0]],self.p,self.c)
            self.assertLess(a['max_balance_residual'],1e-6)
            self.assertLess(a['max_bound_violation'],1e-6)

    def test_dhw_cannot_use_space_heat_pump(self):
        p = copy.deepcopy(self.p); p['dhw'][:] = 0
        state = np.zeros((3,2)); loads = np.zeros((1,1,3,4)); loads[:,:,:,2]=2
        q = build_problem(loads,np.zeros((1,1)),np.array([0]),state,p,self.c)
        r=solve(q,self.c,'simplex'); a=r['x'][q['idx'][0,0]]
        np.testing.assert_allclose(a[:,4],2)
        # HP may fill the separate SH terminal inventory, but cannot serve DHW.
        np.testing.assert_allclose(a[:,0],a[:,5])

    def test_feeder_limit_exposes_unmet_service(self):
        p=copy.deepcopy(self.p); p['feeder']=1
        state=np.zeros((3,2)); loads=np.zeros((1,1,3,4)); loads[:,:,:,1]=10
        q=build_problem(loads,np.zeros((1,1)),np.array([0]),state,p,self.c)
        r=solve(q,self.c,'simplex')
        self.assertEqual(r['status'],'Optimal')
        self.assertGreater(r['x'][q['idx'][0,0,:,3]].sum(),20)
        self.assertLessEqual(r['x'][q['grid'][0,0]],1+1e-6)

    def test_solver_free_fallback_and_uncontrollable_overload(self):
        current=self.d['loads'][336,:3]; state=np.tile(self.p['cap']/2,(3,1))
        a=fallback(current,0,state,self.p,self.c)
        check=action_audit(current,0,state,a,self.p,self.c)
        self.assertLess(check['max_bound_violation'],1e-6)
        p=copy.deepcopy(self.p);p['feeder']=0
        a=fallback(current,0,state,p,self.c)
        self.assertGreater(action_audit(current,0,state,a,p,self.c)['max_bound_violation'],0)

    def test_solvers_agree_and_timeout_is_retained(self):
        loads,temp,_=forecast(self.d,self.c,336,6,3,5)
        q=build_problem(loads,temp,self.d['hours'][336:342],np.tile(self.p['cap']/2,(3,1)),self.p,self.c)
        a=solve(q,self.c,'simplex'); b=solve(q,self.c,'ipm')
        self.assertAlmostEqual(a['objective'],b['objective'],places=5)
        r=solve(q,self.c,'simplex',time_limit=0.)
        self.assertNotEqual(r['status'],'Optimal')
        # The actual decision path must execute and audit fallback on timeout.
        from src.benchmark_v0_2 import decision
        row,_,_,_,_=decision(self.d,self.c,336,6,self.p,np.tile(self.p['cap']/2,(3,1)),5,'simplex',limit=0.)
        self.assertTrue(row['fallback']);self.assertNotEqual(row['status'],'Optimal')
        self.assertLess(row['max_bound_violation'],1e-6)


if __name__=='__main__':
    unittest.main()
