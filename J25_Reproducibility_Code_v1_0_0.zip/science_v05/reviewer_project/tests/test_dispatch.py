"""Physics and information-access checks; not research-performance claims."""

import unittest

import numpy as np
import pandas as pd

from src.dispatch import Plant, solve_horizon, rule_action, physical_residuals
from src.run_pilot import causal_forecast, training_only_capacities


class DispatchTests(unittest.TestCase):
    def test_thermal_to_electric_conversion_and_balances(self):
        plant = Plant(6, 0, 0, 0, 0, storage_hourly_loss_fraction=0)
        sol = solve_horizon(plant, [2], [6], [3], [1], 0, 0)
        self.assertTrue(sol.success, sol.message)
        self.assertAlmostEqual(sol.grid_import[0], 5)  # 2 + 6/3 + 3/3
        self.assertAlmostEqual(sol.unmet_heat[0], 0)
        self.assertAlmostEqual(sol.hp_heat[0], 6)
        self.assertAlmostEqual(sol.storage[-1], 0)

    def test_storage_shifts_heat_without_creating_energy(self):
        plant = Plant(6, 0, 6, 6, 6, storage_hourly_loss_fraction=0)
        sol = solve_horizon(plant, [0, 0], [0, 6], [0, 0], [0.1, 1], 0, 0)
        self.assertTrue(sol.success)
        np.testing.assert_allclose(sol.hp_heat, [6, 0], atol=1e-7)
        np.testing.assert_allclose(sol.storage, [0, 6, 0], atol=1e-7)
        self.assertAlmostEqual(sol.objective, 0.2)

    def test_unmet_heat_is_exposed_and_hard_variant_is_infeasible(self):
        plant = Plant(1, 0, 0, 0, 0, storage_hourly_loss_fraction=0)
        soft = solve_horizon(plant, [0], [4], [0], [0.2], 0, 0)
        hard = solve_horizon(plant, [0], [4], [0], [0.2], 0, 0,
                             allow_unmet_heat=False)
        self.assertTrue(soft.success)
        self.assertAlmostEqual(soft.unmet_heat[0], 3)
        self.assertFalse(hard.success)
        self.assertEqual(hard.status, 2)

    def test_rule_satisfies_same_physics_and_restores_target(self):
        plant = Plant(10, 10, 20, 10, 20)
        storage = 10
        for heat in [1, 12, 5, 19, 0, 6]:
            action = rule_action(plant, 2, heat, 3, storage, 10)
            check = physical_residuals(plant, 2, heat, 3, storage, action)
            self.assertLessEqual(check["max_bound_violation"], 1e-8)
            self.assertAlmostEqual(check["electric_balance_residual_kwh"], 0)
            self.assertAlmostEqual(check["thermal_balance_residual_kwh_th"], 0)
            self.assertAlmostEqual(action["unmet_heat_kwh_th"], 0)
            storage = action["storage_end_kwh_th"]
        self.assertAlmostEqual(storage, 10)

    def test_rule_logs_physical_shortfall_without_negative_storage(self):
        plant = Plant(1, 1, 4, 2, 2, storage_hourly_loss_fraction=0)
        action = rule_action(plant, 0, 10, 0, 1, 2)
        self.assertAlmostEqual(action["unmet_heat_kwh_th"], 7)
        self.assertAlmostEqual(action["storage_end_kwh_th"], 0)
        self.assertLessEqual(physical_residuals(plant, 0, 10, 0, 1, action)["max_bound_violation"], 1e-8)

    def test_end_target_prevents_free_storage_depletion(self):
        plant = Plant(6, 0, 6, 6, 6, storage_hourly_loss_fraction=0)
        sol = solve_horizon(plant, [0], [3], [0], [1], 3, 3)
        self.assertTrue(sol.success)
        self.assertAlmostEqual(sol.hp_heat[0], 3)
        self.assertAlmostEqual(sol.storage[-1], 3)

    def test_persistence_cannot_read_future_values(self):
        data = pd.DataFrame({column: np.arange(400, dtype=float) for column in
                             ("non_shiftable_load_kwh", "heating_plus_dhw_kwh_th", "cooling_demand_kwh_th")})
        before, indices = causal_forecast(data, 100, 24)
        self.assertEqual(indices, [100]+list(range(77, 100)))
        data.loc[101:, :] = -999999
        after, _ = causal_forecast(data, 100, 24)
        np.testing.assert_array_equal(before, after)
        with self.assertRaises(ValueError):
            causal_forecast(data, 100, 25)

    def test_capacity_sizing_cannot_use_test_future(self):
        data = pd.DataFrame({"heating_plus_dhw_kwh_th": np.arange(500, dtype=float)})
        before = training_only_capacities(data)
        data.loc[336:, "heating_plus_dhw_kwh_th"] = 1e10
        self.assertEqual(before, training_only_capacities(data))


if __name__ == "__main__":
    unittest.main()
