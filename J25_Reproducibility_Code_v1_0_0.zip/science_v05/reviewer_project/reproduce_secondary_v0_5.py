"""Repeat the frozen 96-episode physical-score comparison in a fresh work tree.

--prepare-only checks/copies all inputs without executing a second campaign.
The reference archive and original selection/protocol records are never rewritten.
"""
import argparse,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

RUNNER=r'''
import concurrent.futures,json,sys
import numpy as np
from pathlib import Path
from src.study_v0_5.common import *
from src.study_v0_5.physical_score_secondary import init
from src.study_v0_5.campaign import run_episode
if __name__=='__main__':
 reference=Path(sys.argv[1]);cfg=json.loads((ROOT/'configs/study_v0_5/physical_score_selected.json').read_text())
 spec=cfg['spec'];data=load_data(True);ids=[c for c,d in data.items() if d['role']=='fresh_test']
 tasks=[(c,e,spec,r,'physical_score_reproduction') for c in ids for e in episode_dates() for r in ['nominal','cop_step']]
 checks=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=2,initializer=init,initargs=(True,)) as pool:
  for result in pool.map(run_episode,tasks):
   key=result['key'];original=json.loads((reference/f'results/study_v0_5/physical_score_test/{key}.summary.json').read_text())
   diffs={k:abs(result[k]-original[k]) for k in ['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']}
   with np.load(ROOT/f'results/study_v0_5/physical_score_reproduction/{key}.npz') as a,np.load(reference/f'results/study_v0_5/physical_score_test/{key}.npz') as b:
    action=float(np.abs(a['actions']-b['actions']).max())
   checks.append({'key':key,'metric_differences':diffs,'maximum_action_difference':action,'passed':max(diffs.values())<1e-5 and action<1e-5})
   if len(checks)%12==0:print('Compared',len(checks),'of 96',flush=True)
 out={'scope':'Numerical repetition, not independent evaluation','episodes':len(checks),'all_passed':len(checks)==96 and all(x['passed'] for x in checks),'checks':checks}
 write_json(ROOT/'SECONDARY_NUMERICAL_COMPARISON.json',out)
 if not out['all_passed']:raise SystemExit(1)
'''

def prepare(work):
 if work.exists():raise FileExistsError('Use a new work directory')
 work.mkdir(parents=True)
 for rel in ['src','data/study_v0_3','data/study_v0_5','models/study_v0_3','models/study_v0_5','configs','protocol/study_v0_5']:
  shutil.copytree(ROOT/rel,work/rel,ignore=shutil.ignore_patterns('__pycache__','*.pyc'),dirs_exist_ok=True)
 (work/'results/study_v0_5').mkdir(parents=True)
 import hashlib
 freeze=json.loads((work/'protocol/study_v0_5/TEST_FREEZE.json').read_text())
 for x in freeze['files']:assert hashlib.sha256((work/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
 (work/'repeat_secondary.py').write_text(RUNNER)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work-dir',required=True);ap.add_argument('--prepare-only',action='store_true');a=ap.parse_args()
 work=Path(a.work_dir).resolve();prepare(work)
 if a.prepare_only:print(json.dumps({'prepared':True,'scientific_campaign_executed':False,'work_dir':str(work)}));return
 env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 subprocess.run([sys.executable,'repeat_secondary.py',str(ROOT)],cwd=work,env=env,check=True)
if __name__=='__main__':main()
