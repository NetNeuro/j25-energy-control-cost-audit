"""Numerically repeat the frozen campaign in a new result directory.

--quick executes six full episodes. --full repeats all 1248 primary episodes.
Neither option replaces the reference results or declares a new independent test.
"""
import argparse,concurrent.futures,json
import numpy as np
from src.study_v0_5.common import *
from src.study_v0_5.campaign import init_worker,run_episode

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');ap.add_argument('--full',action='store_true');args=ap.parse_args()
    if args.quick==args.full:raise ValueError('Choose one of --quick or --full')
    freeze=json.loads((ROOT/'protocol/study_v0_5/TEST_FREEZE.json').read_text())
    for x in freeze['files']:assert sha(ROOT/x['path'])==x['sha256'],x['path']
    data=load_data(True);specs=json.loads((ROOT/'configs/study_v0_5/selected.json').read_text())['test_specs']
    ids=[c for c,d in data.items() if d['role']=='fresh_test'];eps=episode_dates();regimes=['nominal','cop_step']
    if args.quick:ids=['VT_N00','CA_N00','TX_N00'];eps=eps[:1];regimes=['cop_step'];specs=[s for s in specs if s['name'] in ['adaptive','proposed']]
    phase='reproduction_'+stamp().replace(':','').replace('.','');tasks=[(c,e,s,r,phase) for c in ids for e in eps for r in regimes for s in specs];checks=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,initializer=init_worker,initargs=(True,)) as pool:
        for i,r in enumerate(pool.map(run_episode,tasks)):
            ref=json.loads((ROOT/f'results/study_v0_5/fresh_test/{r["key"]}.summary.json').read_text())
            delta={k:abs(r[k]-ref[k]) for k in ['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']}
            a=np.load(ROOT/f'results/study_v0_5/{phase}/{r["key"]}.npz');b=np.load(ROOT/f'results/study_v0_5/fresh_test/{r["key"]}.npz')
            diff=float(np.abs(a['actions']-b['actions']).max());checks.append({'key':r['key'],'metric_differences':delta,'maximum_action_difference':diff,'passed':max(delta.values())<1e-5 and diff<1e-5})
            if (i+1)%6==0:print('Reproduced',i+1,'/',len(tasks),flush=True)
    result={'mode':'quick' if args.quick else 'full','episodes':len(checks),'all_passed':all(x['passed'] for x in checks),'checks':checks}
    write_json(ROOT/f'results/study_v0_5/{phase}/NUMERICAL_REPRODUCTION.json',result)
    print(json.dumps({'episodes':len(checks),'passed':result['all_passed']},indent=2))
    if not result['all_passed']:raise SystemExit(1)
if __name__=='__main__':main()
