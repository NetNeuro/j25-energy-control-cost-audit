"""Repeat the 16 frozen coordinated FMU cases in a new work tree.

--prepare-only verifies frozen inputs without fetching a runtime or simulating.
Full repetition is provided; only the original full dynamic campaign was executed.
"""
import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work-dir',required=True);ap.add_argument('--prepare-only',action='store_true');a=ap.parse_args()
 work=Path(a.work_dir).resolve()
 if work.exists():raise FileExistsError('Use a new work directory')
 work.mkdir(parents=True)
 for rel in ['src','models/study_v0_5_boptest','protocol/study_v0_5']:
  shutil.copytree(ROOT/rel,work/rel,ignore=shutil.ignore_patterns('__pycache__','*.pyc'),dirs_exist_ok=True)
 for rel in ['data/boptest_v0_3/wrapped.fmu','tools/prepare_boptest_runtime.py']:
  (work/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,work/rel)
 freeze=json.loads((work/'protocol/study_v0_5/BOPTEST_FREEZE.json').read_text())
 for x in freeze['files']:assert hashlib.sha256((work/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
 if a.prepare_only:print(json.dumps({'prepared':True,'scientific_campaign_executed':False,'work_dir':str(work)}));return
 env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 subprocess.run([sys.executable,'tools/prepare_boptest_runtime.py','--destination','data/boptest_v0_3/runtime'],cwd=work,env=env,check=True)
 subprocess.run([sys.executable,'-m','src.study_v0_5.boptest_coupled','--mode','test'],cwd=work,env=env,check=True)
 original=json.loads((ROOT/'results/study_v0_5/boptest/ALL_RESULTS.json').read_text());new=json.loads((work/'results/study_v0_5/boptest/ALL_RESULTS.json').read_text())
 key=lambda x:(x['period'],x['method'],x['regime']);ref={key(x):x for x in original};checks=[]
 for x in new:
  r=ref[key(x)];diffs={k:abs(x[k]-r[k]) for k in ['cold_discomfort_kh','hot_discomfort_kh','custom_cost','energy_kwh']}
  checks.append({'key':key(x),'metric_differences':diffs,'passed':max(diffs.values())<1e-4})
 result={'scope':'Numerical repetition of frozen cases, not independent evaluation','coordinated_runs':len(checks),'all_passed':len(checks)==16 and all(x['passed'] for x in checks),'checks':checks}
 (work/'DYNAMIC_NUMERICAL_COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'runs':len(checks),'all_passed':result['all_passed']}))
 if not result['all_passed']:raise SystemExit(1)
if __name__=='__main__':main()
