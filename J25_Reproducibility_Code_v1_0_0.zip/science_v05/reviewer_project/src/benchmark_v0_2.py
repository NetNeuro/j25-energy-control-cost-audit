"""Development benchmark v0.2: individual devices and two-stage scenario MPC.

Native hourly energy dispatch, not compressor-cycle or indoor-comfort simulation.
All future scenario recourse is revealed after the first action: this is an
optimistic two-stage approximation, not a multistage robust-control guarantee.
"""
import hashlib
import json
from pathlib import Path
from time import perf_counter, process_time

import highspy
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parents[1]
CHANNELS = ['non_shiftable_load', 'heating_demand', 'dhw_demand', 'cooling_demand']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_inputs(config):
    manifest = json.loads((ROOT/config['cohort_manifest']).read_text())
    frames = []
    for item in manifest['files']:
        p = ROOT/item['path']
        if digest(p) != item['sha256']:
            raise ValueError('Data hash mismatch: '+str(p))
        f = pd.read_csv(p)
        if len(f) != 8760 or not np.isfinite(f[CHANNELS].to_numpy()).all():
            raise ValueError('Invalid annual demand record')
        if (f[CHANNELS].to_numpy() < 0).any():
            raise ValueError('Negative demand')
        if frames and not f[['month', 'hour', 'day_type']].equals(frames[0][['month', 'hour', 'day_type']]):
            raise ValueError('Calendar mismatch')
        frames.append(f)
    return {'loads': np.stack([f[CHANNELS].to_numpy() for f in frames], axis=1),
            'weather': pd.read_csv(ROOT/'data/raw/weather.csv')['outdoor_dry_bulb_temperature'].to_numpy(),
            'hours': frames[0]['hour'].to_numpy(dtype=int)-1,
            'ids': [x['building_id'] for x in manifest['files']]}


def size_plant(data, config, buildings):
    p = config['physics']
    train = data['loads'][:config['training_end_exclusive'], :buildings]
    hp_th = np.maximum(1, np.ceil(np.quantile(train[:, :, 1], .9, axis=0)))
    # Electrical nameplate chosen at reference COP; useful output varies with COP.
    hp_el = hp_th/p['reference_cop_for_sizing']
    aux = np.maximum(1, np.ceil(train[:, :, 1].max(axis=0)))
    dhw = np.maximum(1, np.ceil(train[:, :, 2].max(axis=0)))
    cap = np.array([p['space_buffer_litres']*p['space_usable_delta_k']*p['water_kwh_per_litre_k'],
                    p['dhw_buffer_litres']*p['dhw_usable_delta_k']*p['water_kwh_per_litre_k']])
    # Declared connected-load design assumption, not a measured transformer.
    feeder = p['feeder_connected_load_fraction']*(
        (train[:, :, 0]+train[:, :, 3]/p['cooling_cop']).sum(axis=1).max()
        + (hp_el+aux+dhw).sum())
    return {'hp_el': hp_el, 'aux': aux, 'dhw': dhw, 'cap': cap,
            'retention': np.array([1-p['space_hourly_loss'], 1-p['dhw_hourly_loss']]),
            'feeder': float(feeder), 'buildings': buildings}


def heating_cop(temperature, config):
    p = config['physics']
    # Bounded idealized Carnot fraction; no measured defrost or capacity map.
    return np.clip(p['carnot_fraction']*(p['space_supply_c']+273.15)/
                   np.maximum(1, p['space_supply_c']-np.asarray(temperature)),
                   p['cop_min'], p['cop_max'])


def forecast(data, config, origin, horizon, buildings, scenarios):
    end = config['training_end_exclusive']
    if origin < end or not 1 <= horizon <= 24 or not 1 <= scenarios <= 14:
        raise ValueError('Invalid causal development request')
    targets = origin+np.arange(horizon)
    sources = np.where(np.arange(horizon) == 0, origin, targets-24)
    if np.any(sources > origin):
        raise ValueError('Future information requested')
    nominal = data['loads'][sources, :buildings].copy()
    weather = data['weather'][sources].copy()
    out = np.repeat(nominal[None], scenarios, axis=0)
    temp = np.repeat(weather[None], scenarios, axis=0)
    # Thirteen distinct complete daily residual blocks; never duplicate to
    # enlarge the problem. Common donor preserves cross-building dependence.
    donor_days = np.random.default_rng(config['scenario_seed']).permutation(np.arange(1, end//24))
    audit = {'origin': int(origin), 'nominal_sources': sources.tolist(),
             'targets': targets.tolist(), 'residual_donor_rows': []}
    for s, day in enumerate(donor_days[:scenarios-1], start=1):
        donor = day*24 + data['hours'][targets]
        previous = donor-24
        if donor.max() >= end or donor.min() < 24:
            raise ValueError('Residual donor outside calibration window')
        delta = data['loads'][donor, :buildings]-data['loads'][previous, :buildings]
        out[s] = np.maximum(0, nominal+delta)
        temp[s] = weather+data['weather'][donor]-data['weather'][previous]
        out[s, 0] = nominal[0]
        temp[s, 0] = weather[0]
        audit['residual_donor_rows'].append(donor.tolist())
    return out, temp, audit


def build_problem(loads, temperature, hours, state, plant, config):
    """Sparse extensive form with shared first-step columns, no redundant ties.

    Per-building variables: HP heat, auxiliary heat, DHW heat, SH unmet, DHW
    unmet, SH inventory, DHW inventory. Grid import is shared by the community.
    Net buffer exchange avoids simultaneous charge/discharge variables.
    """
    S, H, B, _ = loads.shape
    if state.shape != (B, 2) or np.any(state < 0) or np.any(state > plant['cap']):
        raise ValueError('Invalid initial inventory')
    idx = np.empty((S, H, B, 7), dtype=int)
    grid = np.empty((S, H), dtype=int)
    c, lo, hi = [], [], []
    def var(cost=0., lower=0., upper=np.inf):
        k = len(c); c.append(cost); lo.append(lower); hi.append(upper); return k
    cop = heating_cop(temperature, config)
    price = np.asarray(config['tariff'])[hours]
    penalty = config['shortfall_penalty']
    for s in range(S):
        for t in range(H):
            if s and t == 0:
                idx[s, t], grid[s, t] = idx[0, 0], grid[0, 0]
                continue
            weight = 1. if t == 0 else 1./S
            for b in range(B):
                upper = [plant['hp_el'][b]*cop[s, t], plant['aux'][b], plant['dhw'][b],
                         loads[s, t, b, 1], loads[s, t, b, 2], *plant['cap']]
                for k in range(7):
                    idx[s, t, b, k] = var(penalty*weight if k in (3, 4) else 0., upper=upper[k])
            grid[s, t] = var(price[t]*weight, upper=plant['feeder'])
    rr, cc, vv, lower, upper = [], [], [], [], []
    def row(terms, lb, ub):
        r = len(lower)
        for j, v in terms:
            rr.append(r); cc.append(int(j)); vv.append(float(v))
        lower.append(float(lb)); upper.append(float(ub))
    for s in range(S):
        for t in range(H):
            if s and t == 0:
                continue
            terms = [(grid[s, t], 1)]
            for b in range(B):
                x = idx[s, t, b]
                terms += [(x[0], -1/cop[s, t]), (x[1], -1), (x[2], -1)]
                for j, (generation, unmet, inventory, demand_ch) in enumerate([
                        ((0, 1), 3, 5, 1), ((2,), 4, 6, 2)]):
                    demand = loads[s, t, b, demand_ch]
                    thermal = [(x[inventory], 1), (x[unmet], -1)] + [(x[g], -1) for g in generation]
                    rhs = -demand
                    if t:
                        thermal.append((idx[s, t-1, b, inventory], -plant['retention'][j]))
                    else:
                        rhs += plant['retention'][j]*state[b, j]
                    row(thermal, rhs, rhs)
                    net = [(x[g], 1) for g in generation]+[(x[unmet], 1)]
                    row(net, demand-plant['cap'][j], demand+plant['cap'][j])
            base = (loads[s, t, :, 0]+loads[s, t, :, 3]/config['physics']['cooling_cop']).sum()
            row(terms, base, base)
        for b in range(B):
            for j in range(2):
                a, z = var(penalty/S), var(penalty/S)
                target = plant['cap'][j]*config['initial_fraction']
                row([(idx[s, H-1, b, 5+j], 1), (a, 1), (z, -1)], target, target)
    A = coo_matrix((vv, (rr, cc)), shape=(len(lower), len(c))).tocsc()
    return {'c': np.array(c), 'lo': np.array(lo), 'hi': np.array(hi), 'A': A,
            'rl': np.array(lower), 'ru': np.array(upper), 'idx': idx, 'grid': grid,
            'loads': loads, 'cop': cop, 'state': state, 'hours': hours, 'plant': plant}


def solve(problem, config, method, previous_basis=None, time_limit=None):
    start = perf_counter()
    h = highspy.Highs()
    options = {'output_flag': False, 'threads': 1, 'parallel': 'off', 'presolve': 'on',
               'solver': {'auto': 'choose', 'simplex': 'simplex', 'ipm': 'ipm', 'simplex_basis': 'simplex'}[method],
               'simplex_strategy': 1, 'run_crossover': 'on',
               'primal_feasibility_tolerance': 1e-8, 'dual_feasibility_tolerance': 1e-8,
               'ipm_optimality_tolerance': 1e-8, 'random_seed': config['solver_seed'],
               'time_limit': config['solver_limit_seconds'] if time_limit is None else time_limit}
    for k, v in options.items():
        if h.setOptionValue(k, v) != highspy.HighsStatus.kOk:
            raise RuntimeError('Rejected solver option '+k)
    lp = highspy.HighsLp()
    lp.num_col_, lp.num_row_ = len(problem['c']), problem['A'].shape[0]
    lp.col_cost_, lp.col_lower_, lp.col_upper_ = problem['c'], problem['lo'], problem['hi']
    lp.row_lower_, lp.row_upper_ = problem['rl'], problem['ru']
    lp.a_matrix_.format_ = highspy.MatrixFormat.kColwise
    lp.a_matrix_.start_ = problem['A'].indptr
    lp.a_matrix_.index_, lp.a_matrix_.value_ = problem['A'].indices, problem['A'].data
    if h.passModel(lp) != highspy.HighsStatus.kOk:
        raise RuntimeError('Rejected LP')
    reused = False
    if method == 'simplex_basis' and previous_basis is not None:
        if len(previous_basis.col_status) == lp.num_col_ and len(previous_basis.row_status) == lp.num_row_:
            reused = h.setBasis(previous_basis) == highspy.HighsStatus.kOk
    setup = perf_counter()-start
    t = perf_counter(); h.run(); elapsed = perf_counter()-t
    sol, info = h.getSolution(), h.getInfo()
    valid = bool(sol.value_valid)
    return {'status': h.modelStatusToString(h.getModelStatus()), 'x': np.array(sol.col_value) if valid else None,
            'objective': float(info.objective_function_value) if valid else None,
            'dual_feasible': int(info.dual_solution_status) == 2,
            'max_dual_infeasibility': float(info.max_dual_infeasibility),
            'max_primal_infeasibility_solver': float(info.max_primal_infeasibility),
            'primal_dual_objective_error': float(info.primal_dual_objective_error),
            'iterations': int(info.simplex_iteration_count), 'ipm_iterations': int(info.ipm_iteration_count),
            'solver_setup_seconds': setup, 'solver_seconds': elapsed, 'basis_reused': reused,
            'basis': h.getBasis() if h.getBasis().valid else None}


def matrix_audit(problem, x):
    if x is None:
        return {'max_matrix_violation': None}
    y = problem['A']@x
    return {'max_matrix_violation': float(max(0., np.max(problem['lo']-x), np.max(x-problem['hi']),
                                               np.max(problem['rl']-y), np.max(y-problem['ru'])))}


def action_audit(current, temp, state, action, plant, config):
    """Check physical balances separately from sparse constraint assembly."""
    cop = float(heating_cop(temp, config))
    hp, aux, water, us, uw, es, ew = action.T
    end = np.stack([es, ew], axis=1)
    unmet = np.stack([us, uw], axis=1)
    generation = np.stack([hp+aux, water], axis=1)
    demands = current[:, [1, 2]]
    net = generation+unmet-demands
    residual = end-plant['retention']*state-net
    grid = float((current[:, 0]+current[:, 3]/config['physics']['cooling_cop']+hp/cop+aux+water).sum())
    violation = max(0., -action.min(), (hp-plant['hp_el']*cop).max(),
                    (aux-plant['aux']).max(), (water-plant['dhw']).max(),
                    (unmet-demands).max(), (end-plant['cap']).max(),
                    (np.abs(net)-plant['cap']).max(), grid-plant['feeder'])
    return {'grid_kwh': grid, 'unmet_kwh_th': float(unmet.sum()),
            'max_balance_residual': float(np.abs(residual).max()), 'max_bound_violation': float(violation),
            'feeder_headroom_kw': float(plant['feeder']-grid), 'end': end,
            'space_unmet_kwh_th': float(us.sum()), 'dhw_unmet_kwh_th': float(uw.sum())}


def fallback(current, temp, state, plant, config):
    """Solver-free feasible allocation when fixed electric demand fits feeder.

    Heat shortfall is explicit; no guarantee that service or terminal targets
    can be maintained. Uncontrollable base overload is reported by the audit.
    """
    B = len(current); cop = float(heating_cop(temp, config))
    retained = state*plant['retention']; demand = current[:, [1, 2]]
    output = np.zeros((B, 3))
    headroom = max(0., plant['feeder']-(current[:, 0]+current[:, 3]/config['physics']['cooling_cop']).sum())
    limits = [plant['hp_el']*cop, plant['aux'], plant['dhw']]
    for restore in [False, True]:
        desired = np.maximum(0, demand+(plant['cap']*config['initial_fraction'] if restore else 0)-retained)
        for k in [0, 2, 1]:
            j = 1 if k == 2 else 0
            for b in range(B):
                already = output[b, 2] if j else output[b, :2].sum()
                need = max(0., desired[b, j]-already)
                efficiency = cop if k == 0 else 1.
                addition = min(need, limits[k][b]-output[b, k], headroom*efficiency)
                output[b, k] += addition; headroom = max(0., headroom-addition/efficiency)
    gen = np.stack([output[:, :2].sum(axis=1), output[:, 2]], axis=1)
    unmet = np.maximum(0, demand-retained-gen)
    end = retained+gen+unmet-demand
    return np.column_stack([output, unmet, end])


def decision(data, config, origin, horizon, plant, state, scenarios, method, basis=None, limit=None):
    wall, cpu = perf_counter(), process_time()
    loads, temp, evidence = forecast(data, config, origin, horizon, plant['buildings'], scenarios)
    forecast_seconds = perf_counter()-wall
    t = perf_counter()
    p = build_problem(loads, temp, data['hours'][origin:origin+horizon], state, plant, config)
    build_seconds = perf_counter()-t
    result = solve(p, config, method, basis, limit)
    t = perf_counter(); check = matrix_audit(p, result['x'])
    fallback_used = (result['status'] != 'Optimal' or check['max_matrix_violation'] is None
                     or check['max_matrix_violation'] > config['tolerance'])
    if fallback_used:
        action = fallback(loads[0, 0], temp[0, 0], state, plant, config)
    else:
        action = result['x'][p['idx'][0, 0]]
    audit = action_audit(loads[0, 0], temp[0, 0], state, action, plant, config)
    check_seconds = perf_counter()-t
    row = {k: v for k, v in result.items() if k not in ('x', 'basis')}
    row.update({k: v for k, v in audit.items() if k != 'end'})
    row.update(check)
    if result['x'] is not None:
        plan = result['x'][p['idx']]
        row['predicted_expected_unmet_kwh_th'] = float(plan[:,:,:,3:5].sum()/scenarios)
        row['predicted_expected_terminal_deviation_kwh_th'] = float(np.abs(
            plan[:,-1,:,5:7]-plant['cap']*config['initial_fraction']).sum()/scenarios)
        row['predicted_feeder_binding_steps'] = int((result['x'][p['grid']] >= plant['feeder']-1e-6).sum())
    row.update({'origin': origin, 'horizon': horizon, 'buildings': plant['buildings'], 'scenarios': scenarios,
                'method': method, 'fallback': fallback_used, 'variables': len(p['c']), 'constraints': p['A'].shape[0],
                'nonzeros': p['A'].nnz, 'forecast_seconds': forecast_seconds, 'build_seconds': build_seconds,
                'audit_fallback_seconds': check_seconds, 'decision_seconds': perf_counter()-wall,
                'cpu_seconds': process_time()-cpu})
    return row, audit['end'], action, result['basis'], evidence
