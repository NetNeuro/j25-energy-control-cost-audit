#!/usr/bin/env python3
"""Fetch and audit the frozen three-building J25 pilot demand dataset.

Requires Python >= 3.10 and pandas. No CityLearn runtime is installed or used.
The raw file digests below freeze the publicly retrieved v3.1.0 dataset bytes.
Default: use verified local files, downloading missing files. --refresh checks
the public URLs again. --offline refuses network access and requires all files.
"""

from __future__ import annotations

import argparse
import calendar
import concurrent.futures
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
import time
import urllib.error
import urllib.request

import pandas as pd


VERSION = "v3.1.0"
DATASET = "vt_chittenden_county_neighborhood"
BASE_URL = (
    "https://raw.githubusercontent.com/citylearn-project/CityLearn/"
    f"{VERSION}/data/datasets/{DATASET}/"
)
REPO_URL = "https://github.com/citylearn-project/CityLearn"
SOURCE_CODE_BASE = (
    "https://raw.githubusercontent.com/citylearn-project/CityLearn/" + VERSION + "/"
)
EXPECTED_SHA256 = {
    "schema.json": "b43fed71b9c8fcbed7f925788cf975b458134a39a96be7ffb63405eb60ac9b0b",
    "weather.csv": "d8633bdbf78832f6d1c801b111e98a78254d0fc23b864412c3d6a8f09e63737f",
    "resstock-amy2018-2021-release-1-112208.csv": "5a4184df0a3db15a5eb5d28a48e5314890b823086e8950e7788769738e3b92fe",
    "resstock-amy2018-2021-release-1-116582.csv": "9a8710ebe74ea4a20a4432f9c3ed8a2fdca12d7c114ac20ba97c3a333edf59c6",
    "resstock-amy2018-2021-release-1-134804.csv": "f79e7f89b4d0e8ff9fffb6e3d28908768be576142818007b33255f63044a8492",
}
EXPECTED_BUILDINGS = [
    "resstock-amy2018-2021-release-1-112208",
    "resstock-amy2018-2021-release-1-116582",
    "resstock-amy2018-2021-release-1-134804",
]
CALENDAR_COLUMNS = ["month", "hour", "day_type", "daylight_savings_status"]
DEMAND_COLUMNS = {
    "non_shiftable_load": "non_shiftable_load_kwh",
    "heating_demand": "heating_demand_kwh_th",
    "cooling_demand": "cooling_demand_kwh_th",
    "dhw_demand": "dhw_demand_kwh_th",
}
ASSET_FIELDS = [
    "pricing", "carbon_intensity", "cooling_storage", "heating_storage",
    "dhw_storage", "electrical_storage", "pv", "cooling_device",
    "heating_device", "dhw_device",
]
UNIT_MAP = {
    "row_index": "zero-based source row, dimensionless",
    "day_index": "floor(row_index / 24), zero-based day index",
    "month": "source calendar month, 1..12",
    "source_hour": "source hour label, 1..24; not converted to a UTC timestamp",
    "day_type": "source day-of-week/special-day code",
    "daylight_savings_status": "source binary indicator",
    "non_shiftable_load_kwh": "kWh electricity per native 1-hour step; sum of three buildings",
    "heating_demand_kwh_th": "kWh thermal heat per native 1-hour step; sum of three buildings",
    "cooling_demand_kwh_th": "kWh thermal cooling per native 1-hour step; sum of three buildings",
    "dhw_demand_kwh_th": "kWh thermal DHW per native 1-hour step; sum of three buildings",
    "heating_plus_dhw_kwh_th": "heating_demand_kwh_th + dhw_demand_kwh_th; excludes cooling",
    "solar_generation_source_sum": (
        "arithmetic sum of raw source inputs; CityLearn default input convention W/kW; "
        "NOT installed PV energy; all selected raw values are zero"
    ),
    "outdoor_temperature_c": "degrees Celsius; one shared weather profile, not summed",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def download_or_verify(
    filename: str,
    raw_dir: Path,
    previous: dict,
    refresh: bool,
    offline: bool,
) -> dict:
    """Obtain exact source bytes; reject changed data rather than silently repin."""
    require(Path(filename).name == filename, f"Unsafe source filename: {filename}")
    require(filename in EXPECTED_SHA256, f"Source file is not pinned: {filename}")
    path = raw_dir / filename
    url = BASE_URL + filename
    network_metadata = {}
    use_cache = path.exists() and not refresh
    if use_cache:
        payload = path.read_bytes()
        old = previous.get(filename, {})
        for key in ("downloaded_utc", "http_status", "resolved_url", "authentication"):
            if key in old:
                network_metadata[key] = old[key]
        provenance = "verified_local_cache"
    else:
        if offline:
            raise FileNotFoundError(f"Offline mode requires {path}")
        error = None
        for attempt in range(3):
            try:
                request = urllib.request.Request(
                    url,
                    headers={"User-Agent": "J25-public-research-data-audit/1.0"},
                )
                with urllib.request.urlopen(request, timeout=30) as response:
                    payload = response.read()
                    network_metadata = {
                        "downloaded_utc": utc_now(),
                        "http_status": response.status,
                        "resolved_url": response.geturl(),
                        "authentication": "none; public HTTPS request without credentials",
                    }
                error = None
                break
            except (urllib.error.URLError, TimeoutError) as exc:
                error = exc
                if attempt < 2:
                    time.sleep(1)
        if error is not None:
            raise RuntimeError(f"Download failed for {url}: {error}") from error
        provenance = "public_network_download"
    actual = digest(payload)
    require(
        actual == EXPECTED_SHA256[filename],
        f"SHA256 mismatch for {filename}: expected {EXPECTED_SHA256[filename]}, got {actual}",
    )
    if not use_cache:
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_bytes(payload)
        temporary.replace(path)
    return {
        "filename": filename,
        "path": f"data/raw/{filename}",
        "source_url": url,
        "sha256": actual,
        "byte_count": len(payload),
        "obtained_this_run": provenance,
        **network_metadata,
    }


def audit_frame(frame: pd.DataFrame, filename: str) -> dict:
    missing = {name: int(value) for name, value in frame.isna().sum().items()}
    numerical = list(frame.select_dtypes(include="number").columns)
    nonfinite = {
        name: int((~frame[name].map(math.isfinite)).sum())
        for name in numerical
    }
    require(sum(missing.values()) == 0, f"Missing source cells: {filename}")
    require(sum(nonfinite.values()) == 0, f"Nonfinite source cells: {filename}")
    details = {}
    for name in [*DEMAND_COLUMNS, "solar_generation", "outdoor_dry_bulb_temperature"]:
        if name in frame:
            series = frame[name]
            details[name] = {
                "nonzero_steps": int(series.ne(0).sum()),
                "minimum": float(series.min()),
                "maximum": float(series.max()),
                "sum": float(series.sum()),
            }
            if name != "outdoor_dry_bulb_temperature":
                require(series.ge(0).all(), f"Negative demand or PV field {filename}:{name}")
    return {
        "rows": len(frame),
        "column_count": len(frame.columns),
        "columns": list(frame.columns),
        "missing_by_column": missing,
        "nonfinite_by_numeric_column": nonfinite,
        "selected_statistics": details,
    }


def build_dataset(project_root: Path, refresh: bool, offline: bool) -> dict:
    raw_dir = project_root / "data" / "raw"
    processed_dir = project_root / "data" / "processed"
    raw_dir.mkdir(parents=True, exist_ok=True)
    processed_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = project_root / "data" / "manifest.json"
    previous_manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    previous = {item["filename"]: item for item in previous_manifest.get("raw_files", [])}
    schema_record = download_or_verify("schema.json", raw_dir, previous, refresh, offline)
    schema = json.loads((raw_dir / "schema.json").read_text())
    selected = [
        (name, building) for name, building in schema["buildings"].items()
        if building.get("include", True)
    ][:3]
    require([name for name, _ in selected] == EXPECTED_BUILDINGS, "Schema selection has changed")
    require(schema["seconds_per_time_step"] == 3600, "Expected native hourly data")
    require(schema["simulation_start_time_step"] == 0, "Unexpected source start index")
    require(schema["simulation_end_time_step"] == 8759, "Unexpected source end index")
    weather_files = {building["weather"] for _, building in selected}
    require(weather_files == {"weather.csv"}, "Expected one shared weather file")
    file_order = [building["energy_simulation"] for _, building in selected] + ["weather.csv"]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = {
            name: executor.submit(download_or_verify, name, raw_dir, previous, refresh, offline)
            for name in file_order
        }
        downloaded = {name: future.result() for name, future in futures.items()}
    frames = {name: pd.read_csv(raw_dir / name) for name in file_order}
    for filename, frame in frames.items():
        require(len(frame) == 8760, f"Expected 8760 source rows: {filename}")
        downloaded[filename]["audit"] = audit_frame(frame, filename)
    building_frames = [frames[building["energy_simulation"]] for _, building in selected]
    reference = building_frames[0]
    for index, frame in enumerate(building_frames):
        for field in [*CALENDAR_COLUMNS, *DEMAND_COLUMNS, "solar_generation"]:
            require(field in frame, f"Missing required column {field} in building {index}")
        require(
            frame[CALENDAR_COLUMNS].equals(reference[CALENDAR_COLUMNS]),
            f"Building {index} calendar is not aligned",
        )
        for field in DEMAND_COLUMNS:
            require(frame[field].gt(0).any(), f"No positive {field} in building {index}")
    expected_hours = pd.Series([(row % 24) + 1 for row in range(8760)])
    require(reference["hour"].equals(expected_hours), "Source hours are not a repeated 1..24 sequence")
    # The calendar check uses nonleap month lengths, without asserting a UTC date.
    expected_months = []
    for month in range(1, 13):
        expected_months.extend([month] * calendar.monthrange(2018, month)[1] * 24)
    require(reference["month"].tolist() == expected_months, "Unexpected nonleap calendar order")
    weather = frames["weather.csv"]
    require("outdoor_dry_bulb_temperature" in weather, "Outdoor temperature unavailable")
    output = pd.DataFrame({
        "row_index": range(8760),
        "day_index": [row // 24 for row in range(8760)],
        "month": reference["month"],
        "source_hour": reference["hour"],
        "day_type": reference["day_type"],
        "daylight_savings_status": reference["daylight_savings_status"],
    })
    for original, renamed in DEMAND_COLUMNS.items():
        output[renamed] = sum(frame[original] for frame in building_frames)
    output["heating_plus_dhw_kwh_th"] = (
        output["heating_demand_kwh_th"] + output["dhw_demand_kwh_th"]
    )
    output["solar_generation_source_sum"] = sum(
        frame["solar_generation"] for frame in building_frames
    )
    output["outdoor_temperature_c"] = weather["outdoor_dry_bulb_temperature"]
    require(output.notna().all().all(), "Aggregation introduced missing data")
    require(output["solar_generation_source_sum"].eq(0).all(), "Frozen raw PV assumption changed")
    output_path = processed_dir / "community_hourly.csv"
    # Fifteen significant digits preserve the source resolution while giving a stable CSV.
    temporary_output = output_path.with_suffix(".csv.tmp")
    output.to_csv(temporary_output, index=False, float_format="%.15g", lineterminator="\n")
    temporary_output.replace(output_path)
    raw_records = [schema_record] + [downloaded[name] for name in file_order]
    aggregate_stats = {
        field: {
            "sum": float(output[field].sum()),
            "maximum": float(output[field].max()),
            "minimum": float(output[field].min()),
            "nonzero_steps": int(output[field].ne(0).sum()),
        }
        for field in [*DEMAND_COLUMNS.values(), "heating_plus_dhw_kwh_th", "solar_generation_source_sum"]
    }
    manifest = {
        "manifest_format": "j25-data-audit-1.0",
        "generated_utc": utc_now(),
        "source": {
            "repository": REPO_URL,
            "version_tag": VERSION,
            "dataset": DATASET,
            "base_url": BASE_URL,
            "selection_rule": "First three included buildings in schema insertion order",
            "schema_building_count": len(schema["buildings"]),
            "native_seconds_per_time_step": schema["seconds_per_time_step"],
            "source_simulation_start_time_step": schema["simulation_start_time_step"],
            "source_simulation_end_time_step": schema["simulation_end_time_step"],
            "observation_type": "ResStock-derived building simulation profiles; not raw meter measurements",
            "upstream_doi": "10.25984/1876417",
            "citylearn_v2_paper_doi": "10.1080/19401493.2024.2418813",
            "complete_citylearn_environment": False,
        },
        "selected_buildings": [
            {"name": name, "energy_simulation": b["energy_simulation"],
             "schema_assets": {field: b.get(field) for field in ASSET_FIELDS},
             "dynamics_type": (b.get("dynamics") or {}).get("type")}
            for name, b in selected
        ],
        "raw_files": raw_records,
        "processed_file": {
            "path": "data/processed/community_hourly.csv",
            "sha256": digest(output_path.read_bytes()),
            "byte_count": output_path.stat().st_size,
            "rows": len(output),
            "column_count": len(output.columns),
            "columns": list(output.columns),
            "units": UNIT_MAP,
            "missing_cells": int(output.isna().sum().sum()),
            "aggregate_statistics": aggregate_stats,
        },
        "validation": {
            "raw_sha256_matches_frozen_expected_values": True,
            "three_building_calendars_aligned": True,
            "hour_sequence_1_through_24_repeated": True,
            "nonleap_calendar_month_sequence": True,
            "all_raw_csv_cells_present_and_numeric_cells_finite": True,
            "all_selected_buildings_have_positive_each_demand_channel": True,
            "raw_pv_nonzero_steps": 0,
            "row_336": {"day_index": 14, "month": 1, "source_hour": 1},
            "row_1080": {"day_index": 45, "month": 2, "source_hour": 1},
            "no_imputation_resampling_or_timestamp_conversion": True,
        },
        "licensing_and_attribution": {
            "citylearn_software": {
                "license": "MIT",
                "source_url": SOURCE_CODE_BASE + "LICENSE",
                "copyright": "2020 Jose Ramon Vazquez-Canteli, Intelligent Environments Laboratory",
                "verification": "Pinned repository LICENSE inspected on 2026-11-03",
            },
            "upstream_eulp_data": {
                "license": "CC BY 4.0",
                "license_url": "https://creativecommons.org/licenses/by/4.0/",
                "metadata_url": "https://catalog.data.gov/dataset/end-use-load-profiles-for-the-u-s-building-stock",
                "dataset_url": "https://data.openei.org/submissions/4520",
                "doi": "10.25984/1876417",
                "attribution": "NREL End-Use Load Profiles / ResStock; CityLearn project preprocessing and dataset distribution",
                "verification": "Official DOE Data.gov metadata license and public access fields inspected on 2026-11-03",
            },
            "scope_note": (
                "Software licensing and upstream data licensing are separate. Preserve upstream and "
                "CityLearn attribution. This audit does not infer a new license for separately generated assets."
            ),
        },
        "source_references": {
            "dataset_documentation": "https://www.citylearn.net/overview/dataset.html",
            "observation_units": "https://www.citylearn.net/guides/observations_reference.html",
            "raw_energy_simulation_units": SOURCE_CODE_BASE + "citylearn/data.py",
            "pv_conversion_implementation": SOURCE_CODE_BASE + "citylearn/energy_model.py",
            "pv_autosizing_implementation": SOURCE_CODE_BASE + "citylearn/building.py",
            "resstock_data_documentation": "https://resstock.nlr.gov/datasets",
        },
        "limitations": [
            "These are simulated ResStock-derived profiles, not measured field dispatch or household meter data.",
            "Only three buildings from one neighborhood and one annual source record are selected for a pilot.",
            "Hourly values remain hourly; no 15-minute or subhourly claim is supported.",
            "Raw solar_generation is all zero. The schema requests PV autosizing, which was not run. No PV energy output is available in this audit.",
            "Raw solar_generation convention is W/kW for default per_kw PV mode, whereas simulator solar observations are converted kWh/step.",
            "All selected buildings lack source pricing and carbon profiles. Any pilot tariff or carbon signal must be explicitly modeled and separately sourced.",
            "All selected buildings have null heating/cooling storage; DHW storage is null in building 112208 but autosized in buildings 116582 and 134804.",
            "Battery/PV/autosized assets in schema do not supply audited numerical equipment capacities. The downloaded subset is not a runnable complete CityLearn environment.",
            "LSTM dynamics, weather.epw and PV autosizing assets were not downloaded or executed; annual demand availability is not an annual comfort-dynamics validation.",
            "Fixed thermal demand cannot establish indoor-temperature or comfort guarantees. A separate physical model and validation are needed.",
            "Heating plus DHW is a modeled aggregate service demand; one common heat bus assumes temperature compatibility not established by this dataset.",
            "Source hour labels and month lengths are preserved; no exact UTC timestamps, timezone conversion, or daylight-saving resolution are asserted.",
            "Full annual observed profiles are available for replay only; a controller must not access future actuals. No source weather forecast columns enter the processed CSV.",
            "No missing values were filled. Data byte identity is frozen by SHA256; tag availability alone is not the reproducibility guarantee.",
        ],
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, allow_nan=False) + "\n")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--project-root", type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--refresh", action="store_true", help="Download and recheck all public raw files")
    mode.add_argument("--offline", action="store_true", help="Use local pinned files without network access")
    args = parser.parse_args()
    manifest = build_dataset(args.project_root.resolve(), args.refresh, args.offline)
    print(json.dumps({
        "status": "validated",
        "rows": manifest["processed_file"]["rows"],
        "columns": manifest["processed_file"]["column_count"],
        "processed_sha256": manifest["processed_file"]["sha256"],
        "raw_pv_nonzero_steps": manifest["validation"]["raw_pv_nonzero_steps"],
        "manifest": str(args.project_root.resolve() / "data" / "manifest.json"),
    }, indent=2))


if __name__ == "__main__":
    main()
