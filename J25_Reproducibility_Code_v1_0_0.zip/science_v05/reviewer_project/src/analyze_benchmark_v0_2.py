"""Independent saved-output analysis. Does not call the controller or solver."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('result_dir'); args=ap.parse_args()
    out = Path(args.result_dir)
    if (out/'analysis_summary.json').exists():
        raise FileExistsError('Analysis outputs exist; retain original analysis')
    config=json.loads((ROOT/'configs/benchmark_v0_2.json').read_text())
    d=pd.read_csv(out/'all_decisions.csv'); actions=pd.read_csv(out/'executed_actions.csv')
    plants=json.loads((out/'plant_parameters.json').read_text())
    manifest=json.loads((ROOT/config['cohort_manifest']).read_text())
    inputs={x['building_id']:pd.read_csv(ROOT/x['path']) for x in manifest['files']}
    weather=pd.read_csv(ROOT/'data/raw/weather.csv').outdoor_dry_bulb_temperature.to_numpy()
    # Reconstruct physical balances directly from raw demand and executed logs.
    errors=[]; violations=[]; grid={}; unmet=0.; continuity=[]
    for a in actions.itertuples():
        raw=inputs[a.building_id].iloc[a.origin]
        cop=float(np.clip(.25*(45+273.15)/(45-weather[a.origin]),1,5))
        p=plants[str(a.buildings)]; b=next(i for i,x in enumerate(manifest['files'][:a.buildings]) if x['building_id']==a.building_id)
        es=.998*a.space_start+a.hp_heat+a.aux_heat+a.unmet_space-raw.heating_demand
        ew=.996*a.dhw_start+a.dhw_heat+a.unmet_dhw-raw.dhw_demand
        errors.extend([abs(es-a.space_end),abs(ew-a.dhw_end)])
        violations.extend([0.,-a.hp_heat,-a.aux_heat,-a.dhw_heat,-a.unmet_space,-a.unmet_dhw,
            a.hp_heat-p['hp_el'][b]*cop,a.aux_heat-p['aux'][b],a.dhw_heat-p['dhw'][b],
            -a.space_end,-a.dhw_end,a.space_end-p['cap'][0],a.dhw_end-p['cap'][1],
            a.unmet_space-raw.heating_demand,a.unmet_dhw-raw.dhw_demand,
            abs(a.hp_heat+a.aux_heat+a.unmet_space-raw.heating_demand)-p['cap'][0],
            abs(a.dhw_heat+a.unmet_dhw-raw.dhw_demand)-p['cap'][1]])
        k=(a.buildings,a.scenarios,a.episode,a.origin)
        grid[k]=grid.get(k,0.)+raw.non_shiftable_load+raw.cooling_demand/3+a.hp_heat/cop+a.aux_heat+a.dhw_heat
        unmet+=a.unmet_space+a.unmet_dhw
    grid_error=[]
    roll=d[d.phase=='rollout']
    for a in roll.itertuples():
        g=grid[(a.buildings,a.scenarios,a.episode,a.origin)]
        grid_error.append(abs(g-a.grid_kwh));violations.append(g-plants[str(a.buildings)]['feeder'])
    for key,g in actions.groupby(['buildings','scenarios','episode','building_id']):
        g=g.sort_values('origin'); p=plants[str(key[0])]
        continuity += [abs(g.iloc[0].space_start-p['cap'][0]/2),abs(g.iloc[0].dhw_start-p['cap'][1]/2)]
        continuity += np.abs(g.space_start.to_numpy()[1:]-g.space_end.to_numpy()[:-1]).tolist()
        continuity += np.abs(g.dhw_start.to_numpy()[1:]-g.dhw_end.to_numpy()[:-1]).tolist()
    donor_ok=True; nominal_ok=True; audit_count=0
    with (out/'forecast_audit.jsonl').open() as f:
        for line in f:
            a=json.loads(line);audit_count+=1
            nominal_ok &= a['nominal_sources'][0]==a['origin']
            nominal_ok &= all(s==t-24 and s<a['origin'] for s,t in zip(a['nominal_sources'][1:],a['targets'][1:]))
            donor_ok &= all(24<=x<336 for block in a['residual_donor_rows'] for x in block)
    original=json.loads((ROOT/'PACKAGE_MANIFEST.json').read_text())
    # Original verifier remains the authoritative pilot integrity command.
    import subprocess,sys
    verification=subprocess.run([sys.executable,str(ROOT/'verify_package.py')],cwd=ROOT,capture_output=True,text=True,check=True)
    (out/'original_package_verification.json').write_text(verification.stdout)
    snapshots=d[d.phase=='snapshot']; groups=[]
    for keys,g in snapshots.groupby(['buildings','scenarios','method']):
        groups.append(dict(zip(['buildings','scenarios','method'],keys))|{
            'calls':len(g),'p50_seconds':g.decision_seconds.median(),'p95_seconds':g.decision_seconds.quantile(.95),
            'p99_seconds':g.decision_seconds.quantile(.99),'max_seconds':g.decision_seconds.max(),
            'solver_p50_seconds':g.solver_seconds.median(),'basis_reuse_count':int(g.basis_reused.sum()),
            'variables':int(g.variables.max()),'constraints':int(g.constraints.max()),
            'max_matrix_violation':g.max_matrix_violation.max(),'optimal_count':int((g.status=='Optimal').sum())})
    pd.DataFrame(groups).to_csv(out/'snapshot_comparison.csv',index=False)
    realized=[]
    for keys,g in roll.groupby(['buildings','scenarios','episode']):
        realized.append(dict(zip(['buildings','scenarios','episode'],keys))|{
            'energy_cost':g.energy_cost.sum(),'grid_kwh':g.grid_kwh.sum(),'unmet_kwh_th':g.unmet_kwh_th.sum(),
            'terminal_deviation_kwh_th':g.terminal_deviation.sum(),'max_balance_residual':g.max_balance_residual.max(),
            'max_bound_violation':g.max_bound_violation.max(),'p50_seconds':g.decision_seconds.median(),
            'p95_seconds':g.decision_seconds.quantile(.95),'p99_seconds':g.decision_seconds.quantile(.99),
            'max_seconds':g.decision_seconds.max(),'fallback_count':int(g.fallback.sum()),
            'basis_reuse_count':int(g.basis_reused.sum()),'binding_executed_steps':int((g.feeder_headroom_kw<1e-6).sum())})
    pd.DataFrame(realized).to_csv(out/'realized_comparison.csv',index=False)
    agreement=snapshots.groupby(['buildings','scenarios','origin','repeat']).objective.agg(['max','min'])
    agreement['spread']=agreement['max']-agreement['min']
    audit={'decision_records':len(d),'executed_community_decisions':len(roll),'per_building_actions':len(actions),
           'forecast_audits':audit_count,'nominal_forecast_causal':bool(nominal_ok),'residual_rows_calibration_only':bool(donor_ok),
           'independent_max_thermal_residual':float(max(errors)),'independent_max_grid_residual':float(max(grid_error)),
           'independent_max_bound_violation':float(max(violations)),
           'independent_max_state_continuity_error':float(max(continuity)),
           'independent_total_unmet_kwh_th':float(unmet),'original_package_integrity':True,
           'max_snapshot_objective_spread_across_algorithms':float(agreement.spread.max()),
           'max_matrix_violation_all_decisions':float(d.max_matrix_violation.max())}
    audit['passed']=bool(len(d)==688 and len(roll)==288 and nominal_ok and donor_ok and
        max(errors+grid_error+violations+continuity)<1e-6 and agreement.spread.max()<1e-5)
    (out/'independent_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    summary={'status_counts':d.status.value_counts().to_dict(),'all_decisions':len(d),
             'snapshot_calls':len(snapshots),'rollout_calls':len(roll),'sensitivity_calls':int((d.phase=='feeder_sensitivity').sum()),
             'fallback_count':int(d.fallback.sum()),'total_decision_wall_seconds':float(d.decision_seconds.sum()),
             'total_process_cpu_seconds':float(d.cpu_seconds.sum()),
             'all_decision_max_seconds':float(d.decision_seconds.max()),
             'diagnostic_deadline_exceedances':{str(t):int((d.decision_seconds>t).sum()) for t in config['diagnostic_deadline_seconds']},
             'declared_planning_budget_seconds':config['decision_budget_seconds'],
             'largest_snapshot_variables':int(snapshots.variables.max()),'largest_snapshot_constraints':int(snapshots.constraints.max()),
             'predicted_expected_unmet_max_kwh_th':float(d.predicted_expected_unmet_kwh_th.max()),
             'predicted_expected_terminal_deviation_max_kwh_th':float(d.predicted_expected_terminal_deviation_kwh_th.max()),
             'executed_total_unmet_kwh_th':float(roll.unmet_kwh_th.sum()),
             'executed_total_terminal_deviation_kwh_th':float(roll.terminal_deviation.sum()),
             'gate':'NO GO for effort-predictor training on this benchmark: conventional optimization remains well within the declared hourly planning budget; no matched-compute learning benefit established',
             'statistical_scope':'dependent exploratory development observations only; no inference or population-tail guarantee',
             'audit_passed':audit['passed']}
    (out/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2));print(json.dumps(audit,indent=2))


if __name__=='__main__':main()
