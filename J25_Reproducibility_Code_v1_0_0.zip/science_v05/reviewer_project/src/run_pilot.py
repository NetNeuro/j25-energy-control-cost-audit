"""Run the locally frozen two-day LP pilot; this does not train an ML model.

Run from the project root: python -m src.run_pilot
"""

import argparse
import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy

from src.dispatch import Plant, solve_horizon, rule_action, physical_residuals

PROJECT = Path(__file__).resolve().parents[1]
LOAD_COLUMNS = ("non_shiftable_load_kwh", "heating_plus_dhw_kwh_th",
                "cooling_demand_kwh_th")


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def causal_forecast(data, current_row, horizon, oracle=False):
    if not 1 <= horizon <= 24:
        raise ValueError("Persistence horizon must be in [1, 24] hours.")
    if current_row < 24:
        raise ValueError("At least one complete day of history is required.")
    indices = [current_row+h if oracle or h == 0 else current_row+h-24
               for h in range(horizon)]
    if not oracle and max(indices) > current_row:
        raise AssertionError("A causal prediction requested an unobserved row.")
    values = data.loc[indices, list(LOAD_COLUMNS)].to_numpy(dtype=float)
    return values, indices


def training_only_capacities(data, first_rows=336):
    heat = data.iloc[:first_rows]["heating_plus_dhw_kwh_th"].to_numpy(dtype=float)
    hp = float(np.ceil(np.quantile(heat, 0.9)))
    auxiliary = float(np.ceil(np.max(heat)))
    storage = float(np.ceil(4.0*np.mean(heat)))
    return {"hp_max_kw_th": hp, "auxiliary_max_kw_th": auxiliary,
            "storage_capacity_kwh_th": storage,
            "storage_charge_max_kw_th": hp,
            "storage_discharge_max_kw_th": hp+auxiliary}


def verify_freeze(project, config_path):
    manifest_path = project/"protocol/PILOT_FREEZE.json"
    manifest = json.loads(manifest_path.read_text())
    for entry in manifest["files"]:
        actual = file_sha256(project/entry["path"])
        if actual != entry["sha256"]:
            raise RuntimeError(f"Frozen input changed: {entry['path']}. Do not silently re-freeze after outcomes.")
    if config_path.resolve() != (project/manifest["config_path"]).resolve():
        raise RuntimeError("Requested config is not the locally frozen config.")
    return manifest


def run_episode(data, config, episode, method):
    plant = Plant(**config["plant"])
    start, duration = episode["start_row"], episode["hours"]
    target = config["initial_storage_fraction"]*plant.storage_capacity_kwh_th
    storage = target
    records, predictions = [], []
    prices_by_hour = config["tariff"]["price_by_hour_0_to_23"]
    for local_t in range(duration):
        t = start+local_t
        current = data.iloc[t]
        electric, heat, cool = [float(current[column]) for column in LOAD_COLUMNS]
        hour = int(current["source_hour"])-config["source_hour_offset"]
        price = prices_by_hour[hour]
        controller_started = perf_counter()
        solver_seconds, solver_status, solver_message = 0.0, None, "Rule controller; no solver."
        forecast_objective, forecast_unmet, forecast_terminal = None, None, None
        fallback = False
        horizon = 1 if method == "rule" else min(config["max_horizon_hours"], duration-local_t)
        if method == "rule":
            action = rule_action(plant, electric, heat, cool, storage, target)
            controller_seconds = perf_counter()-controller_started
        else:
            oracle = method == "oracle"
            forecast, source_indices = causal_forecast(data, t, horizon, oracle=oracle)
            future_hours = (data.iloc[t:t+horizon]["source_hour"].astype(int).to_numpy()
                            -config["source_hour_offset"])
            known_prices = np.array([prices_by_hour[h] for h in future_hours])
            result = solve_horizon(plant, forecast[:, 0], forecast[:, 1], forecast[:, 2],
                                   known_prices, storage, target,
                                   time_limit_seconds=config["solver_time_limit_seconds"])
            solver_seconds, solver_status, solver_message = (result.solver_wall_seconds,
                                                             result.status, result.message)
            if result.success:
                action = {"hp_heat_kwh_th": float(result.hp_heat[0]),
                          "auxiliary_heat_kwh_th": float(result.auxiliary_heat[0]),
                          "grid_import_kwh": float(result.grid_import[0]),
                          "unmet_heat_kwh_th": float(result.unmet_heat[0]),
                          "storage_end_kwh_th": float(result.storage[1])}
                forecast_objective = result.objective
                forecast_unmet = float(np.sum(result.unmet_heat))
                forecast_terminal = result.terminal_shortfall+result.terminal_surplus
            else:
                fallback = True
                action = rule_action(plant, electric, heat, cool, storage, target)
            controller_seconds = perf_counter()-controller_started
            # These actual future values are audit-only. They are not passed into
            # the causal solver, which receives only the forecast matrix above.
            for lead, source_index in enumerate(source_indices):
                predictions.append({"episode": episode["name"], "controller": method,
                                    "origin_row": t, "lead_hours": lead,
                                    "prediction_source_row": source_index,
                                    "target_row": t+lead,
                                    "forecast_heat_kwh_th": float(forecast[lead, 1]),
                                    "actual_heat_kwh_th": float(data.iloc[t+lead][LOAD_COLUMNS[1]]),
                                    "forecast_electric_kwh": float(forecast[lead, 0]),
                                    "actual_electric_kwh": float(data.iloc[t+lead][LOAD_COLUMNS[0]]),
                                    "forecast_cooling_kwh_th": float(forecast[lead, 2]),
                                    "actual_cooling_kwh_th": float(data.iloc[t+lead][LOAD_COLUMNS[2]])})
        residuals = physical_residuals(plant, electric, heat, cool, storage, action)
        records.append({"episode": episode["name"], "controller": method,
                        "row_index": t, "episode_hour": local_t, "hour_0_to_23": hour,
                        "electric_load_kwh": electric, "thermal_load_kwh_th": heat,
                        "cooling_load_kwh_th": cool, "illustrative_price": price,
                        "storage_start_kwh_th": storage, **action, **residuals,
                        "energy_cost_illustrative_currency": price*action["grid_import_kwh"],
                        "horizon_hours": horizon, "solver_status": solver_status,
                        "solver_message": solver_message, "fallback_used": fallback,
                        "solver_wall_seconds": solver_seconds,
                        "controller_wall_seconds": controller_seconds,
                        "forecast_objective": forecast_objective,
                        "forecast_total_unmet_kwh_th": forecast_unmet,
                        "forecast_terminal_deviation_kwh_th": forecast_terminal})
        storage = action["storage_end_kwh_th"]
    frame = pd.DataFrame(records)
    terminal_deviation = abs(storage-target)
    unmet_total = float(frame["unmet_heat_kwh_th"].sum())
    operating = float(frame["energy_cost_illustrative_currency"].sum())
    max_balance = float(max(frame["electric_balance_residual_kwh"].abs().max(),
                            frame["thermal_balance_residual_kwh_th"].abs().max()))
    max_bounds = float(frame["max_bound_violation"].max())
    tolerance = config["verification_tolerance"]
    summary = {"episode": episode["name"], "controller": method,
               "steps": duration, "energy_cost_illustrative_currency": operating,
               "augmented_cost": operating+plant.unmet_heat_penalty_per_kwh_th*unmet_total
                                +plant.terminal_penalty_per_kwh_th*terminal_deviation,
               "grid_import_kwh": float(frame["grid_import_kwh"].sum()),
               "hp_heat_kwh_th": float(frame["hp_heat_kwh_th"].sum()),
               "auxiliary_heat_kwh_th": float(frame["auxiliary_heat_kwh_th"].sum()),
               "unmet_heat_kwh_th": unmet_total,
               "terminal_deviation_kwh_th": terminal_deviation,
               "max_absolute_balance_residual": max_balance,
               "max_bound_violation": max_bounds,
               "physically_feasible": bool(max_balance <= tolerance and max_bounds <= tolerance),
               "service_and_terminal_satisfied": bool(unmet_total <= tolerance and terminal_deviation <= tolerance),
               "solver_failure_count": int(frame["fallback_used"].sum()),
               "solver_calls": int(frame["solver_status"].notna().sum()),
               "solver_status_counts": {str(int(k)): int(v) for k, v in frame["solver_status"].value_counts().items()},
               "solver_wall_seconds_total": float(frame["solver_wall_seconds"].sum()),
               "solver_wall_seconds_median": float(frame["solver_wall_seconds"].median()),
               "controller_wall_seconds_total": float(frame["controller_wall_seconds"].sum()),
               "controller_wall_seconds_median": float(frame["controller_wall_seconds"].median())}
    return records, predictions, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/pilot.json")
    parser.add_argument("--output-dir", default="results")
    args = parser.parse_args()
    output = PROJECT/args.output_dir
    if (output/"pilot_summary.json").exists():
        raise FileExistsError("This output already contains a pilot run. Choose a new --output-dir to preserve it.")
    config_path = PROJECT/args.config
    freeze = verify_freeze(PROJECT, config_path)
    config = json.loads(config_path.read_text())
    data = pd.read_csv(PROJECT/config["data_path"])
    if not np.array_equal(data["row_index"].to_numpy(), np.arange(len(data))):
        raise RuntimeError("Expected a complete zero-based, ordered hourly index.")
    if set(data["source_hour"].astype(int).unique()) != set(range(1, 25)):
        raise RuntimeError("Source-hour encoding changed; expected 1..24.")
    sized = training_only_capacities(data, config["sizing_rows"])
    if any(sized[key] != config["plant"][key] for key in sized):
        raise RuntimeError("Frozen plant capacities do not match the declared training-only sizing rule.")
    for episode in config["episodes"]:
        first = data.iloc[episode["start_row"]]
        if int(first["month"]) != episode["expected_month"] or int(first["source_hour"]) != 1:
            raise RuntimeError("Episode's declared source month/hour is inconsistent.")
    started = datetime.now(timezone.utc).isoformat()
    rows, forecasts, summaries = [], [], []
    for episode in config["episodes"]:
        for controller in config["controllers"]:
            step_rows, prediction_rows, summary = run_episode(data, config, episode, controller)
            rows.extend(step_rows)
            forecasts.extend(prediction_rows)
            summaries.append(summary)
    output.mkdir(parents=True, exist_ok=True)
    trajectories = pd.DataFrame(rows)
    trajectories.to_csv(output/"pilot_trajectories.csv", index=False)
    pd.DataFrame(forecasts).to_csv(output/"pilot_forecast_audit.csv", index=False)
    pd.DataFrame(summaries).to_csv(output/"pilot_summary.csv", index=False)
    summary_document = {"label": "Two-day infrastructure pilot; no ML training or Q1 validation",
                        "started_at_utc": started,
                        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
                        "protocol_frozen_at_utc": freeze["frozen_at_utc"],
                        "config_sha256": file_sha256(config_path),
                        "data_sha256": file_sha256(PROJECT/config["data_path"]),
                        "software": {"python": platform.python_version(), "numpy": np.__version__,
                                     "pandas": pd.__version__, "scipy": scipy.__version__,
                                     "solver": "HiGHS via scipy.optimize.linprog; continuous LP"},
                        "platform": platform.platform(), "results": summaries}
    (output/"pilot_summary.json").write_text(json.dumps(summary_document, indent=2)+"\n")
    plot_pilot(trajectories, config, output/"pilot_storage_and_cost.png")
    write_results_report(summary_document, output)
    print(json.dumps(summary_document, indent=2))


def plot_pilot(trajectories, config, path):
    colors = {"rule": "#64748b", "persistence_lp": "#0e7490", "oracle": "#a16207"}
    labels = {"rule": "Causal rule", "persistence_lp": "Causal persistence LP",
              "oracle": "Perfect-future LP oracle"}
    fig, axes = plt.subplots(2, 2, figsize=(11, 6.5), constrained_layout=True)
    for row, episode in enumerate(config["episodes"]):
        for method in config["controllers"]:
            part = trajectories[(trajectories.episode == episode["name"])
                                & (trajectories.controller == method)]
            state = np.concatenate(([part.storage_start_kwh_th.iloc[0]], part.storage_end_kwh_th))
            axes[row, 0].plot(np.arange(len(state)), state, label=labels[method], color=colors[method])
            cumulative = np.concatenate(([0], part.energy_cost_illustrative_currency.cumsum()))
            axes[row, 1].plot(np.arange(len(cumulative)), cumulative, label=labels[method], color=colors[method])
        axes[row, 0].set(title=f"{episode['name']}: thermal storage", ylabel="Stored heat (kWh)")
        axes[row, 1].set(title=f"{episode['name']}: accumulated energy cost", ylabel="Illustrative currency")
        for axis in axes[row, :]:
            axis.set_xlabel("Hours from episode start")
            axis.grid(alpha=0.2)
    axes[0, 0].legend(fontsize=8)
    fig.suptitle("J25 starter pilot — explicit assumed plant and tariff; no learned policy", fontsize=12)
    fig.savefig(path, dpi=160)
    plt.close(fig)


def write_results_report(document, output):
    lines = ["# Actual starter-pilot results", "",
             "This is a two-day infrastructure check on public, simulated ResStock-derived profiles. "
             "It is not a reproduction of J25, a learned-method result, or evidence of Q1 readiness.", "",
             f"Run started: {document['started_at_utc']}", "",
             f"Local protocol freeze: {document['protocol_frozen_at_utc']}. This was not an external preregistration.", "",
             "## Results", "",
             "| Episode | Controller | Energy cost (illustrative currency) | Grid (kWh) | Unmet heat (kWh thermal) | Terminal deviation (kWh thermal) | Max balance residual |",
             "|---|---|---:|---:|---:|---:|---:|"]
    for r in document["results"]:
        lines.append(f"| {r['episode']} | {r['controller']} | {r['energy_cost_illustrative_currency']:.4f} | "
                     f"{r['grid_import_kwh']:.3f} | {r['unmet_heat_kwh_th']:.3g} | "
                     f"{r['terminal_deviation_kwh_th']:.3g} | {r['max_absolute_balance_residual']:.3g} |")
    lines += ["", "## Timing and solver status", "",
              "Timing is one local execution per episode/controller. Initialization, logging and "
              "small problem size can dominate. These observations cannot support a speedup claim.", "",
              "| Episode | Controller | LP calls | Failed LP calls | Total solver seconds | Median solver seconds | Total controller seconds |",
              "|---|---|---:|---:|---:|---:|---:|"]
    for r in document["results"]:
        lines.append(f"| {r['episode']} | {r['controller']} | {r['solver_calls']} | {r['solver_failure_count']} | "
                     f"{r['solver_wall_seconds_total']:.6f} | {r['solver_wall_seconds_median']:.6f} | "
                     f"{r['controller_wall_seconds_total']:.6f} |")
    lines += ["", "## What was compared", "",
              "- `rule`: current measured loads; heat pump first, resistance backup second; restore 50% tank energy each hour subject to capacity limits.",
              "- `persistence_lp`: current measured loads plus the previous day's value for future hours. A continuous LP is re-solved hourly, with the horizon shortened at the episode boundary.",
              "- `oracle`: identical LP and plant, but supplied actual future loads. It is a separately labelled information bound, not an operationally fair forecasting comparator.",
              "- Each episode starts with the same half-full tank and has the same soft end-of-episode target. Unmet heat and terminal deviations have explicit large penalties and are also reported separately.",
              "- Each model represents electricity, combined space heat/DHW, fixed-COP cooling, and a single aggregate heat buffer. The buffer, tariff, COPs and capacities are study assumptions. No PV, battery, gas network, temperature/comfort dynamics, or discrete device commitment is simulated.",
              "", "## Limits and next steps", "",
              "Two preselected winter days and one three-home community cannot establish generalization, "
              "seasonal robustness, statistical significance, computational advantage, or a submission-grade contribution. "
              "The fixed COP and aggregate heat-bus treatment simplify DHW temperature requirements and heat-pump physics. "
              "Prices are an illustrative TOU experiment, not observed local tariffs. Public source profiles are simulated, not measured.", "",
              "Next: verify the chosen paper and closest prior art; choose a credible physical benchmark; freeze a full "
              "multi-season, multi-community split; add strong causal forecasts and optimized solver baselines; "
              "then implement and evaluate a precisely specified learned accelerator. A discrete mixed-integer model "
              "should only be introduced when genuine equipment constraints require it.", "",
              "## Reproduction", "",
              "From the project root, run `python -m unittest discover -s tests -v` and then "
              "`python -m src.run_pilot --output-dir results/reproduction`. The runner checks frozen input hashes. "
              "Numerical results should agree to solver tolerance; runtime values will vary. Keep the initial result "
              "files when adding future experiments.", "",
              "Evidence files: `pilot_summary.json`, `pilot_summary.csv`, `pilot_trajectories.csv`, "
              "`pilot_forecast_audit.csv`, and `pilot_storage_and_cost.png`.", ""]
    report = PROJECT/"docs/PILOT_RESULTS.md"
    # Reproductions write their report alongside their outputs, preserving the
    # original report, which is written only by the initial default run.
    if output.resolve() != (PROJECT/"results").resolve():
        report = output/"PILOT_RESULTS.md"
    report.write_text("\n".join(lines))


if __name__ == "__main__":
    main()
