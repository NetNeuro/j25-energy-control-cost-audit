"""Transparent continuous electricity/heat dispatch for a small pilot.

This module is deliberately an LP: it contains no commitment, minimum-up-time,
temperature dynamics, network flow, battery, or learned policy. All quantities
refer to one-hour intervals, so kWh/interval and average kW are numerically equal.
"""

from dataclasses import dataclass
from time import perf_counter
from typing import Optional

import numpy as np
from scipy.optimize import linprog


@dataclass(frozen=True)
class Plant:
    hp_max_kw_th: float
    auxiliary_max_kw_th: float
    storage_capacity_kwh_th: float
    storage_charge_max_kw_th: float
    storage_discharge_max_kw_th: float
    storage_hourly_loss_fraction: float = 0.002
    heating_cop: float = 3.0
    cooling_cop: float = 3.0
    unmet_heat_penalty_per_kwh_th: float = 1000.0
    terminal_penalty_per_kwh_th: float = 1000.0

    def __post_init__(self):
        capacities = (self.hp_max_kw_th, self.auxiliary_max_kw_th,
                      self.storage_capacity_kwh_th, self.storage_charge_max_kw_th,
                      self.storage_discharge_max_kw_th)
        if min(capacities) < 0 or not all(np.isfinite(capacities)):
            raise ValueError("Capacities must be finite and nonnegative.")
        if not 0 <= self.storage_hourly_loss_fraction < 1:
            raise ValueError("Hourly storage loss must be in [0, 1).")
        if self.heating_cop <= 0 or self.cooling_cop <= 0:
            raise ValueError("COP must be positive.")


@dataclass
class HorizonSolution:
    success: bool
    status: int
    message: str
    solver_wall_seconds: float
    objective: Optional[float] = None
    hp_heat: Optional[np.ndarray] = None
    auxiliary_heat: Optional[np.ndarray] = None
    grid_import: Optional[np.ndarray] = None
    unmet_heat: Optional[np.ndarray] = None
    storage: Optional[np.ndarray] = None
    terminal_shortfall: Optional[float] = None
    terminal_surplus: Optional[float] = None
    iterations: Optional[int] = None


def solve_horizon(plant, electric_load, thermal_load, cooling_load, prices,
                  initial_storage, terminal_target, time_limit_seconds=10.0,
                  allow_unmet_heat=True, soft_terminal=True):
    """Solve a shared physical model using scipy.linprog(method='highs').

    The tank's net charging power is hp + auxiliary + unmet - thermal_load.
    Ideal tank charge/discharge efficiencies are one; standing loss is explicit.
    Heat shortfall and end-target deviations are penalized and returned, never
    silently treated as fulfilled demand or a satisfied end target.
    """
    e, heat, cool, price = [np.asarray(x, dtype=float) for x in
                            (electric_load, thermal_load, cooling_load, prices)]
    n = len(heat)
    if n < 1 or any(x.shape != (n,) for x in (e, heat, cool, price)):
        raise ValueError("All horizon inputs must be nonempty, equal-length vectors.")
    if any(not np.all(np.isfinite(x)) for x in (e, heat, cool, price)):
        raise ValueError("Horizon inputs must be finite.")
    if any(np.any(x < 0) for x in (e, heat, cool, price)):
        raise ValueError("This pilot supports nonnegative loads and import prices.")
    if not 0 <= initial_storage <= plant.storage_capacity_kwh_th:
        raise ValueError("Initial storage is outside physical bounds.")
    if not 0 <= terminal_target <= plant.storage_capacity_kwh_th:
        raise ValueError("Terminal target is outside physical bounds.")

    # Variable blocks: hp[n], auxiliary[n], grid[n], unmet[n], E_next[n],
    # followed by nonnegative terminal shortfall and surplus.
    hp, aux, grid, unmet, stock = [np.arange(k*n, (k+1)*n) for k in range(5)]
    terminal_short, terminal_extra = 5*n, 5*n+1
    c = np.zeros(5*n+2)
    c[grid] = price
    c[unmet] = plant.unmet_heat_penalty_per_kwh_th
    c[[terminal_short, terminal_extra]] = plant.terminal_penalty_per_kwh_th
    eq = np.zeros((2*n+1, len(c)))
    rhs = np.zeros(2*n+1)
    retention = 1-plant.storage_hourly_loss_fraction
    for t in range(n):
        eq[t, grid[t]] = 1
        eq[t, hp[t]] = -1/plant.heating_cop
        eq[t, aux[t]] = -1
        rhs[t] = e[t] + cool[t]/plant.cooling_cop
        eq[n+t, stock[t]] = 1
        eq[n+t, hp[t]] = -1
        eq[n+t, aux[t]] = -1
        eq[n+t, unmet[t]] = -1
        rhs[n+t] = -heat[t]
        if t == 0:
            rhs[n+t] += retention*initial_storage
        else:
            eq[n+t, stock[t-1]] = -retention
    eq[-1, stock[-1]] = 1
    eq[-1, terminal_short] = 1
    eq[-1, terminal_extra] = -1
    rhs[-1] = terminal_target

    ub = np.zeros((2*n, len(c)))
    ub_rhs = np.zeros(2*n)
    for t in range(n):
        ub[t, [hp[t], aux[t], unmet[t]]] = 1
        ub_rhs[t] = heat[t] + plant.storage_charge_max_kw_th
        ub[n+t, [hp[t], aux[t], unmet[t]]] = -1
        ub_rhs[n+t] = plant.storage_discharge_max_kw_th - heat[t]
    bounds = ([(0, plant.hp_max_kw_th)]*n
              + [(0, plant.auxiliary_max_kw_th)]*n
              + [(0, None)]*n
              + [(0, float(v) if allow_unmet_heat else 0) for v in heat]
              + [(0, plant.storage_capacity_kwh_th)]*n
              + [(0, None if soft_terminal else 0)]*2)
    started = perf_counter()
    result = linprog(c, A_ub=ub, b_ub=ub_rhs, A_eq=eq, b_eq=rhs,
                     bounds=bounds, method="highs",
                     options={"time_limit": time_limit_seconds,
                              "primal_feasibility_tolerance": 1e-8,
                              "dual_feasibility_tolerance": 1e-8})
    elapsed = perf_counter()-started
    if not result.success:
        return HorizonSolution(False, int(result.status), str(result.message), elapsed)
    x = result.x
    return HorizonSolution(True, int(result.status), str(result.message), elapsed,
                           float(result.fun), x[hp], x[aux], x[grid], x[unmet],
                           np.concatenate(([initial_storage], x[stock])),
                           float(x[terminal_short]), float(x[terminal_extra]),
                           int(result.nit))


def rule_action(plant, electric_load, thermal_load, cooling_load, storage,
                storage_target):
    """Causal heat-first rule: restore the same fixed tank target every hour.

    Heat pump is used before resistance heat. Limits are enforced explicitly.
    Demand that cannot be served is returned as unmet heat. This rule sees only
    the current observation and the prescribed target, not future data or prices.
    """
    retained = (1-plant.storage_hourly_loss_fraction)*storage
    desired = max(0.0, thermal_load + storage_target - retained)
    charge_room = min(plant.storage_charge_max_kw_th,
                      plant.storage_capacity_kwh_th-retained)
    output = min(desired, plant.hp_max_kw_th+plant.auxiliary_max_kw_th,
                 thermal_load+max(0.0, charge_room))
    hp = min(output, plant.hp_max_kw_th)
    auxiliary = output-hp
    available_discharge = min(plant.storage_discharge_max_kw_th, retained)
    unmet = max(0.0, thermal_load-output-available_discharge)
    next_storage = retained+output+unmet-thermal_load
    grid = electric_load+cooling_load/plant.cooling_cop+hp/plant.heating_cop+auxiliary
    return {"hp_heat_kwh_th": hp, "auxiliary_heat_kwh_th": auxiliary,
            "grid_import_kwh": grid, "unmet_heat_kwh_th": unmet,
            "storage_end_kwh_th": next_storage}


def physical_residuals(plant, electric_load, thermal_load, cooling_load,
                       storage_start, action):
    """Independent accounting of balances and maximum bound violations."""
    hp = action["hp_heat_kwh_th"]
    auxiliary = action["auxiliary_heat_kwh_th"]
    unmet = action["unmet_heat_kwh_th"]
    grid = action["grid_import_kwh"]
    end = action["storage_end_kwh_th"]
    net_charge = hp+auxiliary+unmet-thermal_load
    electric_residual = grid-electric_load-cooling_load/plant.cooling_cop-hp/plant.heating_cop-auxiliary
    thermal_residual = end-(1-plant.storage_hourly_loss_fraction)*storage_start-net_charge
    violations = [0.0, -hp, hp-plant.hp_max_kw_th, -auxiliary,
                  auxiliary-plant.auxiliary_max_kw_th, -grid, -unmet,
                  unmet-thermal_load, -end, end-plant.storage_capacity_kwh_th,
                  net_charge-plant.storage_charge_max_kw_th,
                  -net_charge-plant.storage_discharge_max_kw_th]
    return {"electric_balance_residual_kwh": electric_residual,
            "thermal_balance_residual_kwh_th": thermal_residual,
            "max_bound_violation": max(violations),
            "net_storage_charge_kwh_th": net_charge,
            "standing_loss_kwh_th": plant.storage_hourly_loss_fraction*storage_start}
