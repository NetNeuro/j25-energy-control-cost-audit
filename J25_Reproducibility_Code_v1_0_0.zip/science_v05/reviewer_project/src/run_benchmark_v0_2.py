"""Run predeclared development experiments without overwriting any prior run."""
import argparse
import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import highspy
import numpy as np
import pandas as pd
import scipy

from .benchmark_v0_2 import ROOT, digest, load_inputs, size_plant, decision


def stamp():
    return datetime.now(timezone.utc).isoformat()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output-dir', required=True)
    ap.add_argument('--config', default='configs/benchmark_v0_2.json')
    args = ap.parse_args()
    out = Path(args.output_dir)
    if out.exists():
        raise FileExistsError('Use a fresh result directory; previous attempts are retained')
    freeze = json.loads((ROOT/'protocol/BENCHMARK_FREEZE_v0_2.json').read_text())
    for item in freeze['files']:
        if digest(ROOT/item['path']) != item['sha256']:
            raise ValueError('Frozen input changed: '+item['path'])
    config = json.loads((ROOT/args.config).read_text())
    if args.config != freeze['config']:
        raise ValueError('Config not covered by this freeze')
    out.mkdir(parents=True)
    context = {'started_at_utc': stamp(), 'protocol_frozen_at_utc': freeze['frozen_at_utc'],
               'config_sha256': digest(ROOT/args.config), 'argv': sys.argv,
               'python': sys.version, 'numpy': np.__version__, 'pandas': pd.__version__,
               'scipy': scipy.__version__, 'highspy': highspy.Highs().version(),
               'platform': platform.platform(), 'cpu_count': os.cpu_count(),
               'cpu_affinity': sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else None,
               'cpu_model': next((x.split(':', 1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines()
                                  if x.startswith('model name')), 'unknown'),
               'solver_threads': 1, 'data_loading_timed_separately': True,
               'timing_scope': 'resident input arrays through forecasts, sparse assembly, solver setup/run, full matrix audit, independent first-action check and fallback; excludes output serialization and process import'}
    t = perf_counter(); data = load_inputs(config); context['data_load_seconds'] = perf_counter()-t
    (out/'run_context.json').write_text(json.dumps(context, indent=2)+'\n')
    plants = {B: size_plant(data, config, B) for B in config['building_counts']}
    (out/'plant_parameters.json').write_text(json.dumps({str(B): {k: v.tolist() if isinstance(v, np.ndarray) else v for k,v in p.items()} for B,p in plants.items()}, indent=2)+'\n')
    rows, forecasts = [], []
    with (out/'decision_records.jsonl').open('w') as log, (out/'forecast_audit.jsonl').open('w') as fa:
        def record(row, evidence):
            log.write(json.dumps(row, allow_nan=False)+'\n'); log.flush()
            fa.write(json.dumps(evidence)+'\n'); fa.flush()
        # Balanced method order prevents a permanently cold first comparator.
        for B, plant in plants.items():
            for S in config['scenario_counts']:
                for repeat in range(config['timing_repeats']):
                    bases = {}
                    for oi, origin in enumerate(config['snapshot_origins']):
                        methods = config['solver_methods']
                        shift = (oi+repeat)%len(methods)
                        for method in methods[shift:]+methods[:shift]:
                            row, _, _, basis, evidence = decision(data, config, origin, 24, plant,
                                np.tile(plant['cap']*config['initial_fraction'], (B, 1)), S, method, bases.get(method))
                            bases[method] = basis
                            row.update({'phase': 'snapshot', 'repeat': repeat, 'episode': ''})
                            record(row, evidence); rows.append(row)
                print(f'Snapshots complete B={B} S={S}', flush=True)
        df = pd.DataFrame(rows)
        # Only development snapshots select algorithm; never test outcomes.
        eligible = df[(df.buildings == max(plants)) & (df.scenarios == max(config['scenario_counts']))]
        scored = []
        for method, group in eligible.groupby('method'):
            if (group.status == 'Optimal').all() and group.max_matrix_violation.max() <= config['tolerance']:
                scored.append((float(group.decision_seconds.quantile(.95)), method))
        if not scored:
            raise RuntimeError('No eligible conventional optimizer; retain all attempted records')
        selected = min(scored)[1]
        (out/'selected_optimizer.json').write_text(json.dumps({'selection': 'lowest development p95 complete decision time at largest declared instance size among fully optimal audited methods',
            'selected_method': selected, 'scores': scored, 'selected_at_utc': stamp(), 'confirmatory_selection': False}, indent=2)+'\n')
        actions = []
        for B, plant in plants.items():
            for S in config['scenario_counts']:
                for episode in config['episodes']:
                    state = np.tile(plant['cap']*config['initial_fraction'], (B, 1))
                    basis = None
                    for step in range(episode['hours']):
                        origin = episode['start_row']+step
                        row, end, action, basis, evidence = decision(data, config, origin, episode['hours']-step,
                            plant, state, S, selected, basis)
                        row.update({'phase': 'rollout', 'repeat': 0, 'episode': episode['name'],
                                    'energy_cost': row['grid_kwh']*config['tariff'][int(data['hours'][origin])],
                                    'terminal_deviation': float(np.abs(end-plant['cap']*config['initial_fraction']).sum()) if step == episode['hours']-1 else 0.})
                        record(row, evidence); rows.append(row)
                        for b in range(B):
                            actions.append({'origin': origin, 'buildings': B, 'scenarios': S, 'episode': episode['name'],
                                            'building_id': data['ids'][b], 'space_start': state[b,0], 'dhw_start': state[b,1],
                                            **dict(zip(['hp_heat', 'aux_heat', 'dhw_heat', 'unmet_space', 'unmet_dhw', 'space_end', 'dhw_end'], action[b].tolist()))})
                        state = end
                    print(f'Rollout complete B={B} S={S} {episode["name"]}', flush=True)
        # Fixed, predeclared coupling sensitivity; same development snapshots.
        for fraction in config['feeder_sensitivity_fractions']:
            sensitivity = json.loads(json.dumps(config))
            sensitivity['physics']['feeder_connected_load_fraction'] = fraction
            plant = size_plant(data, sensitivity, max(plants))
            for origin in config['snapshot_origins']:
                row, _, _, _, evidence = decision(data, sensitivity, origin, 24, plant,
                    np.tile(plant['cap']*config['initial_fraction'], (max(plants),1)), max(config['scenario_counts']), selected)
                row.update({'phase': 'feeder_sensitivity', 'repeat': 0, 'episode': '', 'feeder_fraction': fraction})
                record(row, evidence); rows.append(row)
        pd.DataFrame(actions).to_csv(out/'executed_actions.csv', index=False)
    pd.DataFrame(rows).to_csv(out/'all_decisions.csv', index=False)
    context['completed_at_utc'] = stamp()
    (out/'run_context.json').write_text(json.dumps(context, indent=2)+'\n')
    print('Complete:', out, flush=True)


if __name__ == '__main__':
    main()
