"""Finite reserve candidates and a learned jointly deliverable service score."""
import copy,json,pickle,time
import numpy as np
from .common import *
from ..study_v0_3.control import lex_solve,add_reserve_witness,matrix_audit
from ..benchmark_v0_2 import build_problem,fallback

FRACTIONS=[0.,.25,.5,.75,1.]

def forecast(d,t,H,model,cache=True):
    key=(t,H)
    if cache:
        lookup=d.setdefault('_forecast_cache',{})
        if key in lookup:return tuple(x.copy() for x in lookup[key])
    y,w=forecast_point(d,t,H,model)
    if cache:lookup[key]=(y.copy(),w.copy())
    return y,w

def min_deficit(load,temp,state,plant,scale):
    """Exact scalar one-step recourse optimum for the common-COP abstract plant.

    Use retained inventory, then more-efficient HP heat, then unit-efficiency
    SH/DHW resistance. Shared electrical headroom couples all homes/services.
    Verified independently against a linear program on random physical states.
    """
    k=float(heating_cop(temp,config(scale)));need=np.maximum(load[:,[1,2]]-state*plant['retention'],0)
    base=float((load[:,0]+load[:,3]/3).sum());el=max(0,plant['feeder']-base)
    hp=np.minimum(need[:,0],plant['hp_el']*k)
    hpheat=min(float(hp.sum()),el*k);remaining=el-hpheat/k
    if hp.sum()>0:hp=hp*(hpheat/hp.sum())
    resistance=float(np.minimum(np.maximum(need[:,0]-hp,0),plant['aux']).sum()+np.minimum(need[:,1],plant['dhw']).sum())
    return float(max(0,need.sum()-hpheat-min(remaining,resistance)))

def solve_plan(y,w,hours,state,plant,scale,reserve=None,upper=None,lower=None):
    c=config(scale);state=np.clip(state,0,plant['cap'])
    if reserve is not None:c['initial_fraction']=0. # minimize inventory above the explicit repair floor
    p=build_problem(y[None] if y.ndim==3 else y,w[None] if w.ndim==1 else w,hours,state,plant,c);p['base_n']=len(p['c'])
    if reserve is not None:p['lo'][p['idx'][0,0,:,5:7].ravel()]=np.asarray(reserve).ravel()
    q=add_reserve_witness(p,upper,lower,plant,c) if upper is not None else p
    x,info=lex_solve(q,c);check=matrix_audit(q,x)
    if x is None or check['max_matrix_violation']>1e-5:return None,info
    return x[p['idx'][0,0]],info

def nominal(d,t,H,state,plant,scale,model,cal,kind='nominal',level=.8,correction=None,cache=True):
    y,w=forecast(d,t,H,model,cache)
    if correction is not None and H>1:y[1:,:,1:3]*=np.asarray(correction)[None,None,:]
    if kind=='scenario':
        yy=np.repeat(y[None],5,axis=0);ww=np.repeat(w[None],5,axis=0)
        donor=cal[d['climate']];order=np.random.default_rng(20261104).permutation(len(donor['donors']))
        for s,idx in enumerate(order[:4],1):
            yy[s]=np.maximum(0,y+donor['donors'][idx,d['hours'][t:t+H]]*d['scales']);ww[s]=w+donor['temp_donors'][idx,d['hours'][t:t+H]]
            yy[s,0]=y[0];ww[s,0]=w[0]
        a,info=solve_plan(yy,ww,d['hours'][t:t+H],state,plant,scale)
    elif kind=='load_reserve' and H>1:
        score=cal[d['climate']]['q'][str(level)];upper=np.maximum(0,y[1]+score*d['scales']);lower=w[1]+cal[d['climate']]['temperature_lower_error']
        a,info=solve_plan(y,w,d['hours'][t:t+H],state,plant,scale,upper=upper,lower=lower)
        if a is None:
            old=info;a,info=solve_plan(y,w,d['hours'][t:t+H],state,plant,scale)
            info['reserve_unavailable']=True;info['native_solves']+=old['native_solves'];info['solver_seconds']+=old['solver_seconds']
    else:a,info=solve_plan(y,w,d['hours'][t:t+H],state,plant,scale)
    if a is None:
        a=fallback(d['loads'][t],d['weather'][t],state,plant,config(scale));info['fallback']=True
    return a,info,y,w

def candidates(d,t,H,state,plant,scale,model,cal,cache=True):
    a,info,y,w=nominal(d,t,H,state,plant,scale,model,cal,cache=cache)
    actions=[a];available=[True];infos=[info];features=[]
    for fraction in FRACTIONS[1:]:
        r=min(fraction,.5) if H<24 else fraction
        target=np.maximum(a[:,5:7],r*plant['cap'])
        if np.all(target<=a[:,5:7]+1e-8):b=a.copy();inf={'native_solves':0,'solver_seconds':0.,'status':'duplicate'}
        else:b,inf=solve_plan(y[:1],w[:1],d['hours'][t:t+1],state,plant,scale,reserve=target)
        ok=b is not None and b[:,3:5].sum()<=a[:,3:5].sum()+1e-5
        available.append(ok);actions.append(b if ok else a.copy());infos.append(inf)
    nexty,nextw=forecast(d,t,2,model,cache)
    for b in actions:features.append(score_features(d,t,b[:,5:7],plant,scale,nexty[1],nextw[1],b))
    return np.array(actions),np.array(available),np.array(features),infos

def score_features(d,t,end,plant,scale,y,w,action=None):
    k=float(heating_cop(w,config(scale)))
    # First six coordinates are monotone non-increasing inventory covariates.
    return np.r_[(end/plant['cap']).ravel(),(y/d['scales']).ravel(),
        (plant['hp_el']*k/plant['cap'][0]),plant['aux']/plant['cap'][0],plant['dhw']/plant['cap'][1],
        (y[:,0]+y[:,3]/3).sum()/plant['feeder'],
        (y[:,0]+y[:,3]/3+y[:,1]/k+y[:,2]).sum()/plant['feeder'],
        float(w)/30,scale,d['hours'][t]/24,
        *[float(d['climate']==c) for c in ['VT','CA','TX']],
        (d['loads'][t]/d['scales']).ravel(),
        (action[:,:3]/np.column_stack([plant['hp_el']*float(heating_cop(d['weather'][t],config(scale))),plant['aux'],plant['dhw']])).ravel() if action is not None else np.zeros(9)]

def choose(actions,available,pred,offset,plant,temp,hour,scale,tolerance):
    upper=np.maximum(0,pred+offset);ok=available & (upper<=tolerance)
    k=float(heating_cop(temp,config(scale)));c=config();cost=[]
    for a in actions:
        electricity=float((a[:,0]/k+a[:,1]+a[:,2]).sum())
        inventory=float((a[:,5]/k+a[:,6]).sum())
        cost.append(c['tariff'][int(hour)]*electricity-.22*inventory)
    cost=np.array(cost)
    if ok.any():j=int(np.argmin(np.where(ok,cost,np.inf)))
    else:
        minimum=np.min(upper[available]);ok=available&(upper<=minimum+1e-6)
        j=int(np.argmin(np.where(ok,cost,np.inf)))
    return j,upper,bool((available&(upper<=tolerance)).any())

class Controller:
    def __init__(self,spec,model,cal,risk=None,risk_cal=None,corrections=None,cache=True):
        self.spec=spec;self.model=model;self.cal=cal;self.risk=risk;self.risk_cal=risk_cal
        self.corrections=corrections;self.observer=EfficiencyObserver();self.feedback=.5;self.cache=cache
    def act(self,d,t,H,state,plant):
        started=time.perf_counter();cpu=time.process_time();method=self.spec['method']
        scale=1. if method in ['nominal','risk_no_adapt'] else self.observer.value
        detail={'method':method,'chosen_candidate':-1,'candidates_available':0,'score_upper':None,'score_prediction':None,
                'risk_accepted':None,'reserve_unavailable':False,'fallback':False}
        if method.startswith('rule'):
            level=float(method[4:])/100
            c=config(scale);c['initial_fraction']=level if H>=24 else .5
            a=fallback(d['loads'][t],d['weather'][t],state,plant,c);infos=[]
        elif method.startswith('risk'):
            aa,avail,X,infos=candidates(d,t,H,state,plant,scale,self.model,self.cal,self.cache)
            pred=np.maximum(self.risk.predict(X),0)
            mode='none' if method=='risk_uncalibrated' else 'marginal' if method=='risk_marginal' else 'simultaneous'
            q=0. if mode=='none' else np.array(self.risk_cal[d['climate']][mode])
            j,upper,accepted=choose(aa,avail,pred,q,plant,d['weather'][t],d['hours'][t],scale,self.spec.get('tolerance',.1))
            a=aa[j];detail.update(chosen_candidate=j,candidates_available=int(avail.sum()),
                score_upper=float(upper[j]),score_prediction=float(pred[j]),risk_accepted=accepted,
                candidate_upper=upper.tolist(),candidate_available=avail.tolist(),candidate_prediction=pred.tolist())
        else:
            kind='scenario' if method=='scenario' else 'load_reserve' if method=='load_reserve' else 'nominal'
            correction=self.corrections[d['climate']] if method=='decision_focused' else None
            a,inf,y,w=nominal(d,t,H,state,plant,scale,self.model,self.cal,kind=kind,
                level=self.spec.get('level',.8),correction=correction,cache=self.cache);infos=[inf]
            detail['fallback']=inf.get('fallback',False);detail['reserve_unavailable']=inf.get('reserve_unavailable',False)
            if method=='feedback':
                r=min(self.feedback,.5) if H<24 else self.feedback
                target=np.maximum(a[:,5:7],r*plant['cap'])
                if np.any(target>a[:,5:7]+1e-8):
                    b,inf=solve_plan(y[:1],w[:1],d['hours'][t:t+1],state,plant,scale,reserve=target);infos.append(inf)
                    if b is not None and b[:,3:5].sum()<=a[:,3:5].sum()+1e-5:a=b
                    else:detail['reserve_unavailable']=True
        detail.update({'estimated_scale':scale,'decision_seconds':time.perf_counter()-started,'cpu_seconds':time.process_time()-cpu,
           'native_solves':sum(i.get('native_solves',0) for i in infos),'solver_seconds':sum(i.get('solver_seconds',0.) for i in infos),
           'solver_statuses':[i.get('status','unknown') for i in infos]})
        return a,detail
    def update(self,row,temp):
        self.observer.update(row,temp)
        self.feedback=float(np.clip(self.feedback+getattr(self,'feedback_gain',.08)*(float(row['unmet_kwh_th']>1e-3)-.05),0,1))
