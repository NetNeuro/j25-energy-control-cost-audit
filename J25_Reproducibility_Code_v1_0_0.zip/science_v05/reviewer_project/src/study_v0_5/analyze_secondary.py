"""Additional same-candidate conventional-score comparison and emulator checks."""
import json
import numpy as np,pandas as pd
from .common import *

def main():
    out=ROOT/'results/study_v0_5/secondary_analysis';out.mkdir(exist_ok=False)
    folder=ROOT/'results/study_v0_5/physical_score_test';rows=[json.loads(p.read_text()) for p in folder.glob('*.summary.json')];assert len(rows)==96
    data=load_data(True);maxres=0.;decisions=0
    for r in rows:
        with np.load(folder/(r['key']+'.npz')) as a:
            assert len(a['records_json'])==168;d=data[r['community']];loads=d['loads'][a['origins']];actions=a['actions'];states=a['states']
            gen=np.stack([actions[:,:,0]+actions[:,:,1],actions[:,:,2]],axis=2)
            residual=states[1:]-a['retention']*states[:-1]-gen-actions[:,:,3:5]+loads[:,:,[1,2]]
            maxres=max(maxres,float(np.abs(residual).max()));decisions+=len(actions)
    df=pd.DataFrame(rows);df.groupby('regime')[['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th','score_checks','score_miscoverages']].sum().to_csv(out/'physical_score_totals.csv')
    primary=pd.read_csv(ROOT/'results/study_v0_5/analysis/episode_results.csv');key=['community','episode','regime']
    a=df.set_index(key);b=primary[primary.method=='proposed'].set_index(key)
    differences={k:float(b[k].sum()-a[k].sum()) for k in ['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']}
    write_json(out/'physical_score_audit.json',{'episodes':len(rows),'decisions':decisions,'max_independent_balance_residual':maxres,'proposed_minus_physical_score_totals':differences,
        'scope':'Prespecified while primary campaign ran, before aggregate outcome inspection; secondary conventional comparator, not a replacement primary endpoint'})
    emu=json.loads((ROOT/'results/study_v0_5/boptest/ALL_RESULTS.json').read_text());pd.DataFrame(emu).to_csv(out/'boptest_results.csv',index=False)
    warm={};viol=0.;n=0
    for r in emu:
        p=ROOT/f'results/study_v0_5/boptest/{r["period"]}__{r["method"]}__{r["regime"]}'
        trajectory=json.loads((p/'trajectory.json').read_text());w=json.loads((p/'warmup.json').read_text())
        assert len(trajectory)==672 and len(w)==672
        assert max(x['command_sum'] for x in trajectory)<=1.8+1e-7
        warm.setdefault(r['period'],[]).append(w[-1]['zone']);n+=len(trajectory)*3;viol=max(viol,r['max_command_budget_violation'])
    warmdiff=max(float(np.abs(np.array(v)-np.array(v)[0]).max()) for v in warm.values())
    write_json(out/'boptest_audit.json',{'coordinated_runs':len(emu),'FMU_instances_per_run':3,'controlled_building_steps':n,
       'max_shared_command_budget_violation':viol,'common_warmup_end_state_max_difference':warmdiff,
       'scope':'Independent SH dynamics with coupled command budget; virtual replicas are not independent field sites, and the command budget is not a firm kW feeder constraint'})
    print(df.groupby('regime')[['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']].sum().to_string())
    print(pd.DataFrame(emu)[['period','method','regime','custom_cost','cold_discomfort_kh','hot_discomfort_kh']].to_string(index=False))
if __name__=='__main__':main()
