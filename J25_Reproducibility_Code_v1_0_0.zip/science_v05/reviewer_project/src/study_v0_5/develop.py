"""Counterfactual service-score fitting and simultaneous calibration, training homes only."""
import json,pickle,time
from sklearn.ensemble import HistGradientBoostingRegressor
from .common import *
from .controller import *

def main():
    out=ROOT/'models/study_v0_5';out.mkdir(exist_ok=True)
    if (out/'service_score.pkl').exists():raise FileExistsError('Model already fitted')
    model,cal=load_models();data=load_data(False);rng=np.random.default_rng(250511);XX=[];YY=[];groups=[];fail=0
    start=time.perf_counter();label_cpu=time.process_time()
    for d in data.values():
        if d['role']!='train':continue
        plant=size_plant(d,config(),3)
        for t in range(28*24,59*24-24,12):
            state=rng.uniform(.05,.95,size=(3,2))*plant['cap'];actual=float(rng.choice([.75,.9,1.,1.1]));estimate=1. if rng.random()<.5 else float(np.clip(actual+rng.normal(0,.08),.65,1.15))
            aa,avail,X,inf=candidates(d,t,24,state,plant,estimate,model,cal)
            for j,a in enumerate(aa):
                if not avail[j]:fail+=1;continue
                _,end,first=execute(d['loads'][t],d['weather'][t],state,a,plant,estimate,actual)
                loss=first['unmet_kwh_th']+min_deficit(d['loads'][t+1],d['weather'][t+1],end,plant,actual)
                XX.append(X[j]);YY.append(loss);groups.append([d['id'],t,j,estimate,actual])
        print('Labels',d['id'],len(YY),flush=True)
    label_cpu=time.process_time()-label_cpu;X=np.array(XX);Y=np.array(YY)
    mono=[-1]*6+[0]*(X.shape[1]-6);tfit=time.process_time()
    risk=HistGradientBoostingRegressor(loss='quantile',quantile=.9,max_iter=100,max_leaf_nodes=15,min_samples_leaf=25,
        l2_regularization=1.,monotonic_cst=mono,random_state=250511)
    risk.fit(X,Y);fit_cpu=time.process_time()-tfit
    with (out/'service_score.pkl').open('wb') as f:pickle.dump(risk,f)
    np.savez_compressed(out/'training_labels.npz',X=X,Y=Y,groups=np.array(groups,dtype=str))
    # Reference-state calibration follows nominal adaptive MPC, with sampled
    # conversion regimes. Counterfactual outcomes for all feasible candidate
    # actions are available because prescribed thermal demand is exogenous here.
    calibration={};calrows=[];tcal=time.process_time()
    for climate in ['VT','CA','TX']:
        residuals=[];availability=[]
        for d in data.values():
            if d['role']!='train' or d['climate']!=climate:continue
            plant=size_plant(d,config(),3);state=np.tile(plant['cap']/2,(3,1));obs=EfficiencyObserver()
            for step,t in enumerate(range(59*24,73*24-1)):
                actual=1. if step<72 else .8
                if step%6==0:
                    aa,avail,features,inf=candidates(d,t,24,state,plant,obs.value,model,cal)
                    pred=np.maximum(risk.predict(features),0);loss=[]
                    for j,a in enumerate(aa):
                        _,end,first=execute(d['loads'][t],d['weather'][t],state,a,plant,obs.value,actual)
                        loss.append(first['unmet_kwh_th']+min_deficit(d['loads'][t+1],d['weather'][t+1],end,plant,actual))
                    res=np.array(loss)-pred;res[~avail]=-np.inf
                    residuals.append(res);availability.append(avail)
                    calrows.append({'community':d['id'],'origin':t,'predicted':pred.tolist(),'loss':loss,'available':avail.tolist()})
                a,inf,_,_=nominal(d,t,24,state,plant,obs.value,model,cal)
                _,state,row=execute(d['loads'][t],d['weather'][t],state,a,plant,obs.value,actual)
                obs.update(row,d['weather'][t])
        residuals=np.array(residuals);availability=np.array(availability)
        def quant(v):
            v=np.sort(np.asarray(v));n=len(v);index=min(n-1,int(np.ceil((n+1)*.9))-1)
            return float(v[max(index,0)])
        marginal=[quant(residuals[availability[:,j],j]) for j in range(5)]
        simultaneous=quant(residuals.max(axis=1))
        calibration[climate]={'marginal':marginal,'simultaneous':simultaneous,'states':len(residuals),
            'alpha':.1,'reference_policy':'adaptive nominal MPC; one persistent .8 conversion shift',
            'coverage_claim':'Empirical reference calibration only; seasonal closed-loop exchangeability not established'}
        print('Calibrated',climate,calibration[climate],flush=True)
    write_json(out/'score_calibration.json',calibration);write_json(out/'calibration_counterfactuals.json',calrows)
    write_json(out/'training_record.json',{'trained_at_utc':stamp(),'rows':len(Y),'features':X.shape[1],
       'labels_positive':int((Y>1e-3).sum()),'max_label_kwh_th':float(Y.max()),'unavailable_training_candidates':fail,
       'label_cpu_seconds':label_cpu,'fit_cpu_seconds':fit_cpu,'calibration_cpu_seconds':time.process_time()-tcal,
       'total_wall_seconds':time.perf_counter()-start,'source_forecaster_sha256':sha(ROOT/'models/study_v0_3/point_forecast.pkl'),
       'training_windows':[28*24,59*24-24],'calibration_windows':[59*24,73*24-1],'roles':['train'],
       'fresh_test_outcomes_seen':False,'seed':250511,'model':'HistGradientBoosting quantile .9,100 iterations,15 leaves,monotone inventory inputs'})
if __name__=='__main__':main()
