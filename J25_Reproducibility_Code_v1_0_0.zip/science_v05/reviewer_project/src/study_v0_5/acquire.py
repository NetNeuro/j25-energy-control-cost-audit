"""Reserve new building IDs by source eligibility, before their control outcomes."""
import json,concurrent.futures
import numpy as np,pandas as pd
from .common import *
from ..study_v0_3.acquire import get,BASE,CLIMATES

def main():
    out=ROOT/'data/study_v0_5/cohort_manifest.json'
    if out.exists():raise FileExistsError('Fresh cohort already assigned')
    prior=json.loads((ROOT/'data/study_v0_3/cohort_manifest.json').read_text())
    excluded={b['id'] for c in prior['communities'] for b in c['buildings']}
    record={'version':'0.5','assigned_at_utc':stamp(),'no_fresh_control_outcomes_seen':True,
      'selection':'First six eligible include=true IDs per climate after excluding every prior 54 controlled homes; prior raw-only audit does not count as control use.',
      'excluded_controlled_ids':sorted(excluded),'communities':[],'eligibility_audit':[],'source_tag':'v3.1.0'}
    for climate,dataset in CLIMATES.items():
        s=json.loads((ROOT/f'data/study_v0_3/raw/{climate}/schema.json').read_text())
        ids=[k for k,v in s['buildings'].items() if v.get('include') and k not in excluded]
        chosen=[]
        for k in ids:
            dest=ROOT/f'data/study_v0_5/raw/{climate}/{k}.csv'
            item=get(BASE+dataset+'/'+k+'.csv',dest)
            df=pd.read_csv(dest);a=df[['non_shiftable_load','heating_demand','dhw_demand','cooling_demand']].to_numpy()
            ok=len(df)==8760 and np.isfinite(a).all() and (a>=0).all() and df.heating_demand.sum()>0 and df.dhw_demand.sum()>0
            item.update({'id':k,'eligible':bool(ok),'rows':len(df)})
            record['eligibility_audit'].append(item)
            if ok:chosen.append(item)
            if len(chosen)==6:break
        if len(chosen)<6:raise RuntimeError('Not enough eligible fresh homes '+climate)
        for j in range(2):record['communities'].append({'id':f'{climate}_N{j:02d}','climate':climate,'role':'fresh_test','buildings':chosen[3*j:3*j+3]})
        print(climate,'reserved six fresh homes',flush=True)
    allids=[b['id'] for c in record['communities'] for b in c['buildings']]
    assert len(allids)==len(set(allids))==18 and not set(allids)&excluded
    write_json(out,record)
if __name__=='__main__':main()
