"""Coordinated three-FMU mechanism adaptation under a shared modulation budget.

This is SH-only and is not a direct transfer of the primary SH/DHW score model.
The command budget is an electrical-capacity proxy, not a certified kW feeder cap.
Actual electrical power and all comfort outcomes remain reported independently.
"""
import argparse,concurrent.futures,ctypes,json,os,pickle,shutil,time
from pathlib import Path
import numpy as np,pandas as pd
from scipy.optimize import linprog,lsq_linear
from sklearn.ensemble import HistGradientBoostingRegressor
from fmpy import read_model_description,extract
from fmpy.fmi2 import FMU2Slave
from .common import ROOT,sha,stamp,write_json
DT=900.;B=3;BUDGET=1.8;OFFSETS=np.array([-.5,0,.5]);MARGINS=[0.,.15,.3,.5]
MEASURE=['reaTZon_y','reaPHeaPum_y','reaPPumEmi_y','reaPFan_y','weaSta_reaWeaTDryBul_y','weaSta_reaWeaHGloHor_y','reaCOP_y']

def preload():
    root=Path(os.environ.get('J25_FORTRAN_RUNTIME',str(ROOT/'data/boptest_v0_3/runtime')))
    matches=list(root.rglob('libgfortran.so.4.0.0'))
    if not matches:raise FileNotFoundError('Prepare the pinned Fortran runtime with tools/prepare_boptest_runtime.py')
    ctypes.CDLL(str(matches[0]),mode=ctypes.RTLD_GLOBAL)

class Campus:
    def __init__(self,start):
        preload();self.fs=[];self.paths=[]
        fmu=ROOT/'data/boptest_v0_3/wrapped.fmu';md=read_model_description(str(fmu),validate=False);self.refs={v.name:v.valueReference for v in md.modelVariables}
        for b in range(B):
            path=extract(str(fmu));self.paths.append(path)
            f=FMU2Slave(guid=md.guid,unzipDirectory=path,modelIdentifier=md.coSimulation.modelIdentifier,instanceName='building'+str(b))
            f.instantiate();f.setupExperiment(startTime=start);f.enterInitializationMode();f.exitInitializationMode();self.fs.append(f)
        schedule=pd.read_csv(Path(self.paths[0])/'resources/dataFromModel.csv');self.clock=schedule.iloc[:,0].to_numpy()
        self.lower=schedule[next(c for c in schedule if c.startswith('LowerSetp'))].to_numpy()-273.15
        self.upper=schedule[next(c for c in schedule if c.startswith('UpperSetp'))].to_numpy()-273.15
    def bounds(self,times):
        return np.interp(times,self.clock,self.lower)[...,None]+OFFSETS,np.interp(times,self.clock,self.upper)[...,None]+OFFSETS
    def measure(self):
        arr=np.array([f.getReal([self.refs[n] for n in MEASURE]) for f in self.fs])
        return {'zone':arr[:,0]-273.15,'power':arr[:,1:4].sum(axis=1),'hp_power':arr[:,1],
                'weather':float(arr[0,4]-273.15),'solar':float(arr[0,5]),'cop':arr[:,6]}
    def step(self,t,u=None,gain=1.):
        lo,_=self.bounds(np.array([t]));lo=lo[0]
        for b,f in enumerate(self.fs):
            f.setBoolean([self.refs['oveTSet_activate']],[True]);f.setReal([self.refs['oveTSet_u']],[float(lo[b]+273.15)])
            if u is not None:
                received=float(np.clip(u[b]*gain,0,1))
                f.setBoolean([self.refs[n] for n in ['oveHeaPumY_activate','ovePum_activate','oveFan_activate']],[True,True,True])
                f.setReal([self.refs[n] for n in ['oveHeaPumY_u','ovePum_u','oveFan_u']],[received,float(received>0),float(received>0)])
            f.doStep(currentCommunicationPoint=t,communicationStepSize=DT)
        return self.measure()
    def close(self):
        for f in self.fs:f.terminate();f.freeInstance()
        for p in self.paths:shutil.rmtree(p)

def risk_features(zone,u,weather,solar,hour,lo):
    return np.r_[zone-lo,u,weather/30,solar/1000,np.sin(2*np.pi*hour/24),np.cos(2*np.pi*hour/24)]

def develop():
    out=ROOT/'results/study_v0_5/boptest/development';out.mkdir(parents=True,exist_ok=False)
    campus=Campus(0.);m=campus.measure();t=0.;start=7*86400.;end=14*86400.;warm=[];rows=[];rng=np.random.default_rng(250511)
    try:
        while t<start:
            m=campus.step(t);t+=DT;warm.append({'time':t,'zone':m['zone'].tolist()})
        while t<end:
            before=m;lo,hi=campus.bounds(np.array([t+DT]));lo=lo[0];hi=hi[0]
            u=rng.choice([0.,.3,.6,.9],3)
            u=np.where(before['zone']<lo-.5,1.,u);u=np.where(before['zone']>hi-.5,0.,u)
            if u.sum()>BUDGET:u*=BUDGET/u.sum()
            m=campus.step(t,u);t+=DT
            rows.append({'time':t,'zone_before':before['zone'].tolist(),'zone':m['zone'].tolist(),'weather':before['weather'],
                'solar':before['solar'],'u':u.tolist(),'lo':lo.tolist(),'hi':hi.tolist(),'power':m['power'].tolist()})
    finally:campus.close()
    write_json(out/'trajectory.json',rows);write_json(out/'warmup.json',warm)
    coefficients=[];errors=[];train=rows[:5*96];cal=rows[5*96:]
    def matrix(z,b):
        return np.array([[r['weather']-r['zone_before'][b],r['u'][b],r['solar'],1.] for r in z]),np.array([r['zone'][b]-r['zone_before'][b] for r in z])
    for b in range(B):
        X,y=matrix(train,b);fit=lsq_linear(X,y,bounds=([.0001,.00001,0,-.5],[.1,2,.005,.5]));coefficients.append(fit.x.tolist())
        X,y=matrix(cal,b);errors.append(X@fit.x-y)
    X=[];Y=[]
    for r in train:
        X.append(risk_features(np.array(r['zone_before']),np.array(r['u']),r['weather'],r['solar'],(r['time']/3600)%24,np.array(r['lo'])))
        Y.append(float(np.maximum(np.array(r['lo'])-np.array(r['zone']),0).sum()))
    model=HistGradientBoostingRegressor(loss='quantile',quantile=.9,max_iter=80,max_leaf_nodes=7,min_samples_leaf=20,
        monotonic_cst=[-1]*6+[0]*4,l2_regularization=1.,random_state=250511).fit(X,Y)
    errors=np.array(errors).T
    Xc=np.array([risk_features(np.array(r['zone_before']),np.array(r['u']),r['weather'],r['solar'],(r['time']/3600)%24,np.array(r['lo'])) for r in cal])
    yc=np.array([np.maximum(np.array(r['lo'])-np.array(r['zone']),0).sum() for r in cal]);pred=np.maximum(model.predict(Xc),0)
    joint=float(np.quantile(errors.max(axis=1),.9,method='higher'));lossq=float(np.quantile(yc-pred,.9,method='higher'))
    p=ROOT/'models/study_v0_5_boptest';p.mkdir(exist_ok=True)
    with (p/'score.pkl').open('wb') as f:pickle.dump(model,f)
    record={'trained_utc':stamp(),'coefficients':coefficients,'joint_temperature_error_q90':joint,'service_loss_residual_q90':lossq,
        'training_steps':480,'calibration_steps':192,'positive_training_losses':int((np.array(Y)>1e-3).sum()),
        'validation_temperature_rmse_k':float(np.sqrt((errors**2).mean())),'shared_command_budget':BUDGET,
        'scope':'SH-only mechanism adaptation; no DHW, no firm kW feeder guarantee and no direct transfer of primary score model',
        'test_outcomes_seen':False,'fmu_sha256':sha(ROOT/'data/boptest_v0_3/wrapped.fmu')}
    write_json(p/'model.json',record)
    write_json(ROOT/'protocol/study_v0_5/BOPTEST_FREEZE.json',{'frozen_utc':stamp(),'test_outcomes_seen':False,
        'identification_days':[7,12],'calibration_days':[12,14],'warmup_days':7,
        'test_periods':{'winter_new':42,'autumn_new':300},'test_days':7,'regimes':['nominal','actuator_drop_after48h'],
        'methods':['adaptive','fixed_margin','feedback','proposed'],'instances':3,
        'claim_scope':record['scope'],'files':[{'path':str(x.relative_to(ROOT)),'sha256':sha(x)} for x in [Path(__file__),p/'score.pkl',p/'model.json',ROOT/'data/boptest_v0_3/wrapped.fmu']]})
    print(json.dumps(record,indent=2),flush=True)

def solve_joint(zone,weather,solar,lo,hi,coefficients,factors,times,margin):
    H=len(weather);N=B*4*H;eq=np.zeros((B*H,N));rhs=np.zeros(B*H);ub=np.zeros((2*B*H+H,N));v=np.zeros(2*B*H+H)
    cost=np.zeros(N);bounds=[]
    price=np.where((times/3600)%24>=7,.0666,.0383);price=np.where((times/3600)%24>=22,.0383,price)
    for b in range(B):
        base=b*4*H;a,g,s,o=coefficients[b];g*=factors[b];ret=1-a
        bounds.extend([(0,1)]*H+[(None,None)]*H+[(0,None)]*(2*H))
        cost[base:base+H]=price*3.2*.25;cost[base+2*H:base+4*H]=1000.
        for i in range(H):
            row=b*H+i;eq[row,base+H+i]=1;eq[row,base+i]=-g;rhs[row]=a*weather[i]+s*solar[i]+o
            if i:eq[row,base+H+i-1]=-ret
            else:rhs[row]+=ret*zone[b]
            ub[row,base+H+i]=-1;ub[row,base+2*H+i]=-1;v[row]=-lo[i,b]-margin
            j=B*H+row;ub[j,base+H+i]=1;ub[j,base+3*H+i]=-1;v[j]=hi[i,b]
            ub[2*B*H+i,base+i]=1;v[2*B*H+i]=BUDGET
    result=linprog(cost,A_eq=eq,b_eq=rhs,A_ub=ub,b_ub=v,bounds=bounds,method='highs-ds')
    if not result.success:
        u=(zone<lo[0]).astype(float)
        if u.sum()>BUDGET:u*=BUDGET/u.sum()
        return u,np.asarray(zone),1e20,str(result.status)
    u=np.array([result.x[b*4*H] for b in range(B)]);nexttemp=np.array([result.x[b*4*H+H] for b in range(B)])
    return u,nexttemp,float(result.fun),str(result.status)

def run_test(task):
    period,day,method,regime=task;out=ROOT/f'results/study_v0_5/boptest/{period}__{method}__{regime}'
    if (out/'summary.json').exists():return json.loads((out/'summary.json').read_text())
    out.mkdir(parents=True,exist_ok=False)
    frozen=json.loads((ROOT/'protocol/study_v0_5/BOPTEST_FREEZE.json').read_text())
    for x in frozen['files']:assert sha(ROOT/x['path'])==x['sha256']
    info=json.loads((ROOT/'models/study_v0_5_boptest/model.json').read_text());coeff=np.array(info['coefficients'])
    score=pickle.load(open(ROOT/'models/study_v0_5_boptest/score.pkl','rb'))
    start=day*86400.;campus=Campus(start-7*86400.);m=campus.measure();t=start-7*86400.;history=[];warm=[];rows=[];factors=np.ones(3);feedback=.25
    wall=time.perf_counter()
    try:
        while t<start:
            m=campus.step(t);t+=DT;history.append(m);warm.append({'time':t,'zone':m['zone'].tolist()})
        for step in range(7*96):
            before=m;H=min(24,7*96-step);times=t+DT*np.arange(1,H+1);lo,hi=campus.bounds(times)
            past=history[-96:];weather=np.array([past[i%len(past)]['weather'] for i in range(H)]);solar=np.array([past[i%len(past)]['solar'] for i in range(H)])
            start_dec=time.perf_counter();margin=.5 if method=='fixed_margin' else feedback if method=='feedback' else 0.
            candidates=[]
            for mar in (MARGINS if method=='proposed' else [margin]):
                u,predtemp,value,status=solve_joint(before['zone'],weather,solar,lo,hi,coeff,factors,times,mar)
                f=risk_features(before['zone'],u,before['weather'],before['solar'],((t+DT)/3600)%24,lo[0])
                learned=max(0,float(score.predict(f[None])[0])+info['service_loss_residual_q90'])
                physical=float(np.maximum(lo[0]-predtemp+info['joint_temperature_error_q90'],0).sum())
                candidates.append((u,predtemp,value,status,max(learned,physical),mar))
            eligible=[i for i,c in enumerate(candidates) if c[4]<=.05]
            chosen=min(eligible,key=lambda i:candidates[i][2]) if eligible else min(range(len(candidates)),key=lambda i:(candidates[i][4],candidates[i][2]))
            u,predtemp,value,status,upper,margin=candidates[chosen];decision=time.perf_counter()-start_dec
            gain=.8 if regime=='actuator_drop_after48h' and step>=192 else 1.
            m=campus.step(t,u,gain);t+=DT;history.append(m)
            cold=np.maximum(lo[0]-m['zone'],0);hot=np.maximum(m['zone']-hi[0],0)
            delta=m['zone']-before['zone'];estimated=coeff[:,0]*(before['weather']-before['zone'])+coeff[:,2]*before['solar']+coeff[:,3]
            for b in range(B):
                if u[b]>.15:
                    ratio=np.clip((delta[b]-estimated[b])/(coeff[b,1]*u[b]),.5,1.5);factors[b]=.98*factors[b]+.02*ratio
            feedback=float(np.clip(feedback+.05*(float(cold.sum()>.01)-.05),0,1.))
            hour=(t/3600)%24;price=.0666 if 7<=hour<22 else .0383
            rows.append({'time':t,'step':step,'zone_before':before['zone'].tolist(),'zone':m['zone'].tolist(),
                'lo':lo[0].tolist(),'hi':hi[0].tolist(),'command':u.tolist(),'received_input':(u*gain).tolist(),
                'command_sum':float(u.sum()),'power_w':m['power'].tolist(),'cold_deficit_k':float(cold.sum()),'hot_excess_k':float(hot.sum()),
                'custom_cost':float(m['power'].sum()/1000*.25*price),'energy_kwh':float(m['power'].sum()/1000*.25),
                'score_upper':upper,'score_observed':float(cold.sum()),'selected_margin_k':margin,'gain_estimates_after':factors.tolist(),
                'decision_seconds':decision,'solver_status':status,'actual_actuator_gain':gain})
    finally:campus.close()
    write_json(out/'trajectory.json',rows);write_json(out/'warmup.json',warm)
    result={'period':period,'method':method,'regime':regime,'steps':len(rows),'instances':3,'test_days':7,
        'cold_discomfort_kh':sum(r['cold_deficit_k'] for r in rows)*.25,'hot_discomfort_kh':sum(r['hot_excess_k'] for r in rows)*.25,
        'custom_cost':sum(r['custom_cost'] for r in rows),'energy_kwh':sum(r['energy_kwh'] for r in rows),
        'max_command_budget_violation':max(0,max(r['command_sum'] for r in rows)-BUDGET),
        'max_measured_aggregate_power_kw':max(sum(r['power_w']) for r in rows)/1000,
        'decision_p95_seconds':float(np.quantile([r['decision_seconds'] for r in rows],.95)),
        'score_miscoverage_fraction':float(np.mean([r['score_observed']>r['score_upper']+1e-6 for r in rows])),
        'wall_seconds':time.perf_counter()-wall,'scope':info['scope'],'completed_utc':stamp()}
    write_json(out/'summary.json',result);return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['develop','test'],required=True);args=ap.parse_args()
    if args.mode=='develop':develop();return
    frozen=json.loads((ROOT/'protocol/study_v0_5/BOPTEST_FREEZE.json').read_text())
    tasks=[(name,day,method,reg) for name,day in frozen['test_periods'].items() for method in frozen['methods'] for reg in frozen['regimes']]
    rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
        for i,r in enumerate(pool.map(run_test,tasks)):
            rows.append(r);print('Coupled BOPTEST',i+1,'/',len(tasks),r['period'],r['method'],r['regime'],flush=True)
    write_json(ROOT/'results/study_v0_5/boptest/ALL_RESULTS.json',rows)
if __name__=='__main__':main()
