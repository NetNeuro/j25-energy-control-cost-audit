"""Low-dimensional decision-focused forecast output correction through actual rollouts."""
import concurrent.futures
from .common import *
from .campaign import init_worker,run_episode

def main():
    tasks=[]
    for climate in ['VT','CA','TX']:
        for sh in [1.,1.15,1.3]:
            for dhw in [1.,1.15,1.3]:
                spec={'name':f'out_{sh}_{dhw}','method':'decision_focused','correction':[sh,dhw]}
                for j in range(3):
                    for day in [31,45]:
                        tasks.append((f'{climate}_{j:02d}',{'name':f'day{day}','start_row':day*24,'hours':72},spec,'cop_step','decision_training'))
    rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,initializer=init_worker,initargs=(False,)) as pool:
        for i,r in enumerate(pool.map(run_episode,tasks)):
            rows.append(r)
            if (i+1)%27==0:print('Decision-focused tuning',i+1,'/',len(tasks),flush=True)
    chosen={};audit={}
    for climate in ['VT','CA','TX']:
        scores={}
        for r in rows:
            if r['climate']!=climate:continue
            key=r['spec']['name'];v=scores.setdefault(key,{'score':0.,'correction':r['spec']['correction']})
            v['score']+=r['energy_cost']+1000*r['unmet_kwh_th']-r['terminal_inventory_credit']
        key=min(scores,key=lambda k:(scores[k]['score'],scores[k]['correction']))
        chosen[climate]=scores[key]['correction'];audit[climate]={'selected':key,'all_training_scores':scores}
    write_json(ROOT/'models/study_v0_5/decision_corrections.json',chosen)
    write_json(ROOT/'results/study_v0_5/decision_training/TRAINING_SELECTION.json',{'selected_utc':stamp(),'fresh_outcomes_seen':False,'family':'Two thermal output multipliers tuned through executed downstream cost and service, not prediction error; adaptation, not an exact neural DFL reproduction','results':audit})
    print(chosen,flush=True)
if __name__=='__main__':main()
