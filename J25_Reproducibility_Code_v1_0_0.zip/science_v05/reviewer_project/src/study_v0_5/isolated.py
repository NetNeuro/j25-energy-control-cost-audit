"""Serial complete decisions with fresh causal forecasts and physical execution."""
import json,pickle,platform,sys,time
import pandas as pd
from .common import *
from .controller import *

def main():
    out=ROOT/'results/study_v0_5/isolated';out.mkdir(exist_ok=False)
    model,cal=load_models();risk=pickle.load(open(ROOT/'models/study_v0_5/service_score.pkl','rb'))
    rcal=json.loads((ROOT/'models/study_v0_5/score_calibration.json').read_text());corr=json.loads((ROOT/'models/study_v0_5/decision_corrections.json').read_text())
    specs=json.loads((ROOT/'configs/study_v0_5/selected.json').read_text())['test_specs'];data=load_data(True);rows=[]
    for climate in ['VT','CA','TX']:
        d=data[climate+'_N00'];plant=size_plant(d,config(),3)
        for ep in episode_dates()[::2]:
            for rep in range(5):
                order=specs[rep:]+specs[:rep]
                for spec in order:
                    ctrl=Controller(spec,model,cal,risk,rcal,corr,cache=False);t=ep['start_row'];state=np.tile(plant['cap']/2,(3,1))
                    wall=time.perf_counter();cpu=time.process_time();a,detail=ctrl.act(d,t,24,state,plant)
                    actual,end,row=execute(d['loads'][t],d['weather'][t],state,a,plant,detail['estimated_scale'],1.)
                    ctrl.update(row,d['weather'][t]);elapsed=time.perf_counter()-wall;process=time.process_time()-cpu
                    rows.append({'climate':climate,'episode':ep['name'],'repeat':rep,'method':spec['name'],'seconds':elapsed,'cpu_seconds':process,
                        'solver_seconds':detail['solver_seconds'],'native_solves':detail['native_solves'],'complete_physical_check':True})
    df=pd.DataFrame(rows);df.to_csv(out/'calls.csv',index=False);results=[]
    for method,g in df.groupby('method'):
        results.append({'method':method,'calls':len(g),'mean_seconds':g.seconds.mean(),'median_seconds':g.seconds.median(),
            'p95_seconds':g.seconds.quantile(.95),'p99_seconds':g.seconds.quantile(.99),'max_seconds':g.seconds.max(),
            'first_snapshot_calls_p95_seconds':g[g['repeat']==0].seconds.quantile(.95),'misses_60_seconds':int((g.seconds>60).sum())})
    pd.DataFrame(results).to_csv(out/'summary.csv',index=False)
    write_json(out/'context.json',{'completed_utc':stamp(),'python':sys.version,'platform':platform.platform(),
       'scope':'Resident inputs, no forecast cache; causal forecasting, candidate construction, inference, all solves, actual physical execution/check and observer update. Process imports, input loading and output serialization excluded.',
       'concurrency':'One process, one solver/OpenMP/BLAS thread; all other campaigns finished','allowance':'60 seconds is an assumed engineering allowance for hourly operation, not a measured operator deadline'})
    print(pd.DataFrame(results).to_string(index=False))
if __name__=='__main__':main()
