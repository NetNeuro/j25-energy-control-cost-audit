"""Immutable inputs and causal execution conventions for the v0.5 continuation."""
import copy,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
from ..study_v0_3.data import load_all as load_old,features,forecast_point,episode_dates
from ..study_v0_3.control import configuration as old_config,load_models
from ..benchmark_v0_2 import heating_cop,size_plant
ROOT=Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def stamp():return datetime.now(timezone.utc).isoformat()
def config(scale=1.):
    c=old_config();c['version']='0.5';c['physics']=copy.deepcopy(c['physics']);c['physics']['carnot_fraction']*=scale
    return c

def load_data(include_test=False):
    data=load_old()
    if include_test:
        import pandas as pd
        m=json.loads((ROOT/'data/study_v0_5/cohort_manifest.json').read_text())
        for c in m['communities']:
            frames=[]
            for b in c['buildings']:
                assert sha(ROOT/b['path'])==b['sha256'];frames.append(pd.read_csv(ROOT/b['path']))
            ref=data[c['climate']+'_00']
            arr=np.stack([x[['non_shiftable_load','heating_demand','dhw_demand','cooling_demand']].to_numpy() for x in frames],axis=1)
            data[c['id']]={'id':c['id'],'climate':c['climate'],'role':'fresh_test','loads':arr,
                'weather':ref['weather'].copy(),'hours':ref['hours'].copy(),'daytype':ref['daytype'].copy(),
                'scales':np.maximum(np.quantile(arr[:336],.9,axis=0),.25),'building_ids':[b['id'] for b in c['buildings']]}
    return data

def true_scale(regime,step):
    return 1.0 if regime=='nominal' or step<48 else .8

def execute(load,temp,state,action,plant,estimated_scale,actual_scale):
    """Electric commands, realized thermal conversion and an explicit local thermostat.

    The current interval's conversion is observed after execution. Thermostat
    curtailment reduces delivered heat and associated electrical consumption when
    a buffer would overfill. It does not add a heat dump or hide unserved heat.
    """
    nom=config();cm=config(estimated_scale);ca=config(actual_scale)
    kmodel=float(heating_cop(temp,cm));kactual=float(heating_cop(temp,ca))
    el=np.column_stack([action[:,0]/kmodel,action[:,1],action[:,2]])
    el=np.maximum(el,0)
    # Candidate commands respect electrical nameplates and shared headroom.
    limits=np.column_stack([plant['hp_el'],plant['aux'],plant['dhw']]);el=np.minimum(el,limits)
    base=float((load[:,0]+load[:,3]/3).sum());head=max(0,plant['feeder']-base)
    if el.sum()>head+1e-7:el*=head/el.sum()
    gen=el*np.array([kactual,1,1]);ret=state*plant['retention'];demand=load[:,[1,2]]
    curtailed=0.
    for b in range(len(load)):
        for j,ks in [(0,[0,1]),(1,[2])]:
            total=gen[b,ks].sum();maxheat=max(0,demand[b,j]+plant['cap'][j]-ret[b,j])
            if total>maxheat:
                ratio=maxheat/total;curtailed+=total-maxheat;gen[b,ks]*=ratio;el[b,ks]*=ratio
    supplied=np.column_stack([gen[:,:2].sum(axis=1),gen[:,2]])
    unmet=np.maximum(demand-ret-supplied,0);end=ret+supplied+unmet-demand
    actual_action=np.column_stack([gen,unmet,end])
    grid=base+el.sum();balance=end-ret-supplied-unmet+demand
    device=float(max(0,(el-limits).max(),-el.min()))
    excess=float(max(0,-end.min(),(end-plant['cap']).max(),grid-plant['feeder'],device))
    row={'energy_cost':0.,
         'grid_kwh':float(grid),'unmet_kwh_th':float(unmet.sum()),'space_unmet_kwh_th':float(unmet[:,0].sum()),
         'dhw_unmet_kwh_th':float(unmet[:,1].sum()),'max_balance_residual':float(np.abs(balance).max()),
         'max_bound_violation':excess,'device_violation':device,'base_overload_kw':float(max(0,base-plant['feeder'])),
         'thermostat_curtailed_heat_kwh_th':float(curtailed),'hp_electrical_kwh':float(el[:,0].sum()),
         'hp_heat_kwh_th':float(gen[:,0].sum()),'actual_cop':kactual,'model_cop':kmodel,
         'actual_scale':actual_scale,'estimated_scale':estimated_scale}
    return actual_action,end,row

class EfficiencyObserver:
    def __init__(self):self.value=1.;self.samples=0
    def update(self,row,temp):
        if row['hp_electrical_kwh']>.02:
            ratio=(row['hp_heat_kwh_th']/row['hp_electrical_kwh'])/float(heating_cop(temp,config()))
            self.value=float(np.clip(.8*self.value+.2*ratio,.65,1.15));self.samples+=1
