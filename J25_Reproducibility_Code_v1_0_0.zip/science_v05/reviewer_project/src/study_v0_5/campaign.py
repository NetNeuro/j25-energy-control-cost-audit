"""Atomic complete-record rollouts, preserving every failed attempt."""
import argparse,concurrent.futures,json,os,pickle,time,traceback
from .common import *
from .controller import *
_DATA=None;_MODEL=None;_CAL=None;_RISK=None;_RCAL=None;_CORR=None

def init_worker(include_test=False):
    global _DATA,_MODEL,_CAL,_RISK,_RCAL,_CORR
    _DATA=load_data(include_test);_MODEL,_CAL=load_models()
    _RISK=pickle.load(open(ROOT/'models/study_v0_5/service_score.pkl','rb'))
    _RCAL=json.loads((ROOT/'models/study_v0_5/score_calibration.json').read_text())
    p=ROOT/'models/study_v0_5/decision_corrections.json'
    _CORR=json.loads(p.read_text()) if p.exists() else {c:[1.,1.] for c in ['VT','CA','TX']}

def run_episode(task):
    cid,ep,spec,regime,phase=task;d=_DATA[cid];plant=size_plant(d,config(),3)
    out=ROOT/f'results/study_v0_5/{phase}';out.mkdir(parents=True,exist_ok=True)
    key=f'{cid}__{ep["name"]}__{regime}__{spec["name"]}';done=out/(key+'.summary.json')
    if done.exists():return json.loads(done.read_text())
    if (out/(key+'.npz')).exists():raise FileExistsError('Uncommitted output retained: '+key)
    correction=_CORR.copy()
    if 'correction' in spec:correction[d['climate']]=spec['correction']
    ctrl=Controller(spec,_MODEL,_CAL,_RISK,_RCAL,correction,cache=True)
    if 'gain' in spec:ctrl.feedback_gain=spec['gain']
    state=np.tile(plant['cap']/2,(3,1));states=[state.copy()];aa=[];commands=[];rows=[];start=time.perf_counter()
    for step in range(ep['hours']):
        t=ep['start_row']+step;H=min(24,ep['hours']-step)
        a,detail=ctrl.act(d,t,H,state,plant)
        actual,end,row=execute(d['loads'][t],d['weather'][t],state,a,plant,detail['estimated_scale'],true_scale(regime,step))
        row.update(detail);row.update({'community':cid,'climate':d['climate'],'episode':ep['name'],'regime':regime,
             'origin':t,'step':step,'method_name':spec['name'],'phase':phase})
        row['energy_cost']=row['grid_kwh']*config()['tariff'][int(d['hours'][t])]
        row['score_observed']=row['unmet_kwh_th']+min_deficit(d['loads'][t+1],d['weather'][t+1],end,plant,true_scale(regime,step+1)) if H>1 else None
        row['score_miscovered']=(row['score_observed']>row['score_upper']+1e-6) if row['score_upper'] is not None and H>1 else None
        ctrl.update(row,d['weather'][t]);states.append(end.copy());commands.append(a);aa.append(actual);rows.append(row);state=end
    records=np.array([json.dumps(row,allow_nan=False) for row in rows])
    dest=out/(key+'.npz');tmp=dest.with_suffix('.npz.tmp')
    with tmp.open('wb') as f:
        np.savez_compressed(f,actions=np.array(aa),model_commands=np.array(commands),states=np.array(states),
           origins=np.arange(ep['start_row'],ep['start_row']+ep['hours']),records_json=records,
           cap=plant['cap'],hp_el=plant['hp_el'],aux=plant['aux'],dhw=plant['dhw'],feeder=plant['feeder'],retention=plant['retention'])
    os.replace(tmp,dest)
    with np.load(dest,allow_pickle=False) as r:assert len(r['records_json'])==ep['hours'] and r['states'].shape[0]==ep['hours']+1
    endcost=(state[:,0]/float(heating_cop(d['weather'][t],config(ctrl.observer.value)))+state[:,1]).sum()*.22
    summary={'key':key,'community':cid,'climate':d['climate'],'episode':ep['name'],'season':ep.get('season','development'),
        'spec':spec,'regime':regime,'phase':phase,'steps':len(rows),'energy_cost':sum(x['energy_cost'] for x in rows),
        'unmet_kwh_th':sum(x['unmet_kwh_th'] for x in rows),'space_unmet_kwh_th':sum(x['space_unmet_kwh_th'] for x in rows),
        'dhw_unmet_kwh_th':sum(x['dhw_unmet_kwh_th'] for x in rows),'terminal_deviation_kwh_th':float(np.abs(state-plant['cap']/2).sum()),
        'terminal_signed_kwh_th':float((state-plant['cap']/2).sum()),'terminal_inventory_credit':float(endcost),
        'grid_kwh':sum(x['grid_kwh'] for x in rows),'max_balance_residual':max(x['max_balance_residual'] for x in rows),
        'max_bound_violation':max(x['max_bound_violation'] for x in rows),'base_overload_hours':sum(x['base_overload_kw']>1e-6 for x in rows),
        'fallback_count':sum(x['fallback'] for x in rows),'reserve_unavailable_count':sum(x['reserve_unavailable'] for x in rows),
        'score_checks':sum(x['score_miscovered'] is not None for x in rows),'score_miscoverages':sum(x['score_miscovered'] is True for x in rows),
        'risk_accepted_count':sum(x['risk_accepted'] is True for x in rows),'candidate_counts':[sum(x['chosen_candidate']==j for x in rows) for j in range(5)],
        'decision_wall_seconds':sum(x['decision_seconds'] for x in rows),'cpu_seconds':sum(x['cpu_seconds'] for x in rows),
        'wall_seconds':time.perf_counter()-start,'completed_at_utc':stamp(),'record_sha256':sha(dest)}
    write_json(done,summary);return summary

def specs_validation():
    specs=[{'name':m,'method':m} for m in ['rule50','rule75','rule100','nominal','adaptive','scenario','decision_focused']]
    specs +=[{'name':f'load_q{q}','method':'load_reserve','level':q} for q in [.5,.8,.95]]
    specs +=[{'name':f'feedback_g{q}','method':'feedback','gain':q} for q in [.02,.08,.2]]
    specs +=[{'name':f'risk_tol{q}','method':'risk_simultaneous','tolerance':q} for q in [.01,.1,.5]]
    return specs

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['validation','test','reproduce'],required=True);ap.add_argument('--workers',type=int,default=4);args=ap.parse_args()
    if args.phase=='validation':
        data=load_data(False);ids=[k for k,v in data.items() if v['role']=='validation'];specs=specs_validation()
        eps=[{'name':'Mar15','start_row':73*24,'hours':168},{'name':'Mar22','start_row':80*24,'hours':168}]
        regimes=['nominal','cop_step'];phase='validation'
    else:
        freeze=json.loads((ROOT/'protocol/study_v0_5/TEST_FREEZE.json').read_text())
        for x in freeze['files']:
            if sha(ROOT/x['path'])!=x['sha256']:raise ValueError('Frozen scientific input changed '+x['path'])
        data=load_data(True);ids=[k for k,v in data.items() if v['role']=='fresh_test']
        selected=json.loads((ROOT/'configs/study_v0_5/selected.json').read_text());specs=selected['test_specs'];eps=episode_dates();regimes=['nominal','cop_step']
        phase='fresh_test' if args.phase=='test' else 'reproduction_'+stamp().replace(':','').replace('.','')
        if args.phase=='reproduce':ids=['VT_N00','CA_N00','TX_N00'];specs=[x for x in specs if x['name'] in ['adaptive','proposed']];eps=eps[:1];regimes=['cop_step']
    tasks=[(cid,ep,spec,reg,phase) for cid in ids for ep in eps for reg in regimes for spec in specs]
    out=ROOT/f'results/study_v0_5/{phase}';out.mkdir(parents=True,exist_ok=True)
    write_json(out/'CONTEXT.json',{'started_utc':stamp(),'tasks':len(tasks),'workers':args.workers,'phase':phase,'specs':specs,'episodes':eps,'regimes':regimes,
         'record_format':'Atomic NPZ with complete embedded JSON rows; no streamed text log is authoritative','forecast_cache':'Causal resident forecast cache permitted in campaign, isolated timers recompute forecasts'})
    summaries=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init_worker,initargs=(args.phase!='validation',)) as pool:
        futures={pool.submit(run_episode,task):task for task in tasks}
        for future in concurrent.futures.as_completed(futures):
            try:r=future.result()
            except Exception:
                with (out/'FAILED_ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps({'task':futures[future],'error':traceback.format_exc()})+'\n')
                raise
            summaries.append(r)
            if len(summaries)%12==0 or len(summaries)==len(tasks):print(phase,len(summaries),'/',len(tasks),r['key'],flush=True)
    write_json(out/'COMPLETED.json',{'completed_utc':stamp(),'episodes':len(summaries),'decisions':sum(x['steps'] for x in summaries)})
    if args.phase=='reproduce':
        comparisons=[]
        for r in summaries:
            old=json.loads((ROOT/f'results/study_v0_5/fresh_test/{r["key"]}.summary.json').read_text())
            delta={k:abs(r[k]-old[k]) for k in ['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']}
            a=np.load(out/(r['key']+'.npz'));b=np.load(ROOT/f'results/study_v0_5/fresh_test/{r["key"]}.npz')
            diff=float(np.abs(a['actions']-b['actions']).max())
            comparisons.append({'key':r['key'],'metric_deltas':delta,'max_action_difference':diff,'passed':max(delta.values())<1e-5 and diff<1e-5})
        write_json(out/'NUMERICAL_REPRODUCTION.json',{'episodes':len(comparisons),'all_passed':all(x['passed'] for x in comparisons),'comparisons':comparisons})
if __name__=='__main__':main()
