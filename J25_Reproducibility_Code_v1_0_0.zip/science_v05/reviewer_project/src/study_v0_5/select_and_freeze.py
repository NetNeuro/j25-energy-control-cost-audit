"""Validation-only selection and an immutable fresh-test input freeze."""
import json
from pathlib import Path
from .common import *

def main():
    out=ROOT/'protocol/study_v0_5/TEST_FREEZE.json'
    if out.exists():raise FileExistsError('Fresh test already frozen')
    folder=ROOT/'results/study_v0_5/validation';rows=[json.loads(p.read_text()) for p in folder.glob('*.summary.json')]
    assert len(rows)==192,(len(rows),'Incomplete validation')
    totals={}
    for r in rows:
        v=totals.setdefault(r['spec']['name'],{'unmet':0.,'cost':0.,'terminal':0.,'cpu':0.,'spec':r['spec']})
        for dst,src in [('unmet','unmet_kwh_th'),('cost','energy_cost'),('terminal','terminal_deviation_kwh_th'),('cpu','cpu_seconds')]:v[dst]+=r[src]
    def select(names):
        minimum=min(totals[n]['unmet'] for n in names)
        tied=[n for n in names if totals[n]['unmet']<=minimum+.01]
        return min(tied,key=lambda n:(totals[n]['cost'],totals[n]['terminal'],totals[n]['cpu']))
    conventional=[n for n in totals if not n.startswith('risk')]
    baseline=select(conventional);proposed=select([n for n in totals if n.startswith('risk')])
    load=select([n for n in totals if n.startswith('load')]);feedback=select([n for n in totals if n.startswith('feedback')])
    tol=totals[proposed]['spec']['tolerance']
    specs=[{'name':m,'method':m} for m in ['rule50','rule75','rule100','nominal','adaptive','scenario','decision_focused']]
    for name,tag in [(load,'load_reserve'),(feedback,'feedback')]:
        v=totals[name]['spec'].copy();v['name']=tag;specs.append(v)
    specs +=[{'name':name,'method':method,'tolerance':tol} for name,method in [('proposed','risk_simultaneous'),('marginal_calibration','risk_marginal'),('no_model_adaptation','risk_no_adapt'),('uncalibrated_score','risk_uncalibrated')]]
    selected={'selected_at_utc':stamp(),'fresh_outcomes_seen':False,'primary_comparator_validation_name':baseline,
      'primary_comparator_test_name': 'load_reserve' if baseline.startswith('load') else 'feedback' if baseline.startswith('feedback') else baseline,
      'proposed_validation_name':proposed,'proposed_tolerance_kwh_th':tol,'test_specs':specs,'validation_totals':totals,
      'selection_rule':'Lowest validation unmet heat, numerical/practical tie within .01 total kWh thermal then lowest cost; all conventional policies eligible including Rule100. Same rule for proposed tolerance.',
      'primary_gate':{'minimum_relative_service_reduction':.2,'cost_upper_one_sided95_noninferiority_margin':.01,
        'terminal_mean_error_increase_limit_kwh_th':.05,'justification':'Discovery engineering margins: 20% material service change; 1% illustrative operating cost tolerance; .05kWh community-week inventory difference is under .2% of total usable community buffers. Not field-operator requirements or journal standards.'}}
    write_json(ROOT/'configs/study_v0_5/selected.json',selected)
    paths=list((ROOT/'src/study_v0_5').glob('*.py'))+list((ROOT/'models/study_v0_5').glob('*'))
    paths +=[ROOT/'configs/study_v0_5/selected.json',ROOT/'data/study_v0_5/cohort_manifest.json',ROOT/'protocol/study_v0_5/DESIGN_BEFORE_DEVELOPMENT.txt',ROOT/'models/study_v0_3/point_forecast.pkl',ROOT/'models/study_v0_3/calibration.pkl',ROOT/'src/benchmark_v0_2.py']
    paths +=list((ROOT/'data/study_v0_5/raw').rglob('*.csv'))
    write_json(out,{'frozen_at_utc':stamp(),'timestamp_authority':'Local clock, not public preregistration','fresh_controller_outcomes_seen':False,
        'planned_fresh_communities':6,'planned_unique_community_weeks':48,'regimes':['nominal','cop_step'],
        'policies':len(specs),'planned_rollouts':48*2*len(specs),'planned_decisions':48*2*len(specs)*168,
        'files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in paths if p.is_file()]})
    print(json.dumps({'baseline':baseline,'proposed':proposed,'policies':len(specs),'rollouts':48*2*len(specs),'decisions':48*2*len(specs)*168},indent=2))
if __name__=='__main__':main()
