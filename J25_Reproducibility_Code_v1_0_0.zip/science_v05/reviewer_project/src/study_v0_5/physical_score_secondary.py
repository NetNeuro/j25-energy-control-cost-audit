"""Prespecified secondary comparison using the same candidates without a learned score."""
import concurrent.futures,json,time
from .common import *
from .controller import *
from . import campaign

class PhysicalScoreController(Controller):
    def act(self,d,t,H,state,plant):
        start=time.perf_counter();cpu=time.process_time();scale=self.observer.value
        aa,avail,X,infos=candidates(d,t,H,state,plant,scale,self.model,self.cal,self.cache)
        y,w=forecast(d,t,2,self.model,self.cache);donor=self.cal[d['climate']];hour=int(d['hours'][t+1])
        values=[]
        for a in aa:
            losses=[]
            for j in range(len(donor['donors'])):
                load=np.maximum(0,y[1]+donor['donors'][j,hour]*d['scales'])
                temp=w[1]+donor['temp_donors'][j,hour]
                losses.append(float(a[:,3:5].sum())+min_deficit(load,temp,a[:,5:7],plant,scale))
            values.append(float(np.quantile(losses,.9,method='higher')))
        pred=np.array(values);j,upper,accepted=choose(aa,avail,pred,0.,plant,d['weather'][t],d['hours'][t],scale,self.spec['tolerance'])
        return aa[j],{'method':'physical_score','chosen_candidate':j,'candidates_available':int(avail.sum()),'score_upper':float(upper[j]),
            'score_prediction':float(pred[j]),'risk_accepted':accepted,'reserve_unavailable':False,'fallback':False,'estimated_scale':scale,
            'candidate_upper':upper.tolist(),'candidate_available':avail.tolist(),'candidate_prediction':pred.tolist(),
            'decision_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,
            'native_solves':sum(i.get('native_solves',0) for i in infos),'solver_seconds':sum(i.get('solver_seconds',0.) for i in infos),
            'solver_statuses':[i.get('status','unknown') for i in infos]}

def init(include):
    campaign.init_worker(include);campaign.Controller=PhysicalScoreController

def main():
    ap=__import__('argparse').ArgumentParser();ap.add_argument('--phase',choices=['validation','test'],required=True);args=ap.parse_args()
    protocol=ROOT/'protocol/study_v0_5/PHYSICAL_SCORE_SECONDARY.json'
    if args.phase=='validation':
        if protocol.exists():raise FileExistsError('Secondary already declared')
        write_json(protocol,{'written_utc':stamp(),'primary_fresh_campaign_running':True,'primary_aggregate_outcomes_seen':False,
          'purpose':'Isolate learned scoring from the common candidate action family using joint empirical residual paths. This is an additional conventional comparator, not a change to the primary selected Rule100 contrast.',
          'algorithm':'Same nominal/reserve candidates, same EMA, same donor paths and .9 empirical service-loss quantile; no learned service model or residual correction.',
          'tolerances':[.01,.1,.5],'source_sha256':sha(Path(__file__))})
        eps=[{'name':'Mar15','start_row':73*24,'hours':168},{'name':'Mar22','start_row':80*24,'hours':168}]
        ids=[c+'_03' for c in ['VT','CA','TX']];specs=[{'name':f'physical_tol{x}','method':'physical_score','tolerance':x} for x in [.01,.1,.5]];phase='physical_score_validation'
    else:
        assert sha(Path(__file__))==json.loads(protocol.read_text())['source_sha256']
        rows=[json.loads(p.read_text()) for p in (ROOT/'results/study_v0_5/physical_score_validation').glob('*.summary.json')];assert len(rows)==36
        grouped={}
        for r in rows:
            z=grouped.setdefault(r['spec']['name'],{'unmet':0.,'cost':0.,'spec':r['spec']});z['unmet']+=r['unmet_kwh_th'];z['cost']+=r['energy_cost']
        least=min(z['unmet'] for z in grouped.values());key=min([k for k,z in grouped.items() if z['unmet']<=least+.01],key=lambda k:grouped[k]['cost'])
        spec=grouped[key]['spec'].copy();spec['name']='physical_score';specs=[spec]
        write_json(ROOT/'configs/study_v0_5/physical_score_selected.json',{'selected_utc':stamp(),'fresh_secondary_outcomes_seen':False,'primary_aggregate_outcomes_seen':False,'spec':spec,'validation':grouped})
        data=load_data(True);ids=[k for k,v in data.items() if v['role']=='fresh_test'];eps=episode_dates();phase='physical_score_test'
    tasks=[(cid,ep,spec,r,phase) for cid in ids for ep in eps for r in ['nominal','cop_step'] for spec in specs]
    with concurrent.futures.ProcessPoolExecutor(max_workers=2,initializer=init,initargs=(args.phase=='test',)) as pool:
        for i,r in enumerate(pool.map(campaign.run_episode,tasks)):
            if (i+1)%12==0:print(phase,i+1,'/',len(tasks),flush=True)
if __name__=='__main__':main()
