"""Complete calibration counters and equivalence checks, independent of policy."""
import json
import numpy as np
from .common import *

def main():
    folder=ROOT/'results/study_v0_5/fresh_test';audits=0;misses=0;accepted=0;eqmax=0.;cases=0;reference=0
    for p in folder.glob('*.npz'):
        with np.load(p) as a:
            records=[json.loads(x) for x in a['records_json']]
            audits+=sum(r['score_miscovered'] is not None for r in records)
            misses+=sum(r['score_miscovered'] is True for r in records)
            accepted+=sum(r['risk_accepted'] is True for r in records)
        if p.stem.endswith('__proposed'):
            q=p.with_name(p.name.replace('__proposed.npz','__uncalibrated_score.npz'))
            with np.load(p) as a,np.load(q) as b:eqmax=max(eqmax,float(np.abs(a['actions']-b['actions']).max()))
            cases+=1
    old=json.loads((ROOT/'results/study_v0_5/analysis_robust/independent_audit.json').read_text())
    old.update(score_audits=audits,score_miscoverages=misses,risk_accepted_decisions=accepted,
        counter_note='Original analysis initialized score counters but did not increment them; this read-only pass counts all complete embedded records. Physical reconstruction was unchanged.')
    write_json(ROOT/'results/study_v0_5/analysis_robust/COMPLETE_AUDIT.json',old)
    correction=json.loads((ROOT/'models/study_v0_5/score_calibration.json').read_text())
    write_json(ROOT/'results/study_v0_5/analysis_robust/CALIBRATION_EQUIVALENCE.json',{
      'fresh_episodes_compared':cases,'maximum_action_difference_proposed_vs_uncalibrated':eqmax,
      'largest_absolute_simultaneous_offset':max(abs(v['simultaneous']) for v in correction.values()),
      'interpretation':'Simultaneous correction is numerically zero and the calibrated/uncalibrated actions coincide on all 96 fresh regime-episodes. No incremental calibration benefit is demonstrated; this is observed equality, not a proof for every possible state.'})
    print(json.dumps({'score_audits':audits,'miscoverages':misses,'equivalence_cases':cases,'max_action_difference':eqmax},indent=2))
if __name__=='__main__':main()
