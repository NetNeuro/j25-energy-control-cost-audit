"""Independent physical reconstruction and paired blocked statistical analysis."""
import json
import numpy as np,pandas as pd
from .common import *

def main():
    data=load_data(True);folder=ROOT/'results/study_v0_5/fresh_test';out=ROOT/'results/study_v0_5/analysis';out.mkdir(exist_ok=False)
    rows=[];audit={'episodes':0,'decisions':0,'building_actions':0,'max_balance_residual':0.,'max_grid_residual':0.,
        'max_state_continuity_error':0.,'max_storage_violation':0.,'max_device_violation':0.,'max_import_overload_kw':0.,
        'base_overload_decisions':0,'score_audits':0,'score_miscoverages':0}
    per_action=[]
    for p in sorted(folder.glob('*.summary.json')):
        s=json.loads(p.read_text());d=data[s['community']]
        with np.load(p.with_name(s['key']+'.npz'),allow_pickle=False) as a:
            rec=[json.loads(x) for x in a['records_json']];actions=a['actions'];states=a['states'];origins=a['origins'];cap=a['cap'];ret=a['retention'];feeder=float(a['feeder'])
            assert len(rec)==168 and actions.shape==(168,3,7) and states.shape==(169,3,2)
            loads=d['loads'][origins];gen=np.stack([actions[:,:,0]+actions[:,:,1],actions[:,:,2]],axis=2)
            unmet=actions[:,:,3:5];res=states[1:]-ret*states[:-1]-gen-unmet+loads[:,:,[1,2]]
            cop=np.array([r['actual_cop'] for r in rec]);grid=(loads[:,:,0]+loads[:,:,3]/3+actions[:,:,0]/cop[:,None]+actions[:,:,1]+actions[:,:,2]).sum(axis=1)
            dev=max(0,(actions[:,:,0]/cop[:,None]-a['hp_el']).max(),(actions[:,:,1]-a['aux']).max(),(actions[:,:,2]-a['dhw']).max())
            audit['max_balance_residual']=max(audit['max_balance_residual'],float(np.abs(res).max()))
            audit['max_state_continuity_error']=max(audit['max_state_continuity_error'],float(np.abs(actions[:,:,5:7]-states[1:]).max()))
            audit['max_grid_residual']=max(audit['max_grid_residual'],float(np.abs(grid-[r['grid_kwh'] for r in rec]).max()))
            audit['max_storage_violation']=max(audit['max_storage_violation'],float(max(0,-states.min(),(states-cap).max())))
            audit['max_device_violation']=max(audit['max_device_violation'],float(dev));audit['max_import_overload_kw']=max(audit['max_import_overload_kw'],float(max(0,grid.max()-feeder)))
            audit['base_overload_decisions']+=sum(r['base_overload_kw']>1e-6 for r in rec)
            audit['episodes']+=1;audit['decisions']+=len(rec);audit['building_actions']+=len(rec)*3
            assert abs(float(unmet.sum())-s['unmet_kwh_th'])<1e-5
            if s['spec']['name'] in ['proposed','marginal_calibration','no_model_adaptation','uncalibrated_score']:
                for j in range(5):
                    rr=[r for r in rec if r['chosen_candidate']==j and r['score_miscovered'] is not None]
                    per_action.append({'method':s['spec']['name'],'regime':s['regime'],'candidate':j,'selected':len(rr),'miscovered':sum(r['score_miscovered'] for r in rr),
                        'risk_accepted':sum(r['risk_accepted'] for r in rr),'unmet_kwh_th':sum(r['unmet_kwh_th'] for r in rr)})
    expected=json.loads((ROOT/'protocol/study_v0_5/TEST_FREEZE.json').read_text())['planned_rollouts'];assert audit['episodes']==expected
    rows=[json.loads(p.read_text()) for p in sorted(folder.glob('*.summary.json'))]
    df=pd.DataFrame([{**r,'method':r['spec']['name']} for r in rows]);df.to_csv(out/'episode_results.csv',index=False)
    cols=['energy_cost','unmet_kwh_th','space_unmet_kwh_th','dhw_unmet_kwh_th','terminal_deviation_kwh_th','terminal_signed_kwh_th','grid_kwh','score_checks','score_miscoverages','fallback_count','reserve_unavailable_count','risk_accepted_count']
    aggregate=df.groupby(['regime','method'])[cols].sum();aggregate.to_csv(out/'regime_totals.csv')
    df.groupby('method')[cols].sum().to_csv(out/'pooled_totals.csv')
    pd.DataFrame(per_action).groupby(['method','regime','candidate']).sum().to_csv(out/'selected_action_calibration.csv')
    selection=json.loads((ROOT/'configs/study_v0_5/selected.json').read_text());base=selection['primary_comparator_test_name']
    keys=['climate','community','episode','regime'];tables={m:g.set_index(keys).sort_index() for m,g in df.groupby('method')}
    baseline=tables[base];rng=np.random.default_rng(250511);eps=[e['name'] for e in episode_dates()];climates=['VT','CA','TX'];comparisons=[]
    for method in ['proposed','marginal_calibration','no_model_adaptation','uncalibrated_score','adaptive','scenario','decision_focused']:
        target=tables[method];samples=[]
        for rep in range(2000):
            weeks=rng.choice(eps,len(eps),replace=True);idx=[]
            for climate in climates:
                communities=sorted(df[df.climate==climate].community.unique());communities=rng.choice(communities,len(communities),replace=True)
                idx +=[(climate,c,e,r) for c in communities for e in weeks for r in ['nominal','cop_step']]
            a=target.loc[idx];b=baseline.loc[idx]
            samples.append([(a.unmet_kwh_th.sum()-b.unmet_kwh_th.sum())/len(a),
               a.energy_cost.sum()/b.energy_cost.sum()-1,
               a.unmet_kwh_th.sum()/max(b.unmet_kwh_th.sum(),1e-12)-1,
               (a.terminal_deviation_kwh_th.sum()-b.terminal_deviation_kwh_th.sum())/len(a)])
        v=np.array(samples);a=target;b=baseline
        result={'method':method,'baseline':base,'mean_week_unmet_difference':float((a.unmet_kwh_th-b.unmet_kwh_th).mean()),
            'relative_cost_difference':float(a.energy_cost.sum()/b.energy_cost.sum()-1),
            'relative_unmet_difference':float(a.unmet_kwh_th.sum()/max(b.unmet_kwh_th.sum(),1e-12)-1),
            'terminal_mean_error_difference':float((a.terminal_deviation_kwh_th-b.terminal_deviation_kwh_th).mean()),
            'unmet_difference_ci95':np.quantile(v[:,0],[.025,.975]).tolist(),'relative_cost_ci95':np.quantile(v[:,1],[.025,.975]).tolist(),
            'relative_unmet_ci95':np.quantile(v[:,2],[.025,.975]).tolist(),'cost_upper_one_sided95':float(np.quantile(v[:,1],.95)),
            'terminal_difference_ci95':np.quantile(v[:,3],[.025,.975]).tolist()}
        comparisons.append(result)
    write_json(out/'paired_clustered_intervals.json',comparisons)
    primary=next(r for r in comparisons if r['method']=='proposed')
    point=primary['relative_unmet_difference']<=-.2 and primary['relative_cost_difference']<=.01 and primary['terminal_mean_error_difference']<=.05
    supported=primary['relative_unmet_ci95'][1]<=-.2 and primary['cost_upper_one_sided95']<=.01 and primary['terminal_difference_ci95'][1]<=.05
    audit['accounting_passed']=max(audit[k] for k in ['max_balance_residual','max_grid_residual','max_state_continuity_error','max_storage_violation','max_device_violation'])<1e-6
    write_json(out/'independent_audit.json',audit)
    write_json(out/'PRIMARY_GATE.json',{'point_criteria_met':point,'interval_supported_criteria_met':supported,'comparison':primary,
        'claim':'Any learned-control advantage remains conditional on these simulated communities and stated assumptions. Neither gate implies guaranteed Q1 acceptance or unconditional safety.'})
    print(aggregate[['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']].to_string());print(json.dumps(primary,indent=2));print('Gate',point,supported)
if __name__=='__main__':main()
