"""Post-campaign physical-adequacy diagnosis, separately frozen as v0.2.1."""
import json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
from .benchmark_v0_2 import ROOT, digest, load_inputs, size_plant, build_problem, solve, matrix_audit, action_audit


def main():
    freeze=json.loads((ROOT/'protocol/SERVICE_DIAGNOSTIC_FREEZE_v0_2_1.json').read_text())
    for x in freeze['files']:
        if digest(ROOT/x['path']) != x['sha256']:raise ValueError(x['path'])
    spec=json.loads((ROOT/'configs/service_diagnostic_v0_2_1.json').read_text())
    c=json.loads((ROOT/spec['parent_config']).read_text());d=load_inputs(c)
    out=ROOT/spec['output_dir'];out.mkdir(exist_ok=False)
    rows=[];solutions={}
    for B in c['building_counts']:
        p=size_plant(d,c,B);initial=np.tile(p['cap']/2,(B,1))
        for e in c['episodes']:
            start=e['start_row'];loads=d['loads'][start:start+24,:B][None]
            temp=d['weather'][start:start+24][None];hours=d['hours'][start:start+24]
            for hard in [False,True]:
                q=build_problem(loads,temp,hours,initial,p,c)
                if hard:
                    q['hi'][q['idx'][:,:,:,3:5].ravel()]=0
                    q['hi'][-4*B:]=0
                r=solve(q,c,'simplex');audit=matrix_audit(q,r['x'])
                row={k:v for k,v in r.items() if k not in ('x','basis')}
                row.update({'buildings':B,'episode':e['name'],'hard_service_and_terminal':hard,**audit})
                if r['x'] is not None and audit['max_matrix_violation']<=c['tolerance']:
                    x=r['x'];plan=x[q['idx']][0];stock=initial.copy();residual=0.;violation=0.
                    for t in range(24):
                        a=action_audit(loads[0,t],temp[0,t],stock,plan[t],p,c)
                        residual=max(residual,a['max_balance_residual']);violation=max(violation,a['max_bound_violation']);stock=a['end']
                    row.update({'energy_cost':float((x[q['grid']][0]*np.array(c['tariff'])[hours]).sum()),
                                'unmet_kwh_th':float(plan[:,:,3:5].sum()),
                                'terminal_deviation_kwh_th':float(np.abs(stock-p['cap']/2).sum()),
                                'max_physical_residual':residual,'max_bound_violation':violation})
                    solutions[f'B{B}_{e["name"]}_hard{hard}']=x
                rows.append(row)
    for row in rows:
        for k,v in row.items():
            if isinstance(v,float) and not np.isfinite(v):row[k]=None
    (out/'diagnostic_results.json').write_text(json.dumps({'completed_at_utc':datetime.now(timezone.utc).isoformat(),
        'interpretation':'Perfect-future full-day model diagnostic only; not a causal controller or a learned result. Hard runs expose whether zero shortfall and exact terminal inventory are physically possible in this mathematical model.',
        'runs':rows},indent=2)+'\n')
    pd.DataFrame(rows).to_csv(out/'diagnostic_results.csv',index=False)
    np.savez_compressed(out/'oracle_solutions.npz',**solutions)
    print(pd.DataFrame(rows)[['buildings','episode','hard_service_and_terminal','status','energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']].to_string(index=False))


if __name__=='__main__':main()
