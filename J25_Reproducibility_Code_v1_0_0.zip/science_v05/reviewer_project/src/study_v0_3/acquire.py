"""Acquire a deterministic development/validation/test cohort before control outcomes."""
import concurrent.futures,hashlib,json,pathlib,urllib.request,time
import pandas as pd,numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[2]
BASE='https://raw.githubusercontent.com/citylearn-project/CityLearn/v3.1.0/data/datasets/'
CLIMATES={'VT':'vt_chittenden_county_neighborhood','CA':'ca_alameda_county_neighborhood','TX':'tx_travis_county_neighborhood'}

def get(url,p):
 if not p.exists():
  for attempt in range(3):
   try:
    data=urllib.request.urlopen(url,timeout=30).read();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);break
   except Exception:
    if attempt==2:raise
 return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'url':url}

def main():
 out=ROOT/'data/study_v0_3';out.mkdir(exist_ok=True,parents=True)
 if (out/'cohort_manifest.json').exists():raise FileExistsError('Cohort already assigned')
 manifest={'version':'0.3','source_tag':'v3.1.0','selection':'first 18 eligible in include=true schema order; eligibility requires finite nonnegative hourly load channels and nonzero SH and DHW annual sums. All first nine VT homes forced training; never controller-performance selection.','selected_before_new_control_outcomes':True,'communities':[],'data':{},'exclusions':[]}
 for climate,name in CLIMATES.items():
  folder=out/'raw'/climate;folder.mkdir(parents=True,exist_ok=True)
  schema=get(BASE+name+'/schema.json',folder/'schema.json');weather=get(BASE+name+'/weather.csv',folder/'weather.csv')
  s=json.loads((ROOT/schema['path']).read_text());ids=[k for k,v in s['buildings'].items() if v.get('include')]
  ids=ids[:24]
  def download(k):return k,get(BASE+name+'/'+k+'.csv',folder/(k+'.csv'))
  with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:files=list(pool.map(download,ids))
  eligible=[]
  for k,item in files:
   d=pd.read_csv(ROOT/item['path']);cols=['non_shiftable_load','heating_demand','dhw_demand','cooling_demand']
   ok=len(d)==8760 and np.isfinite(d[cols].to_numpy()).all() and (d[cols].to_numpy()>=0).all() and d.heating_demand.sum()>0 and d.dhw_demand.sum()>0
   item.update({'id':k,'rows':len(d),'columns':len(d.columns),'eligible':bool(ok),'annual_SH_kwh_th':float(d.heating_demand.sum()),'annual_DHW_kwh_th':float(d.dhw_demand.sum())})
   if ok:eligible.append(item)
   else:manifest['exclusions'].append({'climate':climate,**item,'reason':'predefined data eligibility'})
  if len(eligible)<18:raise RuntimeError('Insufficient cohort '+climate)
  selected=eligible[:18]
  for i in range(6):
   role='train' if i<3 else 'validation' if i==3 else 'test'
   manifest['communities'].append({'id':f'{climate}_{i:02d}','climate':climate,'role':role,'buildings':selected[i*3:(i+1)*3]})
  manifest['data'][climate]={'dataset':name,'schema':schema,'weather':weather,'eligible_inspected':len(eligible),'selected':18}
  print(climate,len(eligible),'eligible,18 assigned',flush=True)
 ids=[x['id'] for c in manifest['communities'] for x in c['buildings']]
 if len(set(ids))!=54:raise ValueError('Building IDs repeat across cohorts')
 (out/'cohort_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Assigned54 homes in18 disjoint communities',flush=True)
if __name__=='__main__':main()
