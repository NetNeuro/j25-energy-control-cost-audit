"""Cohorts and strictly causal feature construction for study v0.3."""
import hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
CHANNELS=['non_shiftable_load','heating_demand','dhw_demand','cooling_demand']

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_all():
    manifest=json.loads((ROOT/'data/study_v0_3/cohort_manifest.json').read_text())
    result={}
    for c in manifest['communities']:
        frames=[]
        for b in c['buildings']:
            if sha(ROOT/b['path'])!=b['sha256']:raise ValueError('Changed raw profile')
            frames.append(pd.read_csv(ROOT/b['path']))
        weather=manifest['data'][c['climate']]['weather']
        if sha(ROOT/weather['path'])!=weather['sha256']:raise ValueError('Changed weather')
        w=pd.read_csv(ROOT/weather['path']).outdoor_dry_bulb_temperature.to_numpy()
        arrays=np.stack([f[CHANNELS].to_numpy() for f in frames],axis=1)
        scales=np.maximum(np.quantile(arrays[:336],.9,axis=0),.25)
        result[c['id']]={'id':c['id'],'climate':c['climate'],'role':c['role'],'loads':arrays,
            'weather':w,'hours':frames[0].hour.to_numpy(dtype=int)-1,
            'daytype':frames[0].day_type.to_numpy(),'scales':scales,'building_ids':[b['id'] for b in c['buildings']]}
    return result

def features(data,origin,leads):
    leads=np.asarray(leads,dtype=int)
    if origin<168 or np.any(leads<1) or np.any(leads>24):raise ValueError('Unsupported feature origin or lead')
    target=origin+leads;B=data['loads'].shape[1];scale=data['scales']
    # Every demand and weather source index is <=origin. Future calendar is known.
    blocks=[data['loads'][target-lag]/scale for lag in [24,48,168]]
    blocks += [np.broadcast_to(data['loads'][origin]/scale,(len(leads),B,4)),
               np.broadcast_to(data['loads'][origin-23:origin+1].mean(axis=0)/scale,(len(leads),B,4))]
    hour=data['hours'][target]
    shared=np.column_stack([np.sin(2*np.pi*hour/24),np.cos(2*np.pi*hour/24),
        leads/24,data['daytype'][target]/8,np.full(len(leads),data['weather'][origin]/30),
        data['weather'][target-24]/30,*[np.full(len(leads),int(data['climate']==c)) for c in ['VT','CA','TX']]])
    return np.concatenate([*blocks,np.broadcast_to(shared[:,None,:],(len(leads),B,shared.shape[1]))],axis=2).reshape(-1,29)

def forecast_point(data,origin,horizon,model=None):
    target=origin+np.arange(horizon)
    y=data['loads'][np.where(np.arange(horizon)==0,origin,target-24)].copy()
    if model is not None and horizon>1:
        y[1:]=np.maximum(0,model.predict(features(data,origin,np.arange(1,horizon))).reshape(horizon-1,3,4)*data['scales'])
    # Causal persistence of current temperature with previous-day diurnal change.
    temp=data['weather'][origin]+data['weather'][target-24]-data['weather'][origin-24]
    temp[0]=data['weather'][origin]
    return y,temp

def episode_dates():
    # Both winter blocks occur in December, after all training and validation.
    return [{'name':n,'start_row':day*24,'hours':168,'season':s} for n,day,s in [
        ('Apr01',90,'spring'),('Apr15',104,'spring'),('Jul01',181,'summer'),('Jul15',195,'summer'),
        ('Oct01',273,'autumn'),('Oct15',287,'autumn'),('Dec01',334,'winter'),('Dec15',348,'winter')]]
