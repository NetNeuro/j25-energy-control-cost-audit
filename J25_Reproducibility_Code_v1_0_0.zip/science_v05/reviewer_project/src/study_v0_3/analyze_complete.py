"""Pre-test specified independent accounting and paired clustered analysis."""
import json,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from .data import ROOT,load_all,episode_dates

def main():
    base=ROOT/'results/study_v0_3/test';out=ROOT/'results/study_v0_3/analysis';out.mkdir(exist_ok=False)
    summaries=[json.loads(p.read_text()) for p in base.glob('*.summary.json')]
    expected=48*len(json.loads((ROOT/'configs/study_v0_3/selected.json').read_text())['test_specs'])
    if len(summaries)!=expected:raise ValueError(f'Incomplete campaign {len(summaries)}/{expected}')
    data=load_all();flat=[];max_balance=0.;max_bounds=0.;max_gridres=0.;max_cont=0.
    statuses={};accepted_cert=0;inside_cert=0;conditional_fail=0;count=0;raw_unavoidable=[]
    for item in summaries:
        cid=item['community'];d=data[cid];key=item['key'];z=np.load(base/(key+'.npz'))
        actions=z['actions'];states=z['states'];orig=z['origins'];load=d['loads'][orig]
        cop=np.clip(.25*(45+273.15)/(45-d['weather'][orig]),1,5)
        output=np.stack([actions[:,:,0]+actions[:,:,1],actions[:,:,2]],axis=2)
        unmet=actions[:,:,3:5];end=actions[:,:,5:7]
        predicted=states[:-1]*np.array([.998,.996])+output+unmet-load[:,:,[1,2]]
        max_balance=max(max_balance,float(np.abs(predicted-end).max()));max_cont=max(max_cont,float(np.abs(end-states[1:]).max()))
        bounds=max(0.,-float(actions.min()),float((actions[:,:,0]-z['hp_el']*cop[:,None]).max()),
            float((actions[:,:,1]-z['aux']).max()),float((actions[:,:,2]-z['dhw']).max()),
            float((unmet-load[:,:,[1,2]]).max()),float((end-z['cap']).max()),
            float((np.abs(output+unmet-load[:,:,[1,2]])-z['cap']).max()))
        grid=(load[:,:,0]+load[:,:,3]/3+actions[:,:,0]/cop[:,None]+actions[:,:,1]+actions[:,:,2]).sum(axis=1)
        bounds=max(bounds,float((grid-z['feeder']).max()));max_bounds=max(max_bounds,bounds)
        with zipfile.ZipFile(base/'complete_decision_records.zip') as archive:
            records=[json.loads(s) for s in archive.read(key+'.jsonl').decode().splitlines()]
        max_gridres=max(max_gridres,float(np.abs(grid-np.array([x['grid_kwh'] for x in records])).max()))
        count+=len(records)
        for i,row in enumerate(records):
            statuses[row['status']]=statuses.get(row['status'],0)+1
            if row['certificate'] and i+1<len(records):
                accepted_cert+=1
                if row['certificate_next_inside']:
                    inside_cert+=1
                    if records[i+1]['unmet_kwh_th']>1e-5:conditional_fail+=1
        heat=float(load[:,:,[1,2]].sum());base_e=(load[:,:,0]+load[:,:,3]/3).sum(axis=1)
        raw_unavoidable.append({'community':cid,'episode':item['episode'],'uncontrollable_base_overload_hours':int((base_e>z['feeder']+1e-5).sum())})
        flat.append({k:v for k,v in item.items() if k not in ['spec','timing_caveat']}|{
            'method':item['spec']['name'],'source_heat_kwh_th':heat,'unmet_per_1000_heat':1000*item['unmet_kwh_th']/max(heat,1),
            'physical_bound_excess':bounds,'unserved_steps':sum(r['unmet_kwh_th']>1e-5 for r in records)})
    df=pd.DataFrame(flat);df.to_csv(out/'episode_results.csv',index=False)
    aggregated=[]
    for method,g in df.groupby('method'):
        aggregated.append({'method':method,'community_weeks':len(g),'energy_cost_total':g.energy_cost.sum(),
            'energy_cost_mean_week':g.energy_cost.mean(),'unmet_kwh_th_total':g.unmet_kwh_th.sum(),
            'unmet_kwh_th_mean_week':g.unmet_kwh_th.mean(),'terminal_deviation_total':g.terminal_deviation_kwh_th.sum(),
            'terminal_deviation_mean_week':g.terminal_deviation_kwh_th.mean(),'grid_kwh_total':g.grid_kwh.sum(),
            'unserved_hours':g.unserved_steps.sum(),'fallback_count':g.fallback_count.sum(),
            'certificate_count':g.certificate_count.sum(),'reserve_infeasible_count':g.reserve_infeasible_count.sum(),
            'cpu_seconds':g.cpu_seconds.sum(),'max_bound_violation':g.physical_bound_excess.max()})
    pd.DataFrame(aggregated).to_csv(out/'main_results.csv',index=False)
    df.groupby(['climate','method'])[['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']].sum().to_csv(out/'climate_results.csv')
    # Pair on community and common weather week; climates are fixed strata.
    rng=np.random.default_rng(20261104);comparisons=[]
    contrasts=[('learned_gate','ml_mpc'),('scenario','ml_mpc'),('reserve_q0.5','ml_mpc'),
               ('reserve_q0.8','ml_mpc'),('rule100','ml_mpc'),('rule75','ml_mpc'),('ml_mpc','persistence')]
    weeks=[e['name'] for e in episode_dates()]
    for method,reference in contrasts:
        a=df[df.method==method].set_index(['community','episode']);b=df[df.method==reference].set_index(['community','episode'])
        delta=(a[['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']]-b[['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']])
        samples=[]
        for _ in range(2000):
            ww=rng.choice(weeks,len(weeks),replace=True);values=[]
            for climate in ['VT','CA','TX']:
                communities=[x for x,d in data.items() if d['role']=='test' and d['climate']==climate]
                cc=rng.choice(communities,len(communities),replace=True)
                values.extend(delta.loc[(x,w)].to_numpy() for x in cc for w in ww)
            samples.append(np.mean(values,axis=0))
        samples=np.array(samples)
        for j,metric in enumerate(delta.columns):
            comparisons.append({'method':method,'reference':reference,'metric':metric,'mean_paired_difference':float(delta[metric].mean()),
                'ci95_lower':float(np.quantile(samples[:,j],.025)),'ci95_upper':float(np.quantile(samples[:,j],.975)),
                'one_sided_95_upper':float(np.quantile(samples[:,j],.95)),'replicates':2000,'unit':'community-week; week resampling shared across all climates and communities'})
    pd.DataFrame(comparisons).to_csv(out/'paired_clustered_intervals.csv',index=False)
    audit={'expected_episodes':expected,'actual_episodes':len(df),'community_decisions':count,'per_building_actions':count*3,
        'independent_max_balance_residual':max_balance,'independent_max_grid_residual':max_gridres,
        'independent_max_state_continuity_error':max_cont,'max_physical_bound_violation':max_bounds,
        'status_counts':statuses,'certificate_audit_count':accepted_cert,'inside_envelope_count':inside_cert,
        'conditional_next_step_service_failures':conditional_fail,
        'accounting_passed':max(max_balance,max_gridres,max_cont)<1e-5,
        'all_policies_hard_bounds_satisfied':max_bounds<1e-5,'unavoidable_base_overloads':list({(x['community'],x['episode']):x for x in raw_unavoidable}.values()),
        'claim_limit':'Certificate is conditional on the declared load/COP envelope and abstract plant; neither calibration independence nor field safety is established.'}
    (out/'independent_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(pd.DataFrame(aggregated).to_string(index=False));print(json.dumps(audit,indent=2)[:1800])
if __name__=='__main__':main()
