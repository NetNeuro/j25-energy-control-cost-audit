"""Service-priority optimization and explicit one-step reserve witness."""
import json,pickle,time
import highspy
import numpy as np
from scipy.sparse import coo_matrix,block_diag,vstack,hstack,csc_matrix
from ..benchmark_v0_2 import build_problem,size_plant,heating_cop,action_audit,fallback,matrix_audit
from .data import ROOT,forecast_point

def configuration():
    c=json.loads((ROOT/'configs/benchmark_v0_2.json').read_text())
    c.update({'version':'0.3','training_end_exclusive':336,'solver_limit_seconds':10.,'tolerance':1e-5})
    return c

def load_models():
    folder=ROOT/'models/study_v0_3'
    with (folder/'point_forecast.pkl').open('rb') as f:model=pickle.load(f)
    with (folder/'calibration.pkl').open('rb') as f:cal=pickle.load(f)
    return model,cal

def scenarios(d,origin,H,model,cal,S):
    point,temp=forecast_point(d,origin,H,model)
    y=np.repeat(point[None],S,axis=0);w=np.repeat(temp[None],S,axis=0)
    donor=cal[d['climate']]
    order=np.random.default_rng(20261104).permutation(len(donor['donors']))
    hours=d['hours'][origin:origin+H]
    for s,idx in enumerate(order[:S-1],start=1):
        y[s]=np.maximum(0,point+donor['donors'][idx,hours]*d['scales'])
        w[s]=temp+donor['temp_donors'][idx,hours]
        y[s,0]=point[0];w[s,0]=temp[0]
    return y,w,point,temp

def add_reserve_witness(p,upper,temp_lower,plant,c):
    """Hard next-step dispatch witness; first-step end inventories are shared.

    SH/DHW may be less than their upper envelope in realization. Excess buffer
    energy need not be discharged; monotonic demand and COP make the upper-load,
    lower-COP feasibility witness sufficient within this abstract model.
    """
    n=len(p['c']);B=plant['buildings'];count=5*B+1
    lo=np.zeros(count);hi=np.full(count,np.inf)
    cop=float(heating_cop(temp_lower,c));rr=[];cc=[];vv=[];rl=[];ru=[]
    def row(terms,lower,upper):
        k=len(rl)
        for j,v in terms:rr.append(k);cc.append(j);vv.append(v)
        rl.append(lower);ru.append(upper)
    for b in range(B):
        z=n+b*5
        hi[b*5:b*5+5]=[plant['hp_el'][b]*cop,plant['aux'][b],plant['dhw'][b],*plant['cap']]
        row([(z+3,1),(p['idx'][0,0,b,5],-plant['retention'][0]),(z,-1),(z+1,-1)],-upper[b,1],-upper[b,1])
        row([(z+4,1),(p['idx'][0,0,b,6],-plant['retention'][1]),(z+2,-1)],-upper[b,2],-upper[b,2])
        row([(z,1),(z+1,1)],upper[b,1]-plant['cap'][0],upper[b,1]+plant['cap'][0])
        row([(z+2,1)],upper[b,2]-plant['cap'][1],upper[b,2]+plant['cap'][1])
    g=n+5*B;hi[-1]=plant['feeder']
    row([(g,1)]+[(n+b*5+k,-(1/cop if k==0 else 1)) for b in range(B) for k in range(3)],
        float((upper[:,0]+upper[:,3]/3).sum()),float((upper[:,0]+upper[:,3]/3).sum()))
    row([(j,1) for j in p['idx'][0,0,:,3:5].ravel()],0,0)
    A=coo_matrix((vv,(rr,cc)),shape=(len(rl),n+count)).tocsc()
    q=p.copy();q['A']=vstack([hstack([p['A'],csc_matrix((p['A'].shape[0],count))]),A]).tocsc()
    q['c']=np.r_[p['c'],np.zeros(count)];q['lo']=np.r_[p['lo'],lo];q['hi']=np.r_[p['hi'],hi]
    q['rl']=np.r_[p['rl'],rl];q['ru']=np.r_[p['ru'],ru];q['witness_cop']=cop
    return q

def lex_solve(p,c):
    """Warm-reoptimized lexicographic current service, future service, terminal, cost."""
    h=highspy.Highs()
    for key,value in {'output_flag':False,'threads':1,'parallel':'off','presolve':'on','solver':'simplex',
        'simplex_strategy':1,'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8,
        'random_seed':25,'time_limit':c['solver_limit_seconds']}.items():h.setOptionValue(key,value)
    lp=highspy.HighsLp();n=len(p['c']);lp.num_col_=n;lp.num_row_=p['A'].shape[0]
    lp.col_cost_=np.zeros(n);lp.col_lower_=p['lo'];lp.col_upper_=p['hi'];lp.row_lower_=p['rl'];lp.row_upper_=p['ru']
    lp.a_matrix_.format_=highspy.MatrixFormat.kColwise;lp.a_matrix_.start_=p['A'].indptr
    lp.a_matrix_.index_=p['A'].indices;lp.a_matrix_.value_=p['A'].data;h.passModel(lp)
    cur=np.zeros(n);cur[p['idx'][0,0,:,3:5].ravel()]=1
    future=np.zeros(n);S,H,B,_=p['idx'].shape
    for s in range(S):
        future[p['idx'][s,1:,:,3:5].ravel()]+=1/S
    terminal=np.zeros(n);base_n=p.get('base_n',len(p['c']))
    terminal[base_n-4*B*S:base_n]=1/S
    energy=p['c'].copy();energy[energy>=100]=0
    stages=[cur,future,terminal,energy];values=[];statuses=[];runtime=0.;iters=0
    cols=np.arange(n,dtype=np.int32)
    for i,obj in enumerate(stages):
        h.changeColsCost(n,cols,obj)
        t=time.perf_counter();h.run();runtime+=time.perf_counter()-t
        status=h.modelStatusToString(h.getModelStatus());statuses.append(status)
        if status!='Optimal':break
        info=h.getInfo();iters+=info.simplex_iteration_count
        x=np.array(h.getSolution().col_value);v=float(obj@x);values.append(v)
        if i<3 and np.any(obj):
            nz=np.flatnonzero(obj).astype(np.int32)
            h.addRow(-highspy.kHighsInf,v+1e-7,len(nz),nz,obj[nz])
    good=len(values)==4
    x=np.array(h.getSolution().col_value) if good else None
    return x,{'status':statuses[-1],'stage_statuses':'|'.join(statuses),'stage_values':values,
        'solver_seconds':runtime,'simplex_iterations':iters,'native_solves':len(statuses),
        'lex_violation':float(max([0]+[stages[i]@x-values[i]-1e-7 for i in range(3)])) if good else None}

def gating_features(d,origin,state,plant,model,cal):
    y,temp=forecast_point(d,origin,2,model)
    cop=float(heating_cop(temp[1],configuration()))
    predicted_grid=float((y[1,:,0]+y[1,:,3]/3+y[1,:,1]/cop+y[1,:,2]).sum())
    fractions=state/plant['cap']
    q=cal[d['climate']]['q']['0.8']
    return np.array([predicted_grid/plant['feeder'],fractions.min(),fractions.mean(),
        (y[1,:,1]/plant['cap'][0]).max(),(y[1,:,2]/plant['cap'][1]).max(),
        q,temp[1]/30,d['hours'][origin]/24,*[float(d['climate']==x) for x in ['VT','CA','TX']]])

def act(d,origin,H,state,plant,method,model,cal,qlevel=.8,gate=None,threshold=0.):
    wall=time.perf_counter();cpu=time.process_time();c=configuration();B=plant['buildings']
    model_state=np.clip(state,0,plant['cap'])
    normalization=float(np.abs(model_state-state).max())
    if normalization>1e-6:raise ValueError('Material initial inventory violation')
    choice=method
    if method in ['fixed_gate','learned_gate']:
        f=gating_features(d,origin,state,plant,model,cal)
        choose=(f[0]>.75 or f[1]<.25) if method=='fixed_gate' else float(gate.predict(f[None])[0])>threshold
        choice='reserve' if choose else 'ml_mpc'
    if method in ['rule','rule75','rule100']:
        rule_config=c.copy()
        if H>=24 and method!='rule':rule_config['initial_fraction']=.75 if method=='rule75' else 1.
        a=fallback(d['loads'][origin],d['weather'][origin],state,plant,rule_config)
        info={'status':'rule','stage_values':[],'native_solves':0,'solver_seconds':0.,'lex_violation':0.}
        cert=False;reserve_failed=False;check={'max_matrix_violation':0.}
        upper=None;lower=None
    else:
        S=5 if choice=='scenario' else 1
        forecast_model=None if choice=='persistence' else model
        loads,temp,point,tpoint=scenarios(d,origin,H,forecast_model,cal,S)
        p=build_problem(loads,temp,d['hours'][origin:origin+H],model_state,plant,c);p['base_n']=len(p['c'])
        q=p;cert=False;reserve_failed=False;upper=None;lower=None
        if choice=='reserve' and H>1:
            score=cal[d['climate']]['q'][str(qlevel)]
            upper=np.maximum(0,point[1]+score*d['scales'])
            lower=tpoint[1]+cal[d['climate']]['temperature_lower_error']
            q=add_reserve_witness(p,upper,lower,plant,c)
        x,info=lex_solve(q,c)
        if x is None and q is not p:
            reserve_failed=True
            x,fallback_info=lex_solve(p,c)
            fallback_info['native_solves']+=info['native_solves'];fallback_info['solver_seconds']+=info['solver_seconds']
            info=fallback_info;q=p
        check=matrix_audit(q,x)
        if x is None or check['max_matrix_violation']>c['tolerance']:
            a=fallback(d['loads'][origin],d['weather'][origin],state,plant,c);used_fallback=True
        else:
            a=x[p['idx'][0,0]];used_fallback=False;cert=q is not p
        if info['stage_values']:
            info['lex_current_unmet']=info['stage_values'][0]
    if method in ['rule','rule75','rule100']:used_fallback=False
    audit=action_audit(d['loads'][origin],d['weather'][origin],state,a,plant,c)
    # The independent action audit is an acceptance condition, not logging only.
    if audit['max_bound_violation']>c['tolerance'] or audit['max_balance_residual']>c['tolerance']:
        a=fallback(d['loads'][origin],d['weather'][origin],state,plant,c)
        audit=action_audit(d['loads'][origin],d['weather'][origin],state,a,plant,c);used_fallback=True;cert=False
    row={k:v for k,v in info.items() if k!='stage_values'}
    row.update({k:v for k,v in audit.items() if k!='end'});row.update(check)
    row.update({'origin':origin,'method':method,'chosen_policy':choice,'certificate':cert,'reserve_infeasible':reserve_failed,
        'state_model_normalization_kwh':normalization,
        'fallback':used_fallback,'decision_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,
        'energy_cost':audit['grid_kwh']*c['tariff'][int(d['hours'][origin])],
        'certificate_next_inside':bool(np.all(d['loads'][origin+1]<=upper+1e-10) and d['weather'][origin+1]>=lower-1e-10) if cert and origin+1<len(d['loads']) else None})
    # Future truth above is audit-only after action acceptance; it never feeds
    # the optimization, selector, forecast or fallback.
    return a,audit['end'],row
