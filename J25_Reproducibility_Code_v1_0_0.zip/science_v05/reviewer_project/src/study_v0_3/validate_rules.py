import concurrent.futures,json
from .campaign import init_worker,run_episode
from .data import ROOT,load_all
def main():
    data=load_all();tasks=[]
    for cid,d in data.items():
        if d['role']!='validation':continue
        for ep in [{'name':'Mar15','start_row':73*24,'hours':168},{'name':'Mar22','start_row':80*24,'hours':168}]:
            for method in ['rule75','rule100']:tasks.append((cid,ep,{'name':method,'method':method},'validation'))
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,initializer=init_worker) as pool:
        for r in pool.map(run_episode,tasks):print(r['key'],r['unmet_kwh_th'],r['terminal_deviation_kwh_th'],flush=True)
if __name__=='__main__':main()
