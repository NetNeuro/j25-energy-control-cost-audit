"""Single-process resident-input latency and lifecycle accounting."""
import json,pickle,time,platform,sys
import numpy as np
import pandas as pd
from .data import ROOT,load_all,episode_dates
from .control import configuration,load_models,size_plant,act

def main():
    out=ROOT/'results/study_v0_3/isolated';out.mkdir(exist_ok=False)
    data=load_all();model,cal=load_models();c=configuration()
    selected=json.loads((ROOT/'configs/study_v0_3/selected.json').read_text());rows=[]
    gate=pickle.load(open(ROOT/'models/study_v0_3/gate_20261.pkl','rb'))
    for climate in ['VT','CA','TX']:
        d=data[climate+'_04'];p=size_plant(d,c,3)
        for ep in [x for x in episode_dates() if x['name'] in ['Apr01','Jul01','Oct01','Dec01']]:
            for repeat in range(5):
                specs=selected['test_specs'];shift=repeat%len(specs)
                for s in specs[shift:]+specs[:shift]:
                    _,_,row=act(d,ep['start_row'],24,np.tile(p['cap']/2,(3,1)),p,s['method'],model,cal,
                        qlevel=s.get('qlevel',.8),gate=gate,threshold=s.get('threshold',0.))
                    row.update({'climate':climate,'episode':ep['name'],'repeat':repeat,'specification':s['name']})
                    rows.append(row)
    df=pd.DataFrame(rows);df.to_csv(out/'decision_timings.csv',index=False)
    summaries=[]
    for name,g in df.groupby('specification'):
        summaries.append({'method':name,'calls':len(g),'mean_seconds':g.decision_seconds.mean(),
            'p50_seconds':g.decision_seconds.median(),'p95_seconds':g.decision_seconds.quantile(.95),
            'p99_seconds':g.decision_seconds.quantile(.99),'max_seconds':g.decision_seconds.max(),
            'first_calls_p95_seconds':g[g['repeat']==0].decision_seconds.quantile(.95),
            'misses_60_seconds':int((g.decision_seconds>60).sum())})
    times=pd.DataFrame(summaries).set_index('method');times.to_csv(out/'latency_summary.csv')
    training=json.loads((ROOT/'results/study_v0_3/gate_training/training_record.json').read_text())
    forecast=json.loads((ROOT/'models/study_v0_3/training_record.json').read_text())
    offline_gate=training['label_branch_cpu_seconds']+sum(x['fit_seconds'] for x in training['fit_runs'])
    # Ten models were explored. Deployment of one model would still require
    # labels, while its own fit is a smaller part of this measured cost.
    life=[]
    for years in [1,3,5]:
        N=8760*years
        for frequency in [0,4,12]:
            trainings=max(1,frequency*years)
            baseline=trainings*forecast['fit_wall_seconds']+N*times.loc['ml_mpc','mean_seconds']
            learned=trainings*(forecast['fit_wall_seconds']+offline_gate)+N*times.loc['learned_gate','mean_seconds']
            life.append({'years':years,'decisions':N,'retraining_per_year':frequency,'total_fit_campaigns':trainings,
                'baseline_compute_seconds':baseline,'learned_compute_seconds':learned,'extra_seconds':learned-baseline,
                'basis':'scenario projection from measured offline and mean isolated online times, not actual multi-year execution'})
    pd.DataFrame(life).to_csv(out/'lifecycle_scenarios.csv',index=False)
    (out/'context.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),
        'concurrency':'one process,one HiGHS thread; all other experiment campaigns finished',
        'timing_scope':'resident arrays through forecast,features,inference,construction,all lexicographic solves,physical checking,fallback',
        'first_calls_retained':True,'offline_gate_cost_seconds':offline_gate,
        'note':'All trained gates are policy-equivalent to ML-MPC. A favorable timing sample cannot establish an operational learning benefit.'},indent=2)+'\n')
    print(times.to_string());print(pd.DataFrame(life).to_string(index=False))
if __name__=='__main__':main()
