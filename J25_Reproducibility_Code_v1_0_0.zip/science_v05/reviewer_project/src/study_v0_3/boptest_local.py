"""Independent local BOPTEST FMU diagnostic; no remote service latency.

This is an explicitly adapted temperature-reserve experiment, not the same
electricity/DHW dispatch plant or direct transfer of the learned gate.
"""
import argparse,json,pickle,shutil,tempfile,time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog,lsq_linear
from fmpy import read_model_description,extract
from fmpy.fmi2 import FMU2Slave
from .data import ROOT,sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['develop','test'],required=True)
    ap.add_argument('--method',choices=['default','mpc','fixed_margin','robust'],default='default')
    ap.add_argument('--period',choices=['peak','typical'],default='peak');args=ap.parse_args()
    folder=ROOT/'data/boptest_v0_3';dt=900.
    if args.mode=='test':
        freeze=json.loads((ROOT/'protocol/study_v0_3/BOPTEST_FREEZE.json').read_text())
        for x in freeze['files']:
            if sha(ROOT/x['path'])!=x['sha256']:raise ValueError(x['path'])
    out=ROOT/f'results/study_v0_3/boptest/{args.mode}_{args.period}_{args.method}';out.mkdir(exist_ok=False,parents=True)
    md=read_model_description(str(folder/'wrapped.fmu'),validate=False)
    unzip=extract(str(folder/'wrapped.fmu'));refs={x.name:x.valueReference for x in md.modelVariables}
    f=FMU2Slave(guid=md.guid,unzipDirectory=unzip,modelIdentifier=md.coSimulation.modelIdentifier,instanceName='boptest')
    if args.mode=='develop':start=0.;warm=0.;end=7*86400.
    else:start=(16 if args.period=='peak' else 108)*86400.;warm=7*86400.;end=start+14*86400.
    f.instantiate();f.setupExperiment(startTime=start-warm);f.enterInitializationMode();f.exitInitializationMode()
    real_names=['reaTZon_y','reaTSetHea_y','reaTSetCoo_y','reaPHeaPum_y','reaPPumEmi_y','reaPFan_y',
        'weaSta_reaWeaTDryBul_y','weaSta_reaWeaHGloHor_y','oveHeaPumY_y']
    def measure():return dict(zip(real_names,f.getReal([refs[n] for n in real_names])))
    def set_u(u):
        f.setBoolean([refs[n] for n in ['oveHeaPumY_activate','ovePum_activate','oveFan_activate']],[True,True,True])
        f.setReal([refs[n] for n in ['oveHeaPumY_u','ovePum_u','oveFan_u']],[float(u),float(u>0),float(u>0)])
    def step(t,u=None):
        if u is not None:set_u(u)
        f.doStep(currentCommunicationPoint=t,communicationStepSize=dt)
        return measure()
    # Known occupancy/comfort schedules are permitted future information.
    schedule=pd.read_csv(Path(unzip)/'resources/dataFromModel.csv')
    timecol=schedule.columns[0]
    lowercol=next(x for x in schedule.columns if x.startswith('LowerSetp'))
    uppercol=next(x for x in schedule.columns if x.startswith('UpperSetp'))
    def bounds(times):
        return np.interp(times,schedule[timecol],schedule[lowercol])-273.15,np.interp(times,schedule[timecol],schedule[uppercol])-273.15
    history=[];measurement=measure();rng=np.random.default_rng(20261104);warmrows=[]
    t=start-warm
    while t<start:
        measurement=step(t);warmrows.append({'time':t+dt,**measurement});history.append(measurement);t+=dt
    rows=[];native_seconds=0.
    if args.mode=='test':model=json.loads((ROOT/'models/study_v0_3/boptest_rc.json').read_text())
    while t<end-.1:
        before=measurement.copy();decision_start=time.perf_counter();u=None;status='default'
        if args.mode=='develop':
            # Recorded safe-bounded excitation for identification, never test tuning.
            u=float(rng.choice([0.,.3,.6,.9])) if len(rows)%4==0 else last_u
            if before['reaTZon_y']<before['reaTSetHea_y']+.3:u=1.
            if before['reaTZon_y']>before['reaTSetCoo_y']-.3:u=0.
        elif args.method!='default':
            H=24;k=np.arange(1,H+1);zone=before['reaTZon_y']-273.15
            last=history[-96:] if len(history)>=96 else history
            # All weather/solar inputs are recorded history, never FMU future arrays.
            weather=np.array([last[(i-1)%len(last)]['weaSta_reaWeaTDryBul_y']-273.15 for i in k])
            solar=np.array([last[(i-1)%len(last)]['weaSta_reaWeaHGloHor_y'] for i in k])
            lo,hi=bounds(t+k*dt)
            a,b,s,offset=model['coefficients'];ret=1-a
            A=np.zeros((H,4*H));rhs=np.zeros(H)
            # Variables u[H],T[H],low_slack[H],high_slack[H].
            for i in range(H):
                A[i,H+i]=1;A[i,i]=-b
                rhs[i]=a*weather[i]+s*solar[i]+offset
                if i:A[i,H+i-1]=-ret
                else:rhs[i]+=ret*zone
            margin=np.zeros(H)
            if args.method=='fixed_margin':margin[:]=.5
            if args.method=='robust':margin=model['negative_error_q90']*np.cumsum(ret**np.arange(H))
            U=np.zeros((2*H,4*H));v=np.zeros(2*H)
            for i in range(H):
                U[i,H+i]=-1;U[i,2*H+i]=-1;v[i]=-lo[i]-margin[i]
                U[H+i,H+i]=1;U[H+i,3*H+i]=-1;v[H+i]=hi[i]
            price=np.where(((t+k*dt)/3600)%24>=7,.0666,.0383)
            price=np.where(((t+k*dt)/3600)%24>=22,.0383,price)
            objective=np.r_[price*model['rated_electric_kw']*.25,np.zeros(H),np.full(2*H,1000.)]
            result=linprog(objective,A_ub=U,b_ub=v,A_eq=A,b_eq=rhs,
                bounds=[(0,1)]*H+[(None,None)]*H+[(0,None)]*(2*H),method='highs-ds')
            status=str(result.status);u=float(result.x[0]) if result.success else float(zone<lo[0]+.3)
        decision_seconds=time.perf_counter()-decision_start
        a=time.perf_counter();measurement=step(t,u);native_seconds+=time.perf_counter()-a
        history.append(measurement)
        power=measurement['reaPHeaPum_y']+measurement['reaPPumEmi_y']+measurement['reaPFan_y']
        hour=((t+dt)/3600)%24;price=.0666 if 7<=hour<22 else .0383
        rows.append({'time':t+dt,'controller':args.method,'u':u if u is not None else measurement['oveHeaPumY_y'],
            'zone_before_c':before['reaTZon_y']-273.15,'outdoor_before_c':before['weaSta_reaWeaTDryBul_y']-273.15,
            'solar_before_wm2':before['weaSta_reaWeaHGloHor_y'],'zone_c':measurement['reaTZon_y']-273.15,
            'power_w':power,'heatpump_power_w':measurement['reaPHeaPum_y'],'lower_c':measurement['reaTSetHea_y']-273.15,
            'upper_c':measurement['reaTSetCoo_y']-273.15,'price':price,'decision_seconds':decision_seconds,
            'solver_status':status,'native_zone_k':measurement['reaTZon_y']})
        last_u=u; t+=dt
    f.terminate();f.freeInstance();shutil.rmtree(unzip)
    df=pd.DataFrame(rows);df.to_csv(out/'trajectory.csv',index=False)
    if warmrows:pd.DataFrame(warmrows).to_csv(out/'warmup.csv',index=False)
    summary={'period':args.period,'method':args.method,'mode':args.mode,'steps':len(df),'communication_seconds':dt,
        'warmup_days':warm/86400,'energy_kwh':float(df.power_w.sum()*dt/3600/1000),
        'illustrative_cost':float((df.power_w*df.price).sum()*dt/3600/1000),
        'thermal_discomfort_kh':float((np.maximum(0,df.lower_c-df.zone_c)+np.maximum(0,df.zone_c-df.upper_c)).sum()*dt/3600),
        'max_cold_deviation_k':float(np.maximum(0,df.lower_c-df.zone_c).max()),
        'native_emulation_wall_seconds':native_seconds,'online_decision_p95_seconds':float(df.decision_seconds.quantile(.95)),
        'fmu_sha256':sha(folder/'wrapped.fmu'),'integration':'Official unmodified co-simulation FMU through FMPy; adapted diagnostic rather than official REST KPI reproduction',
        'metadata_validation':'FMPy strict XML validation disabled for known legacy local/constant metadata; binary and all physics unchanged'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    if args.mode=='develop':
        train=df.iloc[:5*96];valid=df.iloc[5*96:]
        def xy(z):return np.column_stack([z.outdoor_before_c-z.zone_before_c,z.u,z.solar_before_wm2,np.ones(len(z))]),(z.zone_c-z.zone_before_c).to_numpy()
        X,y=xy(train);fit=lsq_linear(X,y,bounds=([.0001,.00001,0.,-.5],[.1,2.,.005,.5]))
        V,z=xy(valid);error=z-V@fit.x
        record={'coefficients':fit.x.tolist(),'negative_error_q90':float(max(0,np.quantile(-error,.9))),
            'validation_one_step_rmse_k':float(np.sqrt((error**2).mean())),'rated_electric_kw':float(np.quantile(df.heatpump_power_w,.99)/1000),
            'identification_steps':len(train),'calibration_steps':len(valid),'fit_family':'bounded one-state RC surrogate,900second sampling','test_outcomes_seen':False}
        (ROOT/'models/study_v0_3/boptest_rc.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
