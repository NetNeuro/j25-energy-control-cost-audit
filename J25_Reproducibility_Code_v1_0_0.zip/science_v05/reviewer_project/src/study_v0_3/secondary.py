"""Separately declared oracle and physical-mismatch sensitivity experiments."""
import concurrent.futures,json,time
import numpy as np
from .data import ROOT,load_all,episode_dates,sha
from .control import *

def oracle_task(item):
    cid,ep=item;d=load_all()[cid];c=configuration();plant=size_plant(d,c,3)
    start=ep['start_row'];H=ep['hours'];state=np.tile(plant['cap']/2,(3,1))
    loads=d['loads'][start:start+H][None];temp=d['weather'][start:start+H][None]
    records=[]
    for hard in [False,True]:
        p=build_problem(loads,temp,d['hours'][start:start+H],state,plant,c);p['base_n']=len(p['c'])
        if hard:p['hi'][p['idx'][:,:,:,3:5].ravel()]=0;p['hi'][-12:]=0
        x,r=lex_solve(p,c);r.update({'community':cid,'episode':ep['name'],'hard_service_terminal':hard})
        if x is not None:
            plan=x[p['idx']][0]
            r.update({'energy_cost':float((x[p['grid']][0]*np.array(c['tariff'])[d['hours'][start:start+H]]).sum()),
                'unmet_kwh_th':float(plan[:,:,3:5].sum()),
                'terminal_deviation':float(np.abs(plan[-1,:,5:7]-plant['cap']/2).sum()),
                'max_matrix_violation':matrix_audit(p,x)['max_matrix_violation']})
        records.append(r)
    return records

def mismatch_task(item):
    cid,ep,method,stress=item;d=load_all()[cid];model,cal=load_models();c=configuration();plant=size_plant(d,c,3)
    if stress=='capacity80':plant['cap']=plant['cap']*.8
    state=np.tile(plant['cap']/2,(3,1));rows=[];states=[state.copy()];actions=[]
    for k in range(ep['hours']):
        origin=ep['start_row']+k;a,pred,r=act(d,origin,min(24,ep['hours']-k),state,plant,method,model,cal,qlevel=.5)
        load=d['loads'][origin];generation=np.stack([a[:,0]*(.8 if stress=='cop80' else 1)+a[:,1],a[:,2]],axis=1)
        retention=1-(1-plant['retention'])*(1.5 if stress=='loss150' else 1)
        retained=state*retention;actual_unmet=np.maximum(a[:,3:5],load[:,[1,2]]-retained-generation)
        actual=retained+generation+actual_unmet-load[:,[1,2]]
        r.update({'predicted_unmet_kwh_th':r['unmet_kwh_th'],'unmet_kwh_th':float(actual_unmet.sum()),
            'stress':stress,'energy_cost':r['energy_cost'],'terminal_deviation':float(np.abs(actual-plant['cap']/2).sum()) if k==ep['hours']-1 else 0.,
            'actual_storage_bound_excess':float(max(0,-actual.min(),(actual-plant['cap']).max()))})
        # COP/loss reductions cannot increase actual next inventory over the
        # nominal plan; no hidden overflow clipping or heat-dump model is used.
        state=actual;states.append(state.copy());actions.append(a);rows.append(r)
    out=ROOT/'results/study_v0_3/secondary';key=f'{cid}__{ep["name"]}__{method}__{stress}'
    np.savez_compressed(out/(key+'.npz'),actions=np.array(actions),states=np.array(states))
    (out/(key+'.jsonl')).write_text(''.join(json.dumps(r,allow_nan=False)+'\n' for r in rows))
    return {'community':cid,'climate':d['climate'],'episode':ep['name'],'method':method,'stress':stress,
        'cost':sum(r['energy_cost'] for r in rows),'unmet_kwh_th':sum(r['unmet_kwh_th'] for r in rows),
        'terminal_deviation':rows[-1]['terminal_deviation'],'max_actual_storage_excess':max(r['actual_storage_bound_excess'] for r in rows)}

def main():
    spec=json.loads((ROOT/'protocol/study_v0_3/SECONDARY_SPECIFICATION.json').read_text())
    for x in spec['files']:
        if sha(ROOT/x['path'])!=x['sha256']:raise ValueError(x['path'])
    out=ROOT/'results/study_v0_3/secondary';out.mkdir(exist_ok=False)
    all_data=load_all();ids=[x for x,d in all_data.items() if d['role']=='test'];oracles=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        for r in pool.map(oracle_task,[(cid,ep) for cid in ids for ep in episode_dates()]):oracles+=r
    (out/'oracle_results.json').write_text(json.dumps(oracles,indent=2)+'\n')
    print('96 oracle soft/hard calculations complete',flush=True)
    ids=[x for x in ids if x.endswith('_04')];eps=[e for e in episode_dates() if e['name'] in ['Apr01','Dec01']]
    tasks=[(cid,ep,method,stress) for cid in ids for ep in eps for method in ['rule100','ml_mpc','reserve'] for stress in ['cop80','loss150','capacity80']]
    results=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        for i,r in enumerate(pool.map(mismatch_task,tasks)):
            results.append(r)
            if i%9==0:print('Sensitivity',i+1,'/',len(tasks),flush=True)
    (out/'sensitivity_results.json').write_text(json.dumps(results,indent=2)+'\n')
if __name__=='__main__':main()
