"""Offline counterfactual value labels from training-community trajectories only."""
import concurrent.futures,json,pickle,time
from pathlib import Path
import numpy as np
from sklearn.ensemble import ExtraTreesRegressor
from .data import ROOT,load_all
from .control import configuration,load_models,size_plant,act,gating_features

def label_community(cid):
    all_data=load_all();d=all_data[cid];model,cal=load_models();c=configuration();p=size_plant(d,c,3)
    rows=[]
    for day in [31,45]:
        state=np.tile(p['cap']/2,(3,1))
        for step in range(48):
            origin=day*24+step
            if step%3==0:
                scores=[]
                for method in ['ml_mpc','reserve']:
                    branch=state.copy();cost=0.;unmet=0.;compute=0.
                    for h in range(12):
                        _,branch,r=act(d,origin+h,24,branch,p,method,model,cal,qlevel=.8)
                        cost+=r['energy_cost'];unmet+=r['unmet_kwh_th'];compute+=r['cpu_seconds']
                    # Endpoint energy is valued at the known shoulder tariff,
                    # independently from any fitted selector parameters.
                    inventory_value=.22*float((branch[:,0]/3+branch[:,1]).sum())
                    scores.append({'score':cost+1000*unmet-inventory_value,'unmet':unmet,'cost':cost,'cpu_seconds':compute})
                f=gating_features(d,origin,state,p,model,cal)
                rows.append({'community':cid,'origin':origin,'features':f.tolist(),
                    'delta_value':scores[0]['score']-scores[1]['score'],'branches':scores,
                    'role':'train','label_horizon':12})
            _,state,_=act(d,origin,24,state,p,'ml_mpc',model,cal)
    return rows

def main():
    out=ROOT/'results/study_v0_3/gate_training';out.mkdir(exist_ok=False,parents=True)
    data=load_all();ids=[x for x,d in data.items() if d['role']=='train']
    t=time.perf_counter();rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        for cid,r in zip(ids,pool.map(label_community,ids)):
            rows+=r;print('Labeled',cid,len(r),flush=True)
    (out/'counterfactual_labels.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
    X=np.array([r['features'] for r in rows]);y=np.array([r['delta_value'] for r in rows])
    fit=[]
    for seed in range(20261,20271):
        model=ExtraTreesRegressor(n_estimators=48,max_depth=6,min_samples_leaf=8,bootstrap=True,random_state=seed,n_jobs=1)
        a=time.perf_counter();model.fit(X,y)
        with (ROOT/f'models/study_v0_3/gate_{seed}.pkl').open('wb') as f:pickle.dump(model,f)
        fit.append({'seed':seed,'fit_seconds':time.perf_counter()-a})
    record={'label_rows':len(rows),'community_ids':ids,'label_horizon_hours':12,
        'observed_label_positive_fraction':float((y>0).mean()),'label_delta_range':[float(y.min()),float(y.max())],
        'label_branch_cpu_seconds':sum(sum(z['cpu_seconds'] for z in r['branches']) for r in rows),
        'training_wall_seconds':time.perf_counter()-t,'fit_runs':fit,
        'scope':'Exploratory offline training only; forecast model fitted on overlapping training period. New-building validation and all test operation occur later. No test outcomes used.'}
    (out/'training_record.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
if __name__=='__main__':main()
