"""Fit only training homes before calibration and validation; archive all models."""
import json,pickle,time
from datetime import datetime,timezone
import numpy as np
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.metrics import mean_absolute_error
from .data import ROOT,load_all,features,forecast_point,sha

def main():
    out=ROOT/'models/study_v0_3';out.mkdir(parents=True,exist_ok=False)
    data=load_all();X=[];Y=[]
    t=time.perf_counter()
    for d in data.values():
        if d['role']!='train':continue
        for origin in range(168,59*24-24,6):
            leads=np.array([1,6,12,24]);X.append(features(d,origin,leads))
            Y.append((d['loads'][origin+leads]/d['scales']).reshape(-1,4))
    X=np.concatenate(X);Y=np.concatenate(Y)
    model=ExtraTreesRegressor(n_estimators=32,min_samples_leaf=12,max_depth=18,random_state=20261104,n_jobs=1)
    model.fit(X,Y)
    with (out/'point_forecast.pkl').open('wb') as f:pickle.dump(model,f)
    fit_seconds=time.perf_counter()-t
    # Calibration uses training homes during March1 through March14, never test homes.
    calibration={};diagnostics=[]
    for climate in ['VT','CA','TX']:
        donors=[];temp_donors=[];one_errors=[];temp_errors=[]
        for d in data.values():
            if d['role']!='train' or d['climate']!=climate:continue
            for day in range(59,73):
                origin=day*24-1;y,temp=forecast_point(d,origin,25,model)
                donors.append((d['loads'][origin+1:origin+25]-y[1:])/d['scales'])
                temp_donors.append(d['weather'][origin+1:origin+25]-temp[1:])
            for origin in range(59*24,73*24-1):
                y,temp=forecast_point(d,origin,2,model)
                one_errors.append((d['loads'][origin+1]-y[1])/d['scales'])
                temp_errors.append(d['weather'][origin+1]-temp[1])
        err=np.array(one_errors)
        # Community-wise maximum positive normalized error, not independent marginals.
        scores=np.maximum(err,0).max(axis=(1,2))
        quantiles={str(q):float(np.quantile(scores,q,method='higher')) for q in [.5,.8,.9,.95]}
        calibration[climate]={'donors':np.array(donors),'temp_donors':np.array(temp_donors),
            'q':quantiles,'temperature_lower_error':float(np.quantile(temp_errors,.05)),
            'calibration_samples':len(scores),'window':[59*24,73*24]}
        diagnostics.append({'climate':climate,'q':quantiles,'temperature_lower_error':calibration[climate]['temperature_lower_error']})
    with (out/'calibration.pkl').open('wb') as f:pickle.dump(calibration,f)
    for d in data.values():
        if d['role']!='validation':continue
        yy=[];pp=[];mm=[]
        for origin in range(73*24,87*24-24,6):
            a,_=forecast_point(d,origin,24,None);b,_=forecast_point(d,origin,24,model)
            yy.append(d['loads'][origin+1:origin+24]);pp.append(a[1:]);mm.append(b[1:])
        a=np.concatenate(yy);b=np.concatenate(pp);c=np.concatenate(mm)
        diagnostics.append({'community':d['id'],'persistence_mae_by_channel':np.abs(a-b).mean(axis=(0,1)).tolist(),
            'ml_mae_by_channel':np.abs(a-c).mean(axis=(0,1)).tolist()})
    (out/'training_record.json').write_text(json.dumps({'trained_at_utc':datetime.now(timezone.utc).isoformat(),
        'fit_wall_seconds':fit_seconds,'rows':len(X),'features':X.shape[1],'seed':20261104,
        'training_origins':[168,59*24-24],'training_roles':['train'],'calibration_roles':['train'],
        'calibration_window':[59*24,73*24],'validation_window':[73*24,87*24],
        'test_outcomes_seen':False,'diagnostics':diagnostics,'cohort_manifest_sha256':sha(ROOT/'data/study_v0_3/cohort_manifest.json')},indent=2)+'\n')
    print('Forecast fitted',len(X),'rows',round(fit_seconds,2),'seconds',flush=True)
    print(json.dumps(diagnostics,indent=2))
if __name__=='__main__':main()
