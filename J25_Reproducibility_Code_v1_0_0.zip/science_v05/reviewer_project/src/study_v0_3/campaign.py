"""Resumable, one-result-per-episode execution with a reserved-test hash gate."""
import argparse,concurrent.futures,json,os,pickle,time,traceback
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from .data import ROOT,load_all,episode_dates,sha
from .control import configuration,load_models,size_plant,act

_DATA=None;_MODEL=None;_CAL=None

def init_worker():
    global _DATA,_MODEL,_CAL
    _DATA=load_all();_MODEL,_CAL=load_models()

def run_episode(task):
    cid,ep,spec,phase=task;d=_DATA[cid];c=configuration();p=size_plant(d,c,3)
    out=ROOT/f'results/study_v0_3/{phase}';out.mkdir(exist_ok=True,parents=True)
    key=f'{cid}__{ep["name"]}__{spec["name"]}'
    completed=out/(key+'.summary.json')
    if completed.exists():return json.loads(completed.read_text())
    log=out/(key+'.jsonl')
    if log.exists():raise FileExistsError('Partial attempted rollout retained; use amended run directory '+key)
    gate=None
    if spec['method']=='learned_gate':
        with (ROOT/f'models/study_v0_3/gate_{spec["seed"]}.pkl').open('rb') as f:gate=pickle.load(f)
    state=np.tile(p['cap']/2,(3,1));states=[state.copy()];actions=[];rows=[];t=time.perf_counter()
    with log.open('w') as f:
        for step in range(ep['hours']):
            origin=ep['start_row']+step;H=min(24,ep['hours']-step)
            a,end,row=act(d,origin,H,state,p,spec['method'],_MODEL,_CAL,
                qlevel=spec.get('qlevel',.8),gate=gate,threshold=spec.get('threshold',0.))
            row.update({'community':cid,'climate':d['climate'],'role':d['role'],'episode':ep['name'],
                'specification':spec['name'],'phase':phase,'step':step})
            row['terminal_deviation']=float(np.abs(end-p['cap']/2).sum()) if step==ep['hours']-1 else 0.
            f.write(json.dumps(row,allow_nan=False)+'\n');f.flush()
            states.append(end.copy());actions.append(a);rows.append(row);state=end
    np.savez_compressed(out/(key+'.npz'),actions=np.array(actions),states=np.array(states),
        origins=np.arange(ep['start_row'],ep['start_row']+ep['hours']),
        cap=p['cap'],hp_el=p['hp_el'],aux=p['aux'],dhw=p['dhw'],feeder=np.array(p['feeder']),
        records_json=np.array([json.dumps(row,allow_nan=False) for row in rows]))
    # Commit the complete buffered log in one atomic replacement. Streaming
    # writes remain useful for partial attempts but are not the final record.
    temporary=log.with_suffix('.complete.tmp')
    temporary.write_text(''.join(json.dumps(row,allow_nan=False)+'\n' for row in rows))
    os.replace(temporary,log)
    summary={'key':key,'community':cid,'climate':d['climate'],'role':d['role'],'episode':ep['name'],
        'season':ep.get('season','development'),'spec':spec,'phase':phase,'steps':len(rows),
        'energy_cost':sum(x['energy_cost'] for x in rows),'unmet_kwh_th':sum(x['unmet_kwh_th'] for x in rows),
        'terminal_deviation_kwh_th':rows[-1]['terminal_deviation'],'grid_kwh':sum(x['grid_kwh'] for x in rows),
        'max_balance_residual':max(x['max_balance_residual'] for x in rows),
        'max_bound_violation':max(x['max_bound_violation'] for x in rows),
        'fallback_count':sum(x['fallback'] for x in rows),'reserve_infeasible_count':sum(x['reserve_infeasible'] for x in rows),
        'certificate_count':sum(x['certificate'] for x in rows),
        'certificate_inside_count':sum(x['certificate_next_inside'] is True for x in rows),
        'reserve_selected_count':sum(x['chosen_policy']=='reserve' for x in rows),
        'decision_wall_seconds':sum(x['decision_seconds'] for x in rows),'cpu_seconds':sum(x['cpu_seconds'] for x in rows),
        'p95_concurrent_decision_seconds':float(np.quantile([x['decision_seconds'] for x in rows],.95)),
        'completed_at_utc':datetime.now(timezone.utc).isoformat(),'job_wall_seconds':time.perf_counter()-t,
        'timing_caveat':'campaign runs up to four independent single-thread processes; isolated latency benchmark is separate'}
    completed.write_text(json.dumps(summary,indent=2)+'\n')
    return summary

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['validation','test'],required=True);args=ap.parse_args()
    data=load_all()
    if args.phase=='validation':
        eps=[{'name':'Mar15','start_row':73*24,'hours':168},{'name':'Mar22','start_row':80*24,'hours':168}]
        specs=[{'name':x,'method':x} for x in ['rule','persistence','ml_mpc','scenario','fixed_gate']]
        specs += [{'name':f'reserve_q{q}','method':'reserve','qlevel':q} for q in [.5,.8,.9,.95]]
        specs += [{'name':f'gate_t{v}','method':'learned_gate','seed':20261,'threshold':v} for v in [0.,.1,1.,10.]]
        ids=[cid for cid,d in data.items() if d['role']=='validation']
    else:
        frozen=json.loads((ROOT/'protocol/study_v0_3/TEST_FREEZE.json').read_text())
        for item in frozen['files']:
            expected=item['sha256']
            if item['path']=='src/study_v0_3/campaign.py':
                amendment=ROOT/'protocol/study_v0_3/BINARY_LOG_AMENDMENT_v0_3_3.json'
                if not amendment.exists():amendment=ROOT/'protocol/study_v0_3/LOGGING_AMENDMENT_v0_3_2.json'
                if amendment.exists():expected=json.loads(amendment.read_text())['new_runner_sha256']
            if sha(ROOT/item['path'])!=expected:raise ValueError('Test-frozen input changed '+item['path'])
        selected=json.loads((ROOT/'configs/study_v0_3/selected.json').read_text())
        eps=episode_dates();specs=selected['test_specs'];ids=[cid for cid,d in data.items() if d['role']=='test']
    tasks=[(cid,ep,spec,args.phase) for cid in ids for ep in eps for spec in specs]
    context={'started_at_utc':datetime.now(timezone.utc).isoformat(),'phase':args.phase,'tasks':len(tasks),'workers':4,
        'single_thread_each':True,'configuration':configuration(),'episodes':eps,'specs':specs,
        'initial_policy':'half-full storage, finite independent weekly episodes, observed prehistory; no annual continuity claim'}
    base=ROOT/f'results/study_v0_3/{args.phase}';base.mkdir(exist_ok=True,parents=True)
    (base/'campaign_context.json').write_text(json.dumps(context,indent=2)+'\n')
    completed=0
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,initializer=init_worker) as pool:
        futures={pool.submit(run_episode,task):task for task in tasks}
        for future in concurrent.futures.as_completed(futures):
            task=futures[future]
            try:r=future.result()
            except Exception:
                with (base/'FAILED_ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps({'task':task,'error':traceback.format_exc()})+'\n')
                raise
            completed+=1
            if completed%6==0 or completed==len(tasks):print(args.phase,completed,'/',len(tasks),r['key'],flush=True)
    context['completed_at_utc']=datetime.now(timezone.utc).isoformat();(base/'campaign_context.json').write_text(json.dumps(context,indent=2)+'\n')
if __name__=='__main__':main()
