"""Verify the versioned development subset; download missing bytes on request."""
import argparse
import json
import urllib.request
from .benchmark_v0_2 import ROOT, digest


def main():
    p=argparse.ArgumentParser();p.add_argument('--download-missing',action='store_true');args=p.parse_args()
    m=json.loads((ROOT/'data/benchmark_v0_2/cohort_manifest.json').read_text())
    for item in m['files']:
        target=ROOT/item['path']
        if not target.exists():
            if not args.download_missing:raise FileNotFoundError(target)
            payload=urllib.request.urlopen(item['url'],timeout=60).read()
            import hashlib
            if hashlib.sha256(payload).hexdigest()!=item['sha256']:raise ValueError('Remote hash mismatch')
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
        if digest(target)!=item['sha256']:raise ValueError('Local hash mismatch '+str(target))
    print('Verified all nine pinned development profiles')


if __name__=='__main__':main()
