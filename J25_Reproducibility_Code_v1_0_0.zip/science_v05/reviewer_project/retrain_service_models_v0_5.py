"""Refit forecaster, service score, calibration and output corrections from raw data."""
import argparse,os,shutil,subprocess,sys,json,pickle
from pathlib import Path
import numpy as np
from src.study_v0_5.common import ROOT,write_json,stamp

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work-dir',required=True);args=ap.parse_args();work=Path(args.work_dir).resolve()
    if work.exists():raise FileExistsError('Use a new work directory')
    work.mkdir(parents=True);shutil.copytree(ROOT/'src',work/'src',ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copytree(ROOT/'data/study_v0_3',work/'data/study_v0_3');(work/'configs').mkdir();shutil.copy2(ROOT/'configs/benchmark_v0_2.json',work/'configs/benchmark_v0_2.json')
    (work/'results/study_v0_5').mkdir(parents=True);(work/'models').mkdir()
    env=os.environ.copy();env['OMP_NUM_THREADS']='1';env['OPENBLAS_NUM_THREADS']='1'
    for module in ['src.study_v0_3.fit_forecast','src.study_v0_5.develop','src.study_v0_5.tune_decision']:
        log=work/(module.rsplit('.',1)[-1]+'.log')
        with log.open('w') as f:r=subprocess.run([sys.executable,'-m',module],cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError('Retraining stage failed: '+module+'; '+str(log))
        print('Refitted',module,flush=True)
    old=np.load(ROOT/'models/study_v0_5/training_labels.npz');new=np.load(work/'models/study_v0_5/training_labels.npz')
    a=pickle.load(open(ROOT/'models/study_v0_5/service_score.pkl','rb'));b=pickle.load(open(work/'models/study_v0_5/service_score.pkl','rb'))
    point_old=pickle.load(open(ROOT/'models/study_v0_3/point_forecast.pkl','rb'));point_new=pickle.load(open(work/'models/study_v0_3/point_forecast.pkl','rb'))
    from src.study_v0_3.data import load_all,features
    d=load_all()['VT_03'];probe=features(d,75*24,np.array([1,6,12,23]))
    riskdiff=float(np.abs(a.predict(old['X'])-b.predict(old['X'])).max());pointdiff=float(np.abs(point_old.predict(probe)-point_new.predict(probe)).max())
    correction_old=json.loads((ROOT/'models/study_v0_5/decision_corrections.json').read_text());correction_new=json.loads((work/'models/study_v0_5/decision_corrections.json').read_text())
    result={'completed_utc':stamp(),'work_dir':str(work),'point_forecast_probe_max_difference':pointdiff,'service_score_prediction_max_difference':riskdiff,
        'training_labels_equal':bool(np.array_equal(old['Y'],new['Y'])),'decision_corrections_equal':correction_old==correction_new,
        'calibration_equal':json.loads((ROOT/'models/study_v0_5/score_calibration.json').read_text())==json.loads((work/'models/study_v0_5/score_calibration.json').read_text())}
    result['passed']=pointdiff<1e-9 and riskdiff<1e-9 and result['training_labels_equal'] and result['decision_corrections_equal'] and result['calibration_equal']
    # Future reruns preserve the original executed verification receipt.
    write_json(work/'MODEL_RETRAINING_COMPARISON.json',result);print(json.dumps(result,indent=2))
    if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
