"""Fetch the pinned legacy Fortran runtime for the official Linux64 FMU."""
import argparse,hashlib,json,pathlib,platform,subprocess,urllib.request

URL='https://archive.ubuntu.com/ubuntu/pool/main/g/gcc-7/libgfortran4_7.5.0-3ubuntu1~18.04_amd64.deb'
SHA='f89b2473bc251ba0c8eb9479ad31d5f96019e2ea1f8be466beea3a68b11b19fc'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--destination',required=True);args=ap.parse_args()
    if platform.system()!='Linux' or platform.machine() not in ['x86_64','AMD64']:raise RuntimeError('The supplied BOPTEST binary requires Linux x86_64')
    out=pathlib.Path(args.destination).resolve();out.mkdir(parents=True,exist_ok=True);deb=out/'libgfortran4.deb'
    if not deb.exists():deb.write_bytes(urllib.request.urlopen(URL,timeout=60).read())
    if hashlib.sha256(deb.read_bytes()).hexdigest()!=SHA:raise ValueError('Runtime package hash mismatch')
    subprocess.run(['dpkg-deb','-x',str(deb),str(out/'extracted')],check=True)
    lib=out/'extracted/usr/lib/x86_64-linux-gnu'
    print(json.dumps({'library_directory':str(lib),'source_url':URL,'sha256':SHA,
        'license_notice':'GCC runtime library; retain package copyright and runtime exception notices in extracted/usr/share/doc. The dependency is fetched separately, not relicensed as project code.'}))
if __name__=='__main__':main()
