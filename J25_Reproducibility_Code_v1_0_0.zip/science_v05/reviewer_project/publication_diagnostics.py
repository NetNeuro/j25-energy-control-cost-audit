"""Read-only, explicitly post hoc diagnostics of the completed v0.5 campaign.

No controller changes, fitting, new evaluation cohort or confirmatory testing.
"""
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np
import pandas as pd

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--project',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
 root=Path(a.project).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(root))
 from src.study_v0_5.common import load_data
 data=load_data(True);source=root/'results/study_v0_5/analysis_robust/episode_results.csv';df=pd.read_csv(source)
 keys=['community','episode','regime'];manifest=root/'data/study_v0_5/cohort_manifest.json'
 raw=[root/b['path'] for c in json.loads(manifest.read_text())['communities'] for b in c['buildings']]
 allinput=[source,manifest]+raw;by_method=[];demand=0.;per_cell=[]
 for row in df[df.method=='proposed'].itertuples():
  path=root/f'results/study_v0_5/fresh_test/{row.key}.npz';allinput.append(path)
  with np.load(path,allow_pickle=False) as z:demand+=data[row.community]['loads'][z['origins']][:,:,[1,2]].sum()
 for method,part in df.groupby('method'):
  hours=0;episodes=0;thresholded_loss=0.;top=[]
  for row in part.itertuples():
   path=root/f'results/study_v0_5/fresh_test/{row.key}.npz'
   if method!='proposed':allinput.append(path)
   with np.load(path,allow_pickle=False) as z:
    u=z['actions'][:,:,3:5].sum(axis=(1,2));mask=u>1e-3
    hours+=int(mask.sum());episodes+=int(mask.any());thresholded_loss+=float(u[mask].sum());top+=u.tolist()
  total=float(part.unmet_kwh_th.sum());by_method.append({'method':method,'raw_cost':float(part.energy_cost.sum()),'unmet_kwh_th':total,'unmet_percent_of_prescribed_thermal_demand':100*total/demand,'dhw_share_percent':100*part.dhw_unmet_kwh_th.sum()/total if total else 0.,'mean_absolute_terminal_error_kwh_th':float(part.terminal_deviation_kwh_th.mean()),'community_hours_above_0_001_kwh_th':hours,'replays_with_such_an_hour':episodes,'loss_sum_in_thresholded_hours_kwh_th':thresholded_loss,'largest_hour_loss_kwh_th':float(max(top)),'total_community_hours':len(part)*168})
  for (climate,regime),g in part.groupby(['climate','regime']):per_cell.append({'method':method,'climate':climate,'regime':regime,'replays':len(g),'cost':float(g.energy_cost.sum()),'unmet_kwh_th':float(g.unmet_kwh_th.sum()),'mean_terminal_error':float(g.terminal_deviation_kwh_th.mean())})
 by=pd.DataFrame(by_method);by.to_csv(out/'method_diagnostics.csv',index=False);pd.DataFrame(per_cell).to_csv(out/'climate_regime_diagnostics.csv',index=False)
 baseline=df[df.method=='rule100'].set_index(keys);proposed=df[df.method=='proposed'].set_index(keys)
 delta=proposed.unmet_kwh_th-baseline.unmet_kwh_th
 comparisons={'primary_heat_contrast_replays':len(delta),'lower_by_more_than_0_001':int((delta<-.001).sum()),'within_0_001':int((delta.abs()<=.001).sum()),'higher_by_more_than_0_001':int((delta>.001).sum())}
 bycl=df[df.method.isin(['proposed','rule100','adaptive'])].groupby(['method','climate'])[['unmet_kwh_th','dhw_unmet_kwh_th','energy_cost']].sum();bycl.to_csv(out/'principal_climate_totals.csv')
 frontier=[]
 v=by[['raw_cost','unmet_kwh_th','mean_absolute_terminal_error_kwh_th']].to_numpy()
 for i,name in enumerate(by.method):
  dom=[by.method.iloc[j] for j in range(len(by)) if j!=i and np.all(v[j]<=v[i]+1e-6) and np.any(v[j]<v[i]-1e-6)]
  frontier.append({'method':name,'dominated_in_three_recorded_aggregate_metrics_by':dom,'scope':'Observed policy set only; no equality of service or final inventory implied'})
 # A null predictor is a score diagnostic on the ALREADY SELECTED action stream,
 # not a newly executed null-controller baseline and not a coverage guarantee.
 calpath=root/'models/study_v0_5/calibration_counterfactuals.json';allinput.append(calpath)
 cal=json.loads(calpath.read_text());null=[]
 for climate in ['VT','CA','TX']:
  cr=[r for r in cal if r['community'].startswith(climate)];loss=np.array([r['loss'] for r in cr]);available=np.array([r['available'] for r in cr]);maxloss=np.max(np.where(available,loss,-np.inf),axis=1)
  n=len(cr);q=float(np.sort(maxloss)[min(n-1,int(np.ceil((n+1)*.9))-1)]);observed=[]
  for row in df[(df.method=='proposed')&(df.climate==climate)].itertuples():
   with np.load(root/f'results/study_v0_5/fresh_test/{row.key}.npz',allow_pickle=False) as z:
    records=[json.loads(v) for v in z['records_json']]
    observed += [r['score_observed'] for r in records if r['score_observed'] is not None]
  misses=int((np.array(observed)>q+1e-6).sum())
  null.append({'climate':climate,'reference_states':n,'available_candidate_labels':int(available.sum()),'positive_candidate_labels_above_0_001':int((loss[available]>.001).sum()),'reference_states_with_any_loss_above_0_001':int((maxloss>.001).sum()),'null_simultaneous_offset_kwh_th':q,'selected_proposed_stream_checks':len(observed),'null_upper_bound_misses_on_that_stream':misses,'empirical_miscoverage_percent':100*misses/len(observed),'scope':'Zero predictor calibrated on reference candidate maxima, evaluated on already selected proposed actions; not a new closed-loop policy comparison or a guarantee'})
 (out/'null_score_diagnostic.json').write_text(json.dumps(null,indent=2)+'\n')
 result={'analysis_status':'Post hoc descriptive analysis of already inspected outcomes; not new confirmatory evidence','material_hour_threshold_kwh_th':.001,'same_exogenous_thermal_demand_across_regimes_and_policies_kwh_th':float(demand),'denominator_note':'96 regime-specific replays per method reuse 48 unique community-weeks; not annualized','paired_heat_counts':comparisons,'observed_frontier':frontier,'null_score_diagnostic':null,'inputs':[{'path':str(p.relative_to(root)),'sha256':sha(p)} for p in sorted(set(allinput))]}
 (out/'POSTHOC_DIAGNOSTICS.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'thermal_demand_kwh_th':demand,'principal_methods':by[by.method.isin(['proposed','rule100','adaptive'])].to_dict('records'),'paired':comparisons},indent=2))
if __name__=='__main__':main()
