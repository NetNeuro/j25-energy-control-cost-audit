"""Predetermined paired summaries, certificate checks and physical bill accounting."""
from pathlib import Path
import json,sys,hashlib
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1];S=R.parent/'science_v05/reviewer_project'
sys.path.insert(0,str(S))
from src.study_v0_5.common import config,heating_cop,true_scale

def main():
 out=R/'analysis';out.mkdir(exist_ok=True)
 primary=[];ablations=[];solvers=[];cases=[]
 for p in sorted((R/'results/oracle').glob('*__*.json')):
  d=json.loads(p.read_text());primary.extend(d['primary']);ablations.extend(d['ablations'])
  for x in d['solver_calls']:solvers.append({'case':d['key'],'cohort':d['cohort'],**x})
  cases.append({k:d[k] for k in ['key','cohort','community','episode','regime','strict_base_overload_hours','wall_seconds']})
 a=pd.json_normalize(primary);b=pd.json_normalize(ablations);s=pd.DataFrame(solvers)
 assert len(a[a.cohort=='archived'])==1344 and len(a[a.cohort=='replication'])==2688
 a.to_csv(out/'contract_attribution.csv',index=False);b.to_csv(out/'matching_ablations.csv',index=False)
 s.drop(columns=['message']).to_csv(out/'solver_certificates.csv',index=False);pd.DataFrame(cases).to_csv(out/'audit_cases.csv',index=False)
 metrics=[]
 for cohort,folders in [('archived',[S/'results/study_v0_5/fresh_test',S/'results/study_v0_5/physical_score_test']),('replication',[R/'results/replication'])]:
  for folder in folders:
   for p in sorted(folder.glob('*.summary.json')):
    v=json.loads(p.read_text());metrics.append({'cohort':cohort,'method':v['spec']['name'],**{k:v[k] for k in ['community','climate','episode','regime','energy_cost','unmet_kwh_th','space_unmet_kwh_th','dhw_unmet_kwh_th','terminal_deviation_kwh_th','max_balance_residual','max_bound_violation','base_overload_hours','fallback_count']}})
 m=pd.DataFrame(metrics);m.to_csv(out/'controller_episode_metrics.csv',index=False)
 pooled=m.groupby(['cohort','method']).agg(rollouts=('energy_cost','size'),energy_cost=('energy_cost','sum'),unmet_kwh_th=('unmet_kwh_th','sum'),mean_final_error=('terminal_deviation_kwh_th','mean'),base_overload_hours=('base_overload_hours','sum'),fallback_count=('fallback_count','sum')).reset_index()
 pooled.to_csv(out/'controller_pooled_totals.csv',index=False)
 totals=a.groupby(['cohort','method']).agg(cases=('method','size'),decomposable=('decomposable','sum'),raw_saving=('raw_saving','sum'),service_component=('service_component','sum'),inventory_component=('inventory_component','sum'),dispatch_component=('dispatch_component','sum'),native_regret=('native_regret','sum'),reference_regret=('reference_regret','sum'),V00=('V00','sum'),V11=('V11','sum')).reset_index()
 totals.to_csv(out/'attribution_pooled_totals.csv',index=False)
 # Paired community/seasonal block bootstrap, maintaining both regimes and climate strata.
 intervals=[]
 for cohort in ['archived','replication']:
  q=a[(a.cohort==cohort)&(a.method=='proposed')].copy()
  if not q.decomposable.all():
   intervals.append({'cohort':cohort,'status':'not computed because the full paired cohort has infeasible/uncertified contracts'});continue
  keys=['community','episode','regime']
  own=m[(m.cohort==cohort)&(m.method=='proposed')].set_index(keys)
  ref=m[(m.cohort==cohort)&(m.method=='rule100')].set_index(keys)
  q=q.set_index(keys)
  q['unmet_delta']=own.unmet_kwh_th-ref.unmet_kwh_th
  q['final_error_delta']=own.terminal_deviation_kwh_th-ref.terminal_deviation_kwh_th
  q['cost_delta']=own.energy_cost-ref.energy_cost
  cols=['raw_saving','service_component','inventory_component','dispatch_component','unmet_delta','final_error_delta','cost_delta']
  ids=sorted(q.index.get_level_values(0).unique());episodes=sorted(q.index.get_level_values(1).unique());regs=['nominal','cop_step']
  cube=np.array([[[q.loc[(cid,ep,reg),cols].to_numpy(dtype=float) for reg in regs] for ep in episodes] for cid in ids])
  strata=[[i for i,cid in enumerate(ids) if cid.startswith(cl)] for cl in ['VT','CA','TX']]
  rng=np.random.default_rng(20261105);boot=[]
  for j in range(2000):
   ci=np.concatenate([rng.choice(g,size=len(g),replace=True) for g in strata]);ei=rng.integers(0,len(episodes),len(episodes))
   boot.append(cube[ci][:,ei].mean(axis=(0,1,2)))
  z=np.array(boot);point=cube.mean(axis=(0,1,2))
  for i,k in enumerate(cols):intervals.append({'cohort':cohort,'metric':k,'per_replay_estimate':float(point[i]),'lower_95':float(np.quantile(z[:,i],.025)),'upper_95':float(np.quantile(z[:,i],.975)),'bootstrap_draws':2000,'community_clusters':len(ids),'seasonal_blocks':len(episodes)})
 (out/'paired_intervals.json').write_text(json.dumps(intervals,indent=2)+'\n')
 # Exact electrical bill and thermal storage-loss diagnostics for each evaluated policy.
 bills=[];storage=[]
 for cohort,folders in [('archived',[S/'results/study_v0_5/fresh_test',S/'results/study_v0_5/physical_score_test']),('replication',[R/'results/replication'])]:
  for folder in folders:
   for p in sorted(folder.glob('*.summary.json')):
    v=json.loads(p.read_text());method=v['spec']['name'];z=p.with_name(p.name.replace('.summary.json','.npz'))
    with np.load(z,allow_pickle=False) as f:
     actions=f['actions'];states=f['states'];rows=[json.loads(x) for x in f['records_json']];retention=f['retention'];cap=f['cap'];origins=f['origins']
    tempcop=np.array([r['actual_cop'] for r in rows]);hours=(origins%24).astype(int);prices=np.array(config()['tariff'])[hours]
    el=actions[:,:,:3].copy();el[:,:,0]/=tempcop[:,None]
    for k,device in enumerate(['HP','auxiliary','DHW']):
     for price in [.12,.22,.38]:
      select=np.isclose(prices,price);bills.append({'cohort':cohort,'method':method,'community':v['community'],'episode':v['episode'],'regime':v['regime'],'device':device,'price':price,'electrical_kwh':float(el[select,:,k].sum()),'cost':float((el[select,:,k]*price).sum())})
    loss=float(((1-retention)*states[:-1]).sum())
    for h in range(24):
     mask=hours==h;storage.append({'cohort':cohort,'method':method,'hour':h,'mean_fraction':float((states[:-1][mask]/cap).mean()),'mean_thermal_inventory':float(states[:-1][mask].mean()),'weekly_storage_loss':loss/24})
 pd.DataFrame(bills).to_csv(out/'device_tariff_bill.csv',index=False);pd.DataFrame(storage).to_csv(out/'inventory_by_hour.csv',index=False)
 residual_columns=['equality_residual','inequality_violation','bound_violation','stationarity_residual','dual_sign_violation','duality_gap']
 valid=s[s.certificate_passed]
 summary={'completed_controller_rollouts':len(m),'archived_rollouts':1344,'new_rollouts':2688,'new_community_decisions':2688*168,
  'old_and_new_distinct_building_ids':54,'audit_cases':len(cases),'primary_attribution_rows':len(a),'unique_oracle_solves':len(s),
  'solver_status_counts':{str(k):int(v) for k,v in s.status.value_counts().items()},'all_optimal_solutions_certified':bool((s[s.status==0].certificate_passed).all()),
  'decomposable_rows':int(a.decomposable.sum()),'nondecomposable_rows':int((~a.decomposable).sum()),
  'maximum_certificate_residuals':{k:float(valid[k].max()) for k in residual_columns},
  'maximum_attribution_identity_residual':float(a.identity_residual.abs().max()),
  'maximum_native_witness_residual':float(a.filter(like='native_witness.').max().max()),
  'new_maximum_balance_residual':float(m[m.cohort=='replication'].max_balance_residual.max()),
  'new_maximum_bound_violation':float(m[m.cohort=='replication'].max_bound_violation.max()),
  'new_base_overload_hours_across_all_policies':int(m[m.cohort=='replication'].base_overload_hours.sum()),
  'favorable_result_required':False,'new_model_fits':0,'interpretation':'Numerical certificates and accounting identities, not formal interval-arithmetic proofs or causal effects.'}
 (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
