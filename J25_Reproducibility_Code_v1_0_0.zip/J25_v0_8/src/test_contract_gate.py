"""A cross-contract infeasibility counterexample with both native paths feasible."""
from pathlib import Path
import json,unittest
import numpy as np
from oracle import DispatchOracle,attribute

def counterexample():
 load=np.array([[[0.,1.,0.,0.]]])
 plant={'hp_el':np.array([1.]),'aux':np.array([0.]),'dhw':np.array([0.]),'cap':np.array([1.,1.]),'retention':np.ones(2),'feeder':1.}
 o=DispatchOracle(load,np.ones(1),np.ones(1),plant,np.zeros((1,2)))
 Up=np.zeros((1,1,2));Ur=np.array([[[1.,0.]]]);Ep=np.zeros((1,2));Er=np.array([[1.,0.]])
 rows=[o.solve(u,e)[0] for u,e in [(Up,Ep),(Ur,Ep),(Up,Er),(Ur,Er)]]
 return {'native_policy_cost':rows[0]['cost'],'native_reference_cost':rows[3]['cost'],
         'V00':rows[0]['cost'],'V10':rows[1]['cost'],'V01':rows[2]['cost'],'V11':rows[3]['cost'],
         'statuses':[r['status'] for r in rows],
         'decomposable':attribute(1.,1.,*[r['cost'] for r in rows])['decomposable'],
         'physical_reason':'One unit of heat can be generated. Serving one unit while ending with one unit from zero initial inventory requires two units; both native alternatives individually need only one.'}

class CrossContractTest(unittest.TestCase):
 def test_native_feasible_does_not_imply_cross_feasible(self):
  r=counterexample();self.assertEqual(r['statuses'],[0,0,2,0]);self.assertEqual(r['native_policy_cost'],1);self.assertEqual(r['native_reference_cost'],1);self.assertFalse(r['decomposable'])

if __name__=='__main__':
 r=counterexample();out=Path(__file__).resolve().parents[1]/'verification/CROSS_CONTRACT_COUNTEREXAMPLE.json'
 out.write_text(json.dumps(r,indent=2)+'\n');unittest.main()
