"""Reconstruct physical trajectories and saved LP certificates without rerunning policies."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
import audit
from oracle import DispatchOracle
R=Path(__file__).resolve().parents[1];S=R.parent/'science_v05/reviewer_project'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 failures=[];counts={'original_manifest_files':0,'new_controller_rollouts':0,'oracle_solutions':0};maximum={}
 def check(ok,msg):
  if not ok:failures.append(msg)
 def remember(key,value):maximum[key]=max(maximum.get(key,0.),float(value))
 old=json.loads((S/'REVIEW_ARCHIVE_MANIFEST.json').read_text())
 for row in old['files']:
  p=S/row['path'];check(p.is_file() and sha(p)==row['sha256'],'Preserved scientific byte: '+row['path']);counts['original_manifest_files']+=1
 freeze=json.loads((R/'protocol/EXECUTION_FREEZE.json').read_text())
 for row in freeze['files']:check(sha(R/row['path'])==row['sha256'],'Execution freeze: '+row['path'])
 manifest=json.loads((R/'data/cohort_manifest.json').read_text());ids=[b['id'] for c in manifest['communities'] for b in c['buildings']]
 check(len(set(ids))==36 and not set(ids).intersection(manifest['excluded_controlled_ids']),'New ID separation')
 audit.init();cfg=audit.config()
 for p in (R/'results/replication').glob('*.summary.json'):
  s=json.loads(p.read_text());path=p.with_name(p.name.replace('.summary.json','.npz'));check(sha(path)==s['record_sha256'],'Record hash '+p.stem)
  with np.load(path,allow_pickle=False) as a:
   act=a['actions'];state=a['states'];orig=a['origins'];ret=a['retention'];cap=a['cap'];hp=a['hp_el'];aux=a['aux'];dhw=a['dhw'];feeder=float(a['feeder']);rows=[json.loads(v) for v in a['records_json']]
  data=audit.DATA[s['community']];load=data['loads'][orig];cop=np.array([float(audit.heating_cop(data['weather'][t],audit.config(audit.true_scale(s['regime'],i)))) for i,t in enumerate(orig)])
  gen=np.stack([act[:,:,0]+act[:,:,1],act[:,:,2]],axis=2)
  bal=state[1:]-ret*state[:-1]-gen-act[:,:,3:5]+load[:,:,[1,2]]
  electric=act[:,:,:3].copy();electric[:,:,0]/=cop[:,None]
  base=(load[:,:,0]+load[:,:,3]/3).sum(axis=1);grid=base+electric.sum(axis=(1,2));price=np.array(cfg['tariff'])[data['hours'][orig]]
  violation=max(0,float(-state.min()),float((state-cap).max()),float((electric-np.stack([hp,aux,dhw],axis=1)).max()),float((grid-feeder).max()))
  remember('new_thermal_balance',np.max(np.abs(bal)));remember('new_physical_violation',violation)
  cost=float(price@grid);remember('new_bill_residual',abs(cost-s['energy_cost']));check(abs(cost-s['energy_cost'])<1e-6,'Observed cost '+p.stem)
  check(np.max(np.abs(bal))<1e-6 and violation<1e-6,'Physical rollout '+p.stem)
  check(len(rows)==168 and act.shape==(168,3,7),'Complete arrays '+p.stem);counts['new_controller_rollouts']+=1
 for p in sorted((R/'results/oracle').glob('*__*.json')):
  case=json.loads(p.read_text());cohort=case['cohort'];cid=case['community'];ep=case['episode'];reg=case['regime']
  folder=R/'results/replication' if cohort=='replication' else S/'results/study_v0_5/fresh_test'
  ref=folder/f'{cid}__{ep}__{reg}__rule100.npz'
  with np.load(ref) as a:orig=a['origins'];initial=a['states'][0];plant={k:a[k].copy() for k in ['hp_el','aux','dhw','cap','retention','feeder']}
  data=audit.DATA[cid];cop=np.array([float(audit.heating_cop(data['weather'][t],audit.config(audit.true_scale(reg,i)))) for i,t in enumerate(orig)])
  o=DispatchOracle(data['loads'][orig],cop,np.array(cfg['tariff'])[data['hours'][orig]],plant,initial)
  for row in case['solver_calls']:
   if row['status']!=0:
    check(row['cost'] is None and not row['certificate_passed'],'Failed LP value withheld');continue
   with np.load(R/'results/oracle'/row['solution_file'],allow_pickle=False) as a:
    x=a['x'];ye=a['equality_dual'];yu=a['inequality_dual'];yl=a['lower_dual'];yh=a['upper_dual'];U=a['contract_unmet'];E=a['contract_terminal']
   A,b,lo,hi=o.problem(U,E,row['mode'],row['terminal_tolerance'])
   primal=float(o.c@x);dual=float(b@ye+o.bub@yu+lo@yl+hi@yh)
   values={'equality':np.max(np.abs(A@x-b)),'inequality':max(0,np.max(o.Aub@x-o.bub)),
     'bounds':max(0,np.max(lo-x),np.max(x-hi)),'stationarity':np.max(np.abs(o.c-A.T@ye-o.Aub.T@yu-yl-yh)),
     'dual_sign':max(0,np.max(yu),np.max(-yl),np.max(yh)),'gap':abs(primal-dual),'objective':abs(primal+o.constant-row['cost'])}
   for k,v in values.items():remember('oracle_'+k,v)
   check(max(values.values())<=1e-6,'Saved certificate '+case['key']+'/'+row['contract_id']);counts['oracle_solutions']+=1
  for row in case['primary']+case['ablations']:
   if row['decomposable']:
    residual=row['raw_saving']-row['dispatch_component']-row['service_component']-row['inventory_component']
    remember('identity',abs(residual));check(abs(residual)<=1e-6,'Attribution identity '+case['key'])
 check(counts['new_controller_rollouts']==2688,'Expected 2688 new rollouts')
 check(counts['oracle_solutions']==9976,'Expected 9976 saved optimal LPs')
 result={'passed':not failures,'counts':counts,'maximum_reconstructed_residuals':maximum,'failures':failures,
         'scope':'All frozen bytes, all new physical trajectories and every saved primal-dual LP solution reconstructed. Numerical tolerance 1e-6; not field validation.'}
 (R/'verification/INDEPENDENT_RECONSTRUCTION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
 if failures:sys.exit(1)

if __name__=='__main__':main()
