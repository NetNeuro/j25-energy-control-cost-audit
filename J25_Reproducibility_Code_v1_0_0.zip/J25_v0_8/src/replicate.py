"""Repeat unchanged frozen policies on new building IDs, with complete trajectories.

The original scientific project is imported read-only. All new outputs go to v0.8.
"""
from pathlib import Path
import os, sys, json, pickle, time, hashlib, datetime, concurrent.futures, traceback
os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
R=Path(__file__).resolve().parents[1];S=R.parent/'science_v05/reviewer_project'
sys.path.insert(0,str(S))
import numpy as np
import pandas as pd
from src.study_v0_5.common import config,size_plant,heating_cop,execute,true_scale,stamp
from src.study_v0_5.controller import Controller
from src.study_v0_5.physical_score_secondary import PhysicalScoreController
from src.study_v0_3.data import episode_dates
from src.study_v0_3.control import load_models

DATA={};MODEL=CAL=RISK=RCAL=CORR=None
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def init():
 global DATA,MODEL,CAL,RISK,RCAL,CORR
 m=json.loads((R/'data/cohort_manifest.json').read_text())
 for c in m['communities']:
  frames=[]
  for b in c['buildings']:
   assert sha(R/b['path'])==b['sha256'];frames.append(pd.read_csv(R/b['path']))
  wp=S/m['weather'][c['climate']]['science_project_path'];assert sha(wp)==m['weather'][c['climate']]['sha256']
  arr=np.stack([f[['non_shiftable_load','heating_demand','dhw_demand','cooling_demand']].to_numpy() for f in frames],axis=1)
  DATA[c['id']]={'id':c['id'],'climate':c['climate'],'loads':arr,'weather':pd.read_csv(wp).outdoor_dry_bulb_temperature.to_numpy(),
    'hours':frames[0].hour.to_numpy(dtype=int)-1,'daytype':frames[0].day_type.to_numpy(),'scales':np.maximum(np.quantile(arr[:336],.9,axis=0),.25)}
 MODEL,CAL=load_models();RISK=pickle.load(open(S/'models/study_v0_5/service_score.pkl','rb'))
 RCAL=json.loads((S/'models/study_v0_5/score_calibration.json').read_text());CORR=json.loads((S/'models/study_v0_5/decision_corrections.json').read_text())

def run(task):
 cid,ep,spec,regime=task;out=R/'results/replication';out.mkdir(exist_ok=True)
 key=f'{cid}__{ep["name"]}__{regime}__{spec["name"]}';done=out/(key+'.summary.json')
 if done.exists():return json.loads(done.read_text())
 if (out/(key+'.npz')).exists():raise FileExistsError('Uncommitted prior output retained: '+key)
 d=DATA[cid];plant=size_plant(d,config(),3)
 cls=PhysicalScoreController if spec['method']=='physical_score' else Controller
 ctrl=cls(spec,MODEL,CAL,RISK,RCAL,CORR,cache=True)
 if 'gain' in spec:ctrl.feedback_gain=spec['gain']
 state=np.tile(plant['cap']/2,(3,1));states=[state.copy()];actions=[];commands=[];rows=[];start=time.perf_counter()
 for step in range(ep['hours']):
  t=ep['start_row']+step;H=min(24,ep['hours']-step)
  a,detail=ctrl.act(d,t,H,state,plant)
  actual,end,row=execute(d['loads'][t],d['weather'][t],state,a,plant,detail['estimated_scale'],true_scale(regime,step))
  row.update(detail);row.update({'community':cid,'climate':d['climate'],'episode':ep['name'],'regime':regime,'origin':t,'step':step,'method_name':spec['name'],'phase':'replication_v0_8'})
  row['energy_cost']=row['grid_kwh']*config()['tariff'][int(d['hours'][t])]
  ctrl.update(row,d['weather'][t]);states.append(end.copy());actions.append(actual);commands.append(a);rows.append(row);state=end
 dest=out/(key+'.npz');tmp=dest.with_suffix('.npz.tmp')
 with tmp.open('wb') as f:
  np.savez_compressed(f,actions=np.array(actions),model_commands=np.array(commands),states=np.array(states),origins=np.arange(ep['start_row'],ep['start_row']+ep['hours']),
    records_json=np.array([json.dumps(x,allow_nan=False) for x in rows]),cap=plant['cap'],hp_el=plant['hp_el'],aux=plant['aux'],dhw=plant['dhw'],feeder=plant['feeder'],retention=plant['retention'])
 os.replace(tmp,dest)
 summary={'key':key,'community':cid,'climate':d['climate'],'episode':ep['name'],'season':ep['season'],'spec':spec,'regime':regime,'phase':'replication_v0_8','steps':len(rows),
   'energy_cost':sum(x['energy_cost'] for x in rows),'unmet_kwh_th':sum(x['unmet_kwh_th'] for x in rows),
   'space_unmet_kwh_th':sum(x['space_unmet_kwh_th'] for x in rows),'dhw_unmet_kwh_th':sum(x['dhw_unmet_kwh_th'] for x in rows),
   'terminal_deviation_kwh_th':float(np.abs(state-plant['cap']/2).sum()),'terminal_signed_kwh_th':float((state-plant['cap']/2).sum()),
   'max_balance_residual':max(x['max_balance_residual'] for x in rows),'max_bound_violation':max(x['max_bound_violation'] for x in rows),
   'base_overload_hours':sum(x['base_overload_kw']>1e-6 for x in rows),'fallback_count':sum(x['fallback'] for x in rows),
   'decision_wall_seconds':sum(x['decision_seconds'] for x in rows),'wall_seconds':time.perf_counter()-start,'record_sha256':sha(dest),'completed_at_utc':stamp()}
 write(done,summary);return summary

def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=6);args=ap.parse_args()
 freeze=json.loads((R/'protocol/EXECUTION_FREEZE.json').read_text())
 for x in freeze['files']:
  assert sha(R/x['path'])==x['sha256'],x['path']
 p=json.loads((R/'protocol/DESIGN.json').read_text());m=json.loads((R/'data/cohort_manifest.json').read_text())
 tasks=[(c['id'],ep,spec,reg) for c in m['communities'] for ep in episode_dates() for reg in p['new_cohort']['regimes'] for spec in p['new_cohort']['policies']]
 out=R/'results/replication';out.mkdir(exist_ok=True)
 write(out/'CONTEXT.json',{'started_utc':stamp(),'tasks':len(tasks),'workers':args.workers,'configuration_sha256':sha(R/'protocol/DESIGN.json'),'new_model_training':False})
 count=0
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
  futures={pool.submit(run,t):t for t in tasks}
  for future in concurrent.futures.as_completed(futures):
   try:future.result()
   except Exception:
    with (out/'FAILED_ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps({'task':futures[future],'error':traceback.format_exc()})+'\n')
    raise
   count+=1
   if count%48==0 or count==len(tasks):print('Replication',count,'/',len(tasks),flush=True)
 write(out/'COMPLETED.json',{'completed_utc':stamp(),'rollouts':count,'decisions':count*168})

if __name__=='__main__':main()
