"""Independent perfect-information dispatch LP and primal-dual certificates.

Inputs are public loads, physical limits and a delivered-service/final-state
contract. This is an offline accounting bound, not an online controller.
"""
import time, warnings, hashlib
import numpy as np
from scipy.optimize import linprog, OptimizeWarning
from scipy.sparse import coo_matrix, vstack

warnings.filterwarnings('ignore', message='Unrecognized options detected.*threads.*', category=OptimizeWarning)

class DispatchOracle:
 def __init__(self,loads,cop,prices,plant,initial):
  self.loads=np.asarray(loads);self.cop=np.asarray(cop);self.prices=np.asarray(prices);self.plant=plant
  T,B,_=self.loads.shape;self.T=T;self.B=B;self.n=T*B*7
  self.idx=np.arange(self.n).reshape(T,B,7);self.initial=np.asarray(initial)
  self.base=(self.loads[:,:,0]+self.loads[:,:,3]/3).sum(axis=1)
  self.constant=float(self.prices@self.base);self.demand=self.loads[:,:,[1,2]]
  self.c=np.zeros(self.n);self.c[self.idx[:,:,:3]]=np.broadcast_to(self.prices[:,None,None],(T,B,3))
  self.lower=np.zeros(self.n);self.upper=np.zeros(self.n)
  limits=np.column_stack([plant['hp_el'],plant['aux'],plant['dhw']])
  self.upper[self.idx[:,:,:3]]=np.broadcast_to(limits[None],(T,B,3))
  self.upper[self.idx[:,:,3:5]]=self.demand
  self.upper[self.idx[:,:,5:7]]=np.broadcast_to(plant['cap'],(T,B,2))
  rows=[];cols=[];vals=[];rhs=[]
  for t in range(T):
   for b in range(B):
    for j in range(2):
     k=len(rhs);terms=[(self.idx[t,b,5+j],1),(self.idx[t,b,3+j],-1)]
     if j==0:terms.extend([(self.idx[t,b,0],-self.cop[t]),(self.idx[t,b,1],-1)])
     else:terms.append((self.idx[t,b,2],-1))
     target=-self.demand[t,b,j]
     if t:terms.append((self.idx[t-1,b,5+j],-plant['retention'][j]))
     else:target+=plant['retention'][j]*self.initial[b,j]
     for col,val in terms:rows.append(k);cols.append(col);vals.append(val)
     rhs.append(target)
  self.Aeq=coo_matrix((vals,(rows,cols)),shape=(len(rhs),self.n)).tocsr();self.beq=np.array(rhs)
  rr=np.repeat(np.arange(T),B*3);cc=self.idx[:,:,:3].reshape(-1)
  self.Aub=coo_matrix((np.ones(len(cc)),(rr,cc)),shape=(T,self.n)).tocsr()
  self.bub=plant['feeder']-self.base

 def problem(self,unmet,terminal,mode='profile',terminal_tolerance=0.):
  unmet=np.asarray(unmet);terminal=np.asarray(terminal)
  if unmet.shape!=self.demand.shape or terminal.shape!=(self.B,2):raise ValueError('Contract dimensions')
  if np.min(unmet)<-1e-8 or np.max(unmet-self.demand)>1e-8:raise ValueError('Invalid unmet contract')
  lo=self.lower.copy();hi=self.upper.copy();U=np.clip(unmet,0,self.demand)
  A=self.Aeq;b=self.beq
  if mode=='profile':
   lo[self.idx[:,:,3:5]]=U;hi[self.idx[:,:,3:5]]=U
  elif mode in ['building_total','pooled_total']:
   rows=[];cols=[];vals=[];rhs=[]
   groups=[[(bb,j) for bb in range(self.B) for j in range(2)]] if mode=='pooled_total' else [[(bb,j)] for bb in range(self.B) for j in range(2)]
   for k,group in enumerate(groups):
    total=0.
    for bb,j in group:
     cc=self.idx[:,bb,3+j];rows.extend([k]*self.T);cols.extend(cc);vals.extend([1.]*self.T);total+=float(U[:,bb,j].sum())
    rhs.append(total)
   G=coo_matrix((vals,(rows,cols)),shape=(len(groups),self.n)).tocsr()
   A=vstack([A,G],format='csr');b=np.r_[b,rhs]
  else:raise ValueError(mode)
  lo[self.idx[-1,:,5:7]]=np.maximum(0,terminal-terminal_tolerance)
  hi[self.idx[-1,:,5:7]]=np.minimum(self.plant['cap'],terminal+terminal_tolerance)
  if np.any(hi<lo-1e-8):raise ValueError('Invalid terminal contract')
  hi=np.maximum(hi,lo)
  return A,b,lo,hi

 def witness(self,actions):
  x=np.asarray(actions).copy();x[:,:,0]/=self.cop[:,None]
  return x.reshape(-1)

 def solve(self,unmet,terminal,mode='profile',terminal_tolerance=0.,keep_arrays=True):
  A,b,lo,hi=self.problem(unmet,terminal,mode,terminal_tolerance)
  start=time.perf_counter()
  result=linprog(self.c,A_ub=self.Aub,b_ub=self.bub,A_eq=A,b_eq=b,bounds=np.column_stack([lo,hi]),method='highs-ds',
    options={'presolve':True,'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8,'threads':1})
  row={'status':int(result.status),'message':result.message,'solver_seconds':time.perf_counter()-start,
       'iterations':int(result.nit),'mode':mode,'terminal_tolerance':terminal_tolerance,'cost':None,'certificate_passed':False}
  arrays={}
  if result.success:
   x=result.x;ye=result.eqlin.marginals;yu=result.ineqlin.marginals;yl=result.lower.marginals;yh=result.upper.marginals
   equality=float(np.max(np.abs(A@x-b)));inequality=float(max(0,np.max(self.Aub@x-self.bub)))
   bound=float(max(0,np.max(lo-x),np.max(x-hi)))
   stationarity=float(np.max(np.abs(self.c-A.T@ye-self.Aub.T@yu-yl-yh)))
   sign=float(max(0,np.max(yu),np.max(-yl),np.max(yh)))
   primal=float(self.c@x);dual=float(b@ye+self.bub@yu+lo@yl+hi@yh);gap=abs(primal-dual)
   row.update({'cost':primal+self.constant,'primal_objective_excluding_base':primal,'dual_objective_excluding_base':dual,
      'equality_residual':equality,'inequality_violation':inequality,'bound_violation':bound,
      'stationarity_residual':stationarity,'dual_sign_violation':sign,'duality_gap':gap,
      'certificate_passed':max(equality,inequality,bound,stationarity,sign,gap)<=1e-6})
   if keep_arrays:arrays={'x':x,'equality_dual':ye,'inequality_dual':yu,'lower_dual':yl,'upper_dual':yh,'contract_unmet':np.asarray(unmet),'contract_terminal':np.asarray(terminal)}
  return row,arrays

def attribute(Jpolicy,Jreference,V00,V10,V01,V11):
 values=[V00,V10,V01,V11]
 if any(v is None for v in values):return {'decomposable':False}
 service=.5*((V10-V00)+(V11-V01));inventory=.5*((V01-V00)+(V11-V10))
 rp=Jpolicy-V00;rr=Jreference-V11;dispatch=rr-rp;saving=Jreference-Jpolicy
 return {'decomposable':True,'raw_saving':saving,'service_component':service,'inventory_component':inventory,'dispatch_component':dispatch,
         'native_regret':rp,'reference_regret':rr,'identity_residual':saving-service-inventory-dispatch,
         'interaction':V11-V10-V01+V00}
