"""Physical and accounting tests that do not depend on a favorable result."""
import unittest
import numpy as np
from oracle import DispatchOracle,attribute

class OracleTests(unittest.TestCase):
 def problem(self,T=4):
  load=np.zeros((T,1,4));load[:,:,0]=.2;load[:,:,1]=1.;load[:,:,2]=.5
  plant={'hp_el':np.array([2.]),'aux':np.array([2.]),'dhw':np.array([2.]),'cap':np.array([3.,2.]),'retention':np.array([1.,1.]),'feeder':5.}
  return DispatchOracle(load,np.ones(T)*2,np.array([.1,.1,.4,.4])[:T],plant,np.array([[1.,1.]]))
 def test_hand_computable_terminal(self):
  o=self.problem();u=np.zeros((4,1,2));r,a=o.solve(u,np.array([[1.,1.]]))
  self.assertTrue(r['certificate_passed']);self.assertLess(r['duality_gap'],1e-8)
  # Total SH electricity 2 and DHW electricity 2; all can be bought in cheap hours.
  self.assertAlmostEqual(r['cost'],.6,places=7)
 def test_infeasible_service_retained(self):
  o=self.problem();o.plant['feeder']=.2;o.bub[:]=0
  r,a=o.solve(np.zeros((4,1,2)),np.array([[1.,1.]]));self.assertEqual(r['status'],2);self.assertIsNone(r['cost'])
 def test_relaxed_aggregate_is_lower_bound(self):
  o=self.problem();u=np.zeros((4,1,2));u[0,0,1]=.5;E=np.array([[1.,1.]])
  exact,_=o.solve(u,E);agg,_=o.solve(u,E,'building_total');pool,_=o.solve(u,E,'pooled_total')
  self.assertLessEqual(pool['cost'],agg['cost']+1e-8);self.assertLessEqual(agg['cost'],exact['cost']+1e-8)
 def test_attribution_identity_and_symmetry(self):
  r=attribute(10,12,7,8,9,11);self.assertAlmostEqual(r['identity_residual'],0)
  swapped=attribute(10,12,7,9,8,11)
  self.assertAlmostEqual(r['service_component'],swapped['inventory_component'])
 def test_identical_contract_zero_allocation(self):
  r=attribute(10,12,7,7,7,7);self.assertEqual(r['service_component'],0);self.assertEqual(r['inventory_component'],0);self.assertEqual(r['dispatch_component'],2)
 def test_infeasible_attribution_not_imputed(self):
  self.assertFalse(attribute(10,12,7,None,9,11)['decomposable'])
 def test_tolerance_relaxation(self):
  o=self.problem();u=np.zeros((4,1,2));E=np.array([[1.,1.]])
  a,_=o.solve(u,E);b,_=o.solve(u,E,terminal_tolerance=1e-6)
  self.assertLessEqual(b['cost'],a['cost']+1e-8)

if __name__=='__main__':unittest.main()
