"""Re-solve contract audits in a complete fresh work tree, preserving references."""
from pathlib import Path
import argparse,json,os,shutil,subprocess,sys
R=Path(__file__).resolve().parents[1];S=R.parent/'science_v05/reviewer_project'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work-dir',type=Path,required=True);ap.add_argument('--workers',type=int,default=4)
 ap.add_argument('--quick',action='store_true',help='Two complete physical cases in each cohort; full otherwise')
 args=ap.parse_args();work=args.work_dir.resolve()
 if work.is_relative_to(R) or work.is_relative_to(S):raise ValueError('Use a fresh directory outside the reference project')
 work.mkdir(parents=True,exist_ok=False);study=work/'J25_v0_8';study.mkdir()
 for name in ['src','data','protocol']:shutil.copytree(R/name,study/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 (study/'results').mkdir();shutil.copytree(R/'results/replication',study/'results/replication')
 shutil.copytree(S,work/'science_v05/reviewer_project',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 env=os.environ.copy();env.update({'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONPATH':str(study/'src')})
 if args.quick:
  command='import audit; audit.init(); ts=audit.tasks(); chosen=[t for c in ["archived","replication"] for t in [z for z in ts if z[0]==c][:2]]; [audit.one_case(t) for t in chosen]'
  subprocess.run([sys.executable,'-c',command],cwd=study,env=env,check=True)
 else:subprocess.run([sys.executable,str(study/'src/audit.py'),'--workers',str(args.workers)],cwd=study,env=env,check=True)
 checks=[]
 for p in sorted((study/'results/oracle').glob('*__*.json')):
  new=json.loads(p.read_text());ref=json.loads((R/'results/oracle'/p.name).read_text());old={x['method']:x for x in ref['primary']}
  for row in new['primary']:
   target=old[row['method']];deltas={}
   for k in ['V00','V10','V01','V11','raw_saving','service_component','inventory_component','dispatch_component']:
    a=row.get(k);b=target.get(k)
    deltas[k]=abs(a-b) if a is not None and b is not None else (0. if a is b else float('inf'))
   checks.append({'case':new['key'],'method':row['method'],'maximum_value_difference':max(deltas.values()),'status_matches':row['contract_statuses']==target['contract_statuses']})
 result={'mode':'quick' if args.quick else 'full','cases':len(set(x['case'] for x in checks)),'contrasts':len(checks),
   'passed':all(x['maximum_value_difference']<=1e-6 and x['status_matches'] for x in checks),'checks':checks}
 (work/'AUDIT_REPEAT_COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
 if not result['passed']:sys.exit(1)

if __name__=='__main__':main()
