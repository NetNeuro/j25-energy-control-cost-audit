"""Contract-specific cost bounds and two-factor accounting, with all failures retained."""
from pathlib import Path
import os,sys,json,hashlib,time,concurrent.futures,traceback
os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
R=Path(__file__).resolve().parents[1];S=R.parent/'science_v05/reviewer_project'
sys.path.insert(0,str(S))
import numpy as np
import pandas as pd
from oracle import DispatchOracle,attribute
from src.study_v0_5.common import load_data,config,heating_cop,true_scale,stamp
DATA={}

def init():
 global DATA
 DATA=load_data(True)
 manifest=json.loads((R/'data/cohort_manifest.json').read_text())
 for c in manifest['communities']:
  frames=[pd.read_csv(R/b['path']) for b in c['buildings']]
  arr=np.stack([f[['non_shiftable_load','heating_demand','dhw_demand','cooling_demand']].to_numpy() for f in frames],axis=1)
  DATA[c['id']]={'loads':arr,'weather':DATA[c['climate']+'_00']['weather'],'hours':frames[0].hour.to_numpy(dtype=int)-1}

def write(p,x):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)

def one_case(task):
 cohort,cid,ep,regime,paths=task;key=f'{cohort}__{cid}__{ep}__{regime}';out=R/'results/oracle'
 out.mkdir(exist_ok=True);done=out/(key+'.json')
 if done.exists():return json.loads(done.read_text())
 start=time.perf_counter();data=DATA[cid]
 summaries={};records={}
 for method,p in paths.items():
  summaries[method]=json.loads(Path(p).read_text());z=Path(p).with_name(Path(p).name.replace('.summary.json','.npz'))
  with np.load(z,allow_pickle=False) as a:
   records[method]={'actions':a['actions'].copy(),'states':a['states'].copy(),'origins':a['origins'].copy()}
   if method=='rule100':plant={k:a[k].copy() for k in ['hp_el','aux','dhw','cap','retention','feeder']}
 ref=records['rule100'];origins=ref['origins'];T=len(origins)
 cop=np.array([float(heating_cop(data['weather'][t],config(true_scale(regime,i)))) for i,t in enumerate(origins)])
 prices=np.array([config()['tariff'][int(data['hours'][t])] for t in origins])
 o=DispatchOracle(data['loads'][origins],cop,prices,plant,ref['states'][0])
 cache={};solvers=[]
 sol_dir=out/'solutions'/key;sol_dir.mkdir(parents=True,exist_ok=True)
 def value(U,E,mode,tol=0.):
  h=hashlib.sha256(np.ascontiguousarray(U).tobytes()+np.ascontiguousarray(E).tobytes()+mode.encode()+str(tol).encode()).hexdigest()[:24]
  if h not in cache:
   row,arrays=o.solve(U,E,mode,tol)
   row.update({'contract_id':h,'solution_file':f'solutions/{key}/{h}.npz' if arrays else None})
   if arrays:np.savez_compressed(sol_dir/(h+'.npz'),**arrays)
   cache[h]=row;solvers.append(row)
  return cache[h]
 rows=[];ablations=[]
 Uref=ref['actions'][:,:,3:5];Eref=ref['states'][-1];Jref=summaries['rule100']['energy_cost']
 for method,rec in records.items():
  U=rec['actions'][:,:,3:5];E=rec['states'][-1];J=summaries[method]['energy_cost']
  x=o.witness(rec['actions']);A,b,lo,hi=o.problem(U,E)
  witness={'balance_residual':float(np.max(np.abs(A@x-b))),
           'bound_violation':float(max(0,np.max(lo-x),np.max(x-hi))),
           'feeder_violation':float(max(0,np.max(o.Aub@x-o.bub))),
           'cost_residual':float(abs(o.c@x+o.constant-J))}
  modes=['profile']+(['building_total','pooled_total','terminal_tolerance'] if method=='proposed' else [])
  for label in modes:
   mode='profile' if label=='terminal_tolerance' else label;tol=1e-6 if label=='terminal_tolerance' else 0.
   corners=[value(u,e,mode,tol) for u,e in [(U,E),(Uref,E),(U,Eref),(Uref,Eref)]]
   valid=all(v['certificate_passed'] for v in corners)
   result=attribute(J,Jref,*[v['cost'] if v['certificate_passed'] else None for v in corners])
   row={'cohort':cohort,'community':cid,'climate':cid[:2],'episode':ep,'regime':regime,'method':method,'matching':label,
        'observed_cost':J,'reference_cost':Jref,'unmet_kwh_th':summaries[method]['unmet_kwh_th'],
        'native_witness':witness,'contract_statuses':[v['status'] for v in corners],'contract_ids':[v['contract_id'] for v in corners],
        'all_certified':valid,'V00':corners[0]['cost'],'V10':corners[1]['cost'],'V01':corners[2]['cost'],'V11':corners[3]['cost'],**result}
   (rows if label=='profile' else ablations).append(row)
 result={'key':key,'cohort':cohort,'community':cid,'episode':ep,'regime':regime,'primary':rows,'ablations':ablations,
   'solver_calls':solvers,'strict_base_overload_hours':int(np.sum(o.bub < -1e-6)),'wall_seconds':time.perf_counter()-start,'completed_utc':stamp()}
 write(done,result);return result

def tasks():
 grouped={}
 for cohort,folder in [('archived',S/'results/study_v0_5/fresh_test'),('archived',S/'results/study_v0_5/physical_score_test'),('replication',R/'results/replication')]:
  for p in folder.glob('*.summary.json'):
   s=json.loads(p.read_text());key=(cohort,s['community'],s['episode'],s['regime'])
   grouped.setdefault(key,{})[s['spec']['name']]=str(p)
 return [(*key,paths) for key,paths in sorted(grouped.items())]

def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=6);ap.add_argument('--cohort',choices=['archived','replication','both'],default='both');args=ap.parse_args()
 ts=[t for t in tasks() if args.cohort=='both' or t[0]==args.cohort]
 out=R/'results/oracle';out.mkdir(exist_ok=True)
 write(out/f'CONTEXT_{args.cohort}.json',{'started_utc':stamp(),'cases':len(ts),'workers':args.workers,'configuration_sha256':hashlib.sha256((R/'protocol/DESIGN.json').read_bytes()).hexdigest()})
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
  futures={pool.submit(one_case,t):t for t in ts};count=0
  for future in concurrent.futures.as_completed(futures):
   try:future.result()
   except Exception:
    with (out/'FAILED_ATTEMPTS.jsonl').open('a') as f:f.write(json.dumps({'task':futures[future][:-1],'error':traceback.format_exc()})+'\n')
    raise
   count+=1
   if count%12==0 or count==len(ts):print('Certified audit',args.cohort,count,'/',len(ts),flush=True)
 write(out/f'COMPLETED_{args.cohort}.json',{'cases':count,'completed_utc':stamp()})

if __name__=='__main__':main()
