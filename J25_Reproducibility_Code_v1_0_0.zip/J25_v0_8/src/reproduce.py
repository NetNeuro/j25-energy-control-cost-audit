"""Repeat complete new-cohort episodes into a fresh work directory.

--quick repeats the six episodes actually checked in the delivered release.
--full repeats all 2,688 new-cohort rollouts; it was not run a second time here.
"""
from pathlib import Path
import argparse,concurrent.futures,json,sys
import numpy as np
import replicate
R=Path(__file__).resolve().parents[1]

def initialize(work):
 replicate.R=R;replicate.init();replicate.R=Path(work)

def main():
 ap=argparse.ArgumentParser();g=ap.add_mutually_exclusive_group(required=True);g.add_argument('--quick',action='store_true');g.add_argument('--full',action='store_true')
 ap.add_argument('--work-dir',type=Path,required=True);ap.add_argument('--workers',type=int,default=4);args=ap.parse_args()
 work=args.work_dir.resolve();work.mkdir(parents=True,exist_ok=False);(work/'results').mkdir()
 p=json.loads((R/'protocol/DESIGN.json').read_text());m=json.loads((R/'data/cohort_manifest.json').read_text())
 if args.quick:
  ids=['VT_R00','CA_R00','TX_R00'];eps=replicate.episode_dates()[:1];regs=['cop_step'];specs=[x for x in p['new_cohort']['policies'] if x['name'] in ['adaptive','proposed']]
 else:ids=[x['id'] for x in m['communities']];eps=replicate.episode_dates();regs=p['new_cohort']['regimes'];specs=p['new_cohort']['policies']
 tasks=[(cid,ep,spec,reg) for cid in ids for ep in eps for reg in regs for spec in specs];checks=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=initialize,initargs=(str(work),)) as pool:
  for i,new in enumerate(pool.map(replicate.run,tasks)):
   key=new['key'];old=json.loads((R/'results/replication'/(key+'.summary.json')).read_text())
   with np.load(work/'results/replication'/(key+'.npz')) as a,np.load(R/'results/replication'/(key+'.npz')) as b:
    diff=float(np.abs(a['actions']-b['actions']).max())
   delta={k:abs(new[k]-old[k]) for k in ['energy_cost','unmet_kwh_th','terminal_deviation_kwh_th']}
   checks.append({'key':key,'maximum_action_difference':diff,'metric_differences':delta,'passed':diff<=1e-8 and max(delta.values())<=1e-8})
   if (i+1)%12==0 or i+1==len(tasks):print('Repeated',i+1,'/',len(tasks),flush=True)
 result={'mode':'quick' if args.quick else 'full','episodes':len(checks),'all_passed':all(x['passed'] for x in checks),'checks':checks}
 (work/'NUMERICAL_REPEAT.json').write_text(json.dumps(result,indent=2)+'\n');print('All passed:',result['all_passed'])
 if not result['all_passed']:sys.exit(1)

if __name__=='__main__':main()
