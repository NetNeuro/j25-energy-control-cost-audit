"""Derived demand fractions, exact action checks and matching-relaxation summaries."""
from pathlib import Path
import json,numpy as np,pandas as pd
import audit
from src.study_v0_3.data import episode_dates
R=Path(__file__).resolve().parents[1]

def main():
 audit.init();m=json.loads((R/'data/cohort_manifest.json').read_text());ids=[c['id'] for c in m['communities']]
 result={}
 for cohort,cids in [('archived',[x for x in audit.DATA if '_N' in x]),('replication',ids)]:
  total=sum(2*float(audit.DATA[cid]['loads'][ep['start_row']:ep['start_row']+168,:,[1,2]].sum()) for cid in cids for ep in episode_dates())
  exact=0;folder=R/'results/replication' if cohort=='replication' else audit.S/'results/study_v0_5/fresh_test'
  for p in folder.glob('*__proposed.npz'):
   with np.load(p) as a,np.load(p.with_name(p.name.replace('__proposed.npz','__uncalibrated_score.npz'))) as b:
    exact+=int(np.array_equal(a['actions'],b['actions']))
  result[cohort]={'demand_kwh_th':total,'calibrated_uncalibrated_exact_action_replays':exact}
 (R/'analysis/ADDITIONAL_DIAGNOSTICS.json').write_text(json.dumps(result,indent=2)+'\n')
 p=pd.read_csv(R/'analysis/contract_attribution.csv').query("method=='proposed'").set_index(['cohort','community','episode','regime'])
 b=pd.read_csv(R/'analysis/matching_ablations.csv');rows=[]
 for (cohort,mode),q in b.groupby(['cohort','matching']):
  q=q.set_index(['cohort','community','episode','regime']);delta=p.loc[q.index,'V00']-q.V00
  rows.append({'cohort':cohort,'matching':mode,'minimum':delta.min(),'median':delta.median(),'maximum':delta.max(),'sum':delta.sum()})
 pd.DataFrame(rows).to_csv(R/'analysis/matching_sensitivity_summary.csv',index=False)
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
