"""Outcome-independent selection of public profiles for the v0.8 replication."""
from pathlib import Path
import concurrent.futures, hashlib, json, urllib.request, datetime
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parents[1]
S=R.parent/'science_v05/reviewer_project'
DATASETS={'VT':'vt_chittenden_county_neighborhood','CA':'ca_alameda_county_neighborhood','TX':'tx_travis_county_neighborhood'}
BASE='https://raw.githubusercontent.com/citylearn-project/CityLearn/v3.1.0/data/datasets/'
CHANNELS=['non_shiftable_load','heating_demand','dhw_demand','cooling_demand']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fetch(item):
 climate,key=item;dest=R/f'data/raw/{climate}/{key}.csv'
 if not dest.exists():
  dest.parent.mkdir(parents=True,exist_ok=True)
  for attempt in range(3):
   try:
    data=urllib.request.urlopen(BASE+DATASETS[climate]+'/'+key+'.csv',timeout=40).read()
    dest.write_bytes(data);break
   except Exception:
    if attempt==2:raise
 df=pd.read_csv(dest);a=df[CHANNELS].to_numpy()
 eligible=len(df)==8760 and np.isfinite(a).all() and (a>=0).all() and df.heating_demand.sum()>0 and df.dhw_demand.sum()>0
 return {'id':key,'climate':climate,'path':dest.relative_to(R).as_posix(),'sha256':sha(dest),'bytes':dest.stat().st_size,
         'url':BASE+DATASETS[climate]+'/'+key+'.csv','rows':len(df),'eligible':bool(eligible)}

def main():
 dest=R/'data/cohort_manifest.json'
 if dest.exists():raise FileExistsError('Cohort assignment already exists; preserve it')
 previous=[json.loads((S/f'data/study_{v}/cohort_manifest.json').read_text()) for v in ['v0_3','v0_5']]
 excluded={b['id'] for m in previous for c in m['communities'] for b in c['buildings']}
 result={'source_tag':'v3.1.0','selected_before_new_control_outputs':True,'excluded_controlled_ids':sorted(excluded),
         'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'communities':[],'eligibility_audit':[],'weather':{}}
 for climate in DATASETS:
  schema=json.loads((S/f'data/study_v0_3/raw/{climate}/schema.json').read_text())
  candidates=[k for k,v in schema['buildings'].items() if v.get('include') and k not in excluded]
  # Fetch candidates in fixed batches and retain schema ordering, regardless of completion time.
  chosen=[]
  for start in range(0,len(candidates),12):
   with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    rows=list(pool.map(fetch,[(climate,k) for k in candidates[start:start+12]]))
   result['eligibility_audit'].extend(rows);chosen.extend(x for x in rows if x['eligible'])
   if len(chosen)>=12:break
  if len(chosen)<12:raise RuntimeError('Fewer than twelve eligible new profiles: '+climate)
  for j in range(4):result['communities'].append({'id':f'{climate}_R{j:02d}','climate':climate,'buildings':chosen[3*j:3*j+3]})
  weather=S/f'data/study_v0_3/raw/{climate}/weather.csv'
  result['weather'][climate]={'science_project_path':weather.relative_to(S).as_posix(),'sha256':sha(weather)}
  print(climate,'assigned 12 new eligible profiles',flush=True)
 ids=[b['id'] for c in result['communities'] for b in c['buildings']]
 assert len(ids)==len(set(ids))==36 and not excluded.intersection(ids)
 dest.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
